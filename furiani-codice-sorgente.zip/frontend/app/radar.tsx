import React, { useCallback, useEffect, useRef, useState } from "react";
import { View, Text, StyleSheet, Pressable, ScrollView, Linking, Platform } from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import { useRouter } from "expo-router";
import { Ionicons } from "@react-native-vector-icons/ionicons";
import * as Location from "expo-location";

import { apiJson } from "@/src/api";
import { colors, spacing, radius } from "@/src/theme";
import RadarMap from "@/src/components/radar-map";
import type { RadarMapHandle, RadarPosition } from "@/src/components/radar-html";

type Status = "idle" | "locating" | "sharing" | "denied" | "blocked" | "error";

export default function RadarScreen() {
  const insets = useSafeAreaInsets();
  const router = useRouter();
  const mapRef = useRef<RadarMapHandle>(null);
  const watchRef = useRef<Location.LocationSubscription | null>(null);
  const pollRef = useRef<ReturnType<typeof setInterval> | null>(null);
  const [positions, setPositions] = useState<RadarPosition[]>([]);
  const [status, setStatus] = useState<Status>("idle");
  const sharing = status === "sharing" || status === "locating";

  const fetchPositions = useCallback(async () => {
    try {
      const d = await apiJson<{ positions: RadarPosition[] }>("/radar/positions");
      setPositions(d.positions || []);
      mapRef.current?.send({ type: "positions", positions: d.positions || [] });
    } catch {}
  }, []);

  const stopTimers = () => {
    watchRef.current?.remove();
    watchRef.current = null;
    if (pollRef.current) clearInterval(pollRef.current);
    pollRef.current = null;
  };

  // Show who is online even before sharing; stop sharing when leaving the screen
  useEffect(() => {
    fetchPositions();
    const viewPoll = setInterval(fetchPositions, 8000);
    return () => {
      clearInterval(viewPoll);
      if (watchRef.current) apiJson("/radar/leave", { method: "POST" }).catch(() => {});
      stopTimers();
    };
  }, [fetchPositions]);

  const startSharing = async () => {
    try {
      let perm = await Location.getForegroundPermissionsAsync();
      if (perm.status !== "granted") {
        if (!perm.canAskAgain) { setStatus("blocked"); return; }
        perm = await Location.requestForegroundPermissionsAsync();
        if (perm.status !== "granted") { setStatus(perm.canAskAgain ? "denied" : "blocked"); return; }
      }
      setStatus("locating");
      watchRef.current = await Location.watchPositionAsync(
        { accuracy: Location.Accuracy.High, timeInterval: 5000, distanceInterval: 5 },
        async (p) => {
          setStatus("sharing");
          try {
            await apiJson("/radar/ping", {
              method: "POST",
              body: JSON.stringify({ lat: p.coords.latitude, lng: p.coords.longitude }),
            });
          } catch {}
          fetchPositions();
        },
      );
      pollRef.current = setInterval(fetchPositions, 5000);
    } catch {
      setStatus("error");
    }
  };

  const stopSharing = async () => {
    stopTimers();
    setStatus("idle");
    await apiJson("/radar/leave", { method: "POST" }).catch(() => {});
    fetchPositions();
  };

  return (
    <View style={[styles.root, { paddingTop: insets.top }]} testID="radar-screen">
      <View style={styles.header}>
        <Pressable testID="back-home" onPress={() => router.push("/home")} style={styles.iconChip} hitSlop={6}>
          <Ionicons name="chevron-back" size={22} color={colors.onSurface} />
        </Pressable>
        <View style={{ flex: 1 }}>
          <Text style={styles.headerLabel}>POSIZIONE LIVE</Text>
          <Text style={styles.headerTitle}>RADAR SQUADRA</Text>
        </View>
        <View style={[styles.pill, sharing && { backgroundColor: colors.brandPrimary }]}>
          <View style={[styles.dot, { backgroundColor: sharing ? colors.onBrandTertiary : colors.muted }]} />
          <Text style={[styles.pillText, sharing && { color: colors.onBrandPrimary }]}>{sharing ? "ONLINE" : "OFFLINE"}</Text>
        </View>
      </View>

      <View style={styles.controls}>
        {!sharing ? (
          <Pressable testID="start-sharing" onPress={startSharing} style={styles.btn}>
            <Ionicons name="location" size={16} color={colors.onBrandPrimary} />
            <Text style={styles.btnText}>CONDIVIDI LA MIA POSIZIONE</Text>
          </Pressable>
        ) : (
          <Pressable testID="stop-sharing" onPress={stopSharing} style={[styles.btn, styles.btnDanger]}>
            <Ionicons name="close" size={16} color={colors.error} />
            <Text style={[styles.btnText, { color: colors.error }]}>INTERROMPI CONDIVISIONE</Text>
          </Pressable>
        )}
        <Text style={styles.meta}>{positions.length} operatori online</Text>
      </View>
      {status === "locating" ? <Text style={[styles.notice, { color: colors.warning }]}>Ricerca posizione...</Text> : null}
      {status === "denied" ? (
        <Text style={[styles.notice, { color: colors.error }]}>Permesso posizione negato. Premi di nuovo "Condividi" per riprovare.</Text>
      ) : null}
      {status === "blocked" ? (
        <View style={styles.blockedRow}>
          <Text style={[styles.notice, { color: colors.error, flex: 1 }]}>
            Posizione bloccata. Abilitala dalle impostazioni{Platform.OS === "web" ? " del browser" : ""}.
          </Text>
          {Platform.OS !== "web" ? (
            <Pressable testID="open-settings" onPress={() => Linking.openSettings()} style={styles.settingsBtn}>
              <Text style={styles.settingsText}>APRI IMPOSTAZIONI</Text>
            </Pressable>
          ) : null}
        </View>
      ) : null}
      {status === "error" ? <Text style={[styles.notice, { color: colors.error }]}>Impossibile ottenere la posizione.</Text> : null}

      <Text style={styles.disclaimer}>
        Attivando il radar condividi la tua posizione in tempo reale con gli altri operatori. Uscendo dalla pagina o premendo "Interrompi" smetti di condividere.
      </Text>

      <RadarMap ref={mapRef} />

      <ScrollView style={[styles.list, { marginBottom: insets.bottom }]}>
        {positions.map((p) => (
          <Pressable
            key={p.user_id}
            testID={`radar-user-${p.user_id}`}
            onPress={() => mapRef.current?.send({ type: "focus", lat: p.lat, lng: p.lng })}
            style={styles.row}
          >
            <View style={[styles.dot, { width: 12, height: 12, borderRadius: 6, backgroundColor: p.is_me ? colors.info : colors.brandPrimary }]} />
            <Text style={styles.rowName}>{p.name}{p.is_me ? " (tu)" : ""}</Text>
            <Text style={styles.rowAge}>{p.age_seconds ?? 0}s fa</Text>
            <Ionicons name="map" size={16} color={colors.brandPrimary} />
          </Pressable>
        ))}
      </ScrollView>
    </View>
  );
}

const styles = StyleSheet.create({
  root: { flex: 1, backgroundColor: colors.surface },
  header: {
    flexDirection: "row", alignItems: "center", gap: spacing.md,
    paddingHorizontal: spacing.lg, paddingVertical: spacing.md,
    borderBottomWidth: 1, borderBottomColor: colors.border,
  },
  headerLabel: { color: colors.brandPrimary, fontSize: 10, letterSpacing: 2, fontWeight: "800" },
  headerTitle: { color: colors.onSurface, fontSize: 22, fontWeight: "900", letterSpacing: 2 },
  iconChip: {
    width: 44, height: 44, borderRadius: radius.sm, backgroundColor: colors.surfaceSecondary,
    alignItems: "center", justifyContent: "center", borderWidth: 1, borderColor: colors.border,
  },
  pill: {
    flexDirection: "row", alignItems: "center", gap: 4, paddingHorizontal: 8, paddingVertical: 4,
    borderRadius: radius.pill, backgroundColor: colors.surfaceSecondary, borderWidth: 1, borderColor: colors.border,
  },
  pillText: { color: colors.onSurfaceSecondary, fontSize: 9, fontWeight: "900" },
  dot: { width: 8, height: 8, borderRadius: 4 },
  controls: { flexDirection: "row", alignItems: "center", gap: spacing.md, padding: spacing.md, flexWrap: "wrap" },
  btn: {
    flexDirection: "row", alignItems: "center", gap: spacing.sm, backgroundColor: colors.brandPrimary,
    paddingHorizontal: spacing.md, minHeight: 44, borderRadius: radius.sm,
  },
  btnDanger: { backgroundColor: colors.surfaceSecondary, borderWidth: 1, borderColor: colors.error },
  btnText: { color: colors.onBrandPrimary, fontSize: 12, fontWeight: "900", letterSpacing: 1 },
  meta: { color: colors.onSurfaceSecondary, fontSize: 12 },
  notice: { fontSize: 12, paddingHorizontal: spacing.md, paddingBottom: spacing.sm },
  blockedRow: { flexDirection: "row", alignItems: "center", paddingRight: spacing.md },
  settingsBtn: { borderWidth: 1, borderColor: colors.brandPrimary, borderRadius: radius.sm, paddingHorizontal: spacing.sm, minHeight: 36, justifyContent: "center" },
  settingsText: { color: colors.brandPrimary, fontSize: 10, fontWeight: "900", letterSpacing: 1 },
  disclaimer: {
    color: colors.onSurfaceSecondary, fontSize: 11, padding: spacing.sm, paddingHorizontal: spacing.md,
    backgroundColor: colors.surfaceSecondary, borderTopWidth: 1, borderBottomWidth: 1, borderColor: colors.border,
  },
  list: { maxHeight: 180, borderTopWidth: 1, borderTopColor: colors.border },
  row: {
    flexDirection: "row", alignItems: "center", gap: spacing.sm, minHeight: 44,
    paddingHorizontal: spacing.md, borderBottomWidth: 1, borderBottomColor: colors.border,
  },
  rowName: { flex: 1, color: colors.onSurface, fontSize: 13, fontWeight: "700" },
  rowAge: { color: colors.muted, fontSize: 11 },
});
