import React from "react";
import { View, Text, StyleSheet, Pressable, ScrollView } from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import { useRouter } from "expo-router";
import { Ionicons } from "@react-native-vector-icons/ionicons";
import { Image } from "expo-image";

import { useAuth } from "@/src/auth-context";
import { colors, spacing, radius } from "@/src/theme";

type Tile = {
  key: string;
  title: string;
  subtitle: string;
  icon: string;
  route: string;
};

const TILES: Tile[] = [
  {
    key: "events",
    title: "CALENDARIO",
    subtitle: "Eventi · Weekend · Allegati",
    icon: "calendar",
    route: "/events",
  },
  {
    key: "roster",
    title: "GESTIONALE",
    subtitle: "Operatori · Presenze · Pagamenti · Note",
    icon: "people",
    route: "/roster",
  },
  {
    key: "photos",
    title: "ARCHIVIO FOTO",
    subtitle: "Storico 2015+ · Album recenti",
    icon: "images",
    route: "/photos",
  },
  {
    key: "radar",
    title: "RADAR SQUADRA",
    subtitle: "Posizione live operatori sulla mappa",
    icon: "map",
    route: "/radar",
  },
];

const CASSA_TILE: Tile = {
  key: "cassa",
  title: "CASSA SQUADRA",
  subtitle: "Bilancio · Tornei · Documenti",
  icon: "wallet",
  route: "/cassa",
};

export default function HomeScreen() {
  const insets = useSafeAreaInsets();
  const router = useRouter();
  const { user, signOut } = useAuth();
  const isAdmin = user?.role === "admin";

  return (
    <View style={[styles.root, { paddingTop: insets.top }]} testID="home-screen">
      <View style={styles.header}>
        <Image
          source={require("../assets/images/furiani-logo.jpeg")}
          style={styles.logo}
          contentFit="contain"
        />
        <View style={{ flex: 1 }}>
          <Text style={styles.headerLabel}>BATTAGLIONE FURIANI</Text>
          <Text style={styles.headerTitle}>GESTIONALE</Text>
        </View>
        {isAdmin ? (
          <Pressable
            testID="analytics-button"
            onPress={() => router.push("/analytics")}
            style={styles.iconChip}
            hitSlop={6}
          >
            <Ionicons name="stats-chart" size={18} color={colors.brandPrimary} />
          </Pressable>
        ) : null}
        {isAdmin ? (
          <Pressable
            testID="team-button"
            onPress={() => router.push("/team")}
            style={styles.iconChip}
            hitSlop={6}
          >
            <Ionicons name="people" size={18} color={colors.brandPrimary} />
          </Pressable>
        ) : null}
        <Pressable testID="logout-btn" onPress={signOut} style={styles.iconChip} hitSlop={6}>
          <Ionicons name="log-out-outline" size={18} color={colors.onSurfaceSecondary} />
        </Pressable>
      </View>

      <ScrollView
        contentContainerStyle={{ padding: spacing.lg, paddingBottom: spacing.xxl, gap: spacing.lg }}
      >
        <View style={styles.welcome}>
          <Text style={styles.welcomeHello}>
            Benvenuto{user?.name ? `, ${user.name.split(" ")[0]}` : ""}
          </Text>
          <Text style={styles.welcomeSub}>Seleziona una sezione per iniziare</Text>
        </View>

        {(isAdmin ? [...TILES, CASSA_TILE] : TILES).map((t, idx) => (
          <Pressable
            key={t.key}
            testID={`tile-${t.key}`}
            onPress={() => router.push(t.route as any)}
            style={({ pressed }) => [
              styles.tile,
              pressed && { opacity: 0.9, transform: [{ scale: 0.985 }] },
            ]}
          >
            <View style={styles.tileIconWrap}>
              <Ionicons name={t.icon as any} size={34} color={colors.brandPrimary} />
            </View>
            <View style={{ flex: 1, minWidth: 0 }}>
              <Text style={styles.tileTitle}>{t.title}</Text>
              <Text style={styles.tileSubtitle} numberOfLines={2}>
                {t.subtitle}
              </Text>
            </View>
            <Ionicons name="chevron-forward" size={22} color={colors.onBrandPrimary} />
            <View style={styles.tileCorner}>
              <Text style={styles.tileCornerText}>0{idx + 1}</Text>
            </View>
          </Pressable>
        ))}

        <View style={styles.footer}>
          <Text style={styles.footerText}>1° BATTAGLIONE FURIANI · ASD</Text>
          <Text style={styles.footerSubtext}>Softair · Addestramento · Tornei</Text>
        </View>
      </ScrollView>
    </View>
  );
}

const styles = StyleSheet.create({
  root: { flex: 1, backgroundColor: colors.surface },
  header: {
    flexDirection: "row",
    alignItems: "center",
    gap: spacing.sm,
    paddingHorizontal: spacing.lg,
    paddingVertical: spacing.md,
    borderBottomWidth: StyleSheet.hairlineWidth,
    borderBottomColor: colors.border,
  },
  logo: {
    width: 44,
    height: 44,
    borderRadius: 22,
  },
  headerLabel: {
    color: colors.brandPrimary,
    fontSize: 10,
    letterSpacing: 2,
    fontWeight: "800",
  },
  headerTitle: {
    color: colors.onSurface,
    fontSize: 22,
    fontWeight: "900",
    letterSpacing: 2,
  },
  iconChip: {
    width: 36,
    height: 36,
    borderRadius: radius.lg,
    backgroundColor: colors.surfaceSecondary,
    alignItems: "center",
    justifyContent: "center",
    borderWidth: StyleSheet.hairlineWidth,
    borderColor: colors.border,
  },
  welcome: {
    paddingVertical: spacing.sm,
  },
  welcomeHello: {
    color: colors.onSurface,
    fontSize: 20,
    fontWeight: "900",
    letterSpacing: 0.5,
  },
  welcomeSub: {
    color: colors.onSurfaceSecondary,
    fontSize: 13,
    marginTop: 4,
  },
  tile: {
    flexDirection: "row",
    alignItems: "center",
    gap: spacing.md,
    padding: spacing.lg,
    borderRadius: radius.lg,
    backgroundColor: colors.brand,
    borderWidth: 1,
    borderColor: colors.brandPrimary,
    overflow: "hidden",
    position: "relative",
    minHeight: 92,
  },
  tileIconWrap: {
    width: 56,
    height: 56,
    borderRadius: radius.lg,
    backgroundColor: colors.surface,
    alignItems: "center",
    justifyContent: "center",
    borderWidth: StyleSheet.hairlineWidth,
    borderColor: colors.brandPrimary,
  },
  tileTitle: {
    color: colors.onBrand,
    fontSize: 18,
    fontWeight: "900",
    letterSpacing: 2,
  },
  tileSubtitle: {
    color: colors.onBrand,
    opacity: 0.85,
    fontSize: 12,
    marginTop: 4,
    fontWeight: "600",
  },
  tileCorner: {
    position: "absolute",
    top: 8,
    right: 42,
    opacity: 0.15,
  },
  tileCornerText: {
    color: colors.onBrand,
    fontSize: 42,
    fontWeight: "900",
    letterSpacing: 2,
  },
  footer: {
    alignItems: "center",
    paddingVertical: spacing.lg,
    marginTop: spacing.md,
  },
  footerText: {
    color: colors.brandPrimary,
    fontSize: 11,
    letterSpacing: 3,
    fontWeight: "900",
  },
  footerSubtext: {
    color: colors.onSurfaceSecondary,
    fontSize: 10,
    letterSpacing: 2,
    marginTop: 4,
  },
});
