import React, { useCallback, useEffect, useMemo, useState } from "react";
import {
  View,
  Text,
  StyleSheet,
  Pressable,
  ScrollView,
  ActivityIndicator,
  RefreshControl,
  Modal,
  Alert,
  TextInput,
  Platform,
  useWindowDimensions,
} from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import { useRouter } from "expo-router";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Ionicons } from "@react-native-vector-icons/ionicons";
import { Image } from "expo-image";
import * as ImagePicker from "expo-image-picker";
import * as Haptics from "expo-haptics";

import { apiJson, apiFetch, BACKEND_URL, getToken } from "@/src/api";
import { useAuth } from "@/src/auth-context";
import { colors, spacing, radius } from "@/src/theme";
import ZoomableImage from "@/src/components/zoomable-image";
import LightboxVideoPlayer from "@/src/components/lightbox-video-player";

type MediaItem = {
  id: string;
  year: number;
  album: string;
  caption: string;
  filename: string;
  content_type: string;
  size: number;
  source: string;
  is_private?: boolean;
  is_video?: boolean;
  uploaded_at: string | null;
  order: number;
};

type AlbumSummary = {
  year: number;
  album: string;
  count: number;
  cover_id: string | null;
  source: string;
  latest: string | null;
};

type PrivateListResponse = { photos: MediaItem[]; albums: AlbumSummary[] };

function thumbUrl(photoId: string, pw: string) {
  const token = getToken();
  const tokenPart = token ? `token=${encodeURIComponent(token)}` : "";
  const pwPart = `pw=${encodeURIComponent(pw)}`;
  const qs = [tokenPart, pwPart].filter(Boolean).join("&");
  return `${BACKEND_URL}/api/photos/private/file/${photoId}?${qs}`;
}

export default function PrivatePhotosScreen() {
  const insets = useSafeAreaInsets();
  const router = useRouter();
  const qc = useQueryClient();
  const { width } = useWindowDimensions();
  const { user } = useAuth();
  const isAdmin = user?.role === "admin";
  const isEditor = user?.role === "editor";
  const canEdit = isAdmin || isEditor;

  const [unlocked, setUnlocked] = useState(false);
  const [password, setPassword] = useState("");
  const [pwDraft, setPwDraft] = useState("");
  const [pwError, setPwError] = useState("");
  const [checking, setChecking] = useState(false);
  const [adminPwModal, setAdminPwModal] = useState(false);
  const [newPw, setNewPw] = useState("");
  const [newPw2, setNewPw2] = useState("");
  const [selected, setSelected] = useState<{ year: number; album: string } | null>(null);
  const [lightbox, setLightbox] = useState<{ items: MediaItem[]; index: number } | null>(null);
  const [zoomedLightbox, setZoomedLightbox] = useState(false);
  const [uploadOpen, setUploadOpen] = useState(false);
  const [uploadYear, setUploadYear] = useState(new Date().getFullYear().toString());
  const [uploadAlbum, setUploadAlbum] = useState("");
  const [uploadCaption, setUploadCaption] = useState("");
  const [uploading, setUploading] = useState(false);

  const statusQ = useQuery({
    queryKey: ["private-status"],
    queryFn: async () =>
      await apiJson<{ configured: boolean }>("/photos/private/status"),
  });

  const listQ = useQuery({
    queryKey: ["private-list", selected?.year, selected?.album],
    enabled: unlocked,
    queryFn: async () => {
      const parts: string[] = [];
      if (selected) {
        parts.push(`year=${selected.year}`);
        parts.push(`album=${encodeURIComponent(selected.album)}`);
      }
      const qs = parts.length ? `?${parts.join("&")}` : "";
      return await apiJson<PrivateListResponse>(`/photos/private/list${qs}`, {
        headers: { "X-Private-Password": password },
      });
    },
  });

  // Reset unlock if config missing
  useEffect(() => {
    if (statusQ.data && !statusQ.data.configured) {
      setUnlocked(false);
      setPassword("");
    }
  }, [statusQ.data]);

  const checkPassword = useCallback(async () => {
    const pw = pwDraft.trim();
    if (!pw) return;
    setChecking(true);
    setPwError("");
    try {
      await apiJson(`/photos/private/check`, {
        method: "POST",
        body: JSON.stringify({ password: pw }),
      });
      setPassword(pw);
      setUnlocked(true);
      setPwDraft("");
      try { Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success); } catch {}
    } catch (e: any) {
      setPwError(e?.message || "Password errata");
      try { Haptics.notificationAsync(Haptics.NotificationFeedbackType.Error); } catch {}
    } finally {
      setChecking(false);
    }
  }, [pwDraft]);

  const setPasswordMut = useMutation({
    mutationFn: async (pw: string) =>
      await apiJson(`/photos/private/password`, {
        method: "POST",
        body: JSON.stringify({ password: pw }),
      }),
    onSuccess: () => {
      Alert.alert("Password aggiornata", "La password dell'area privata è stata salvata.");
      setAdminPwModal(false);
      setNewPw("");
      setNewPw2("");
      qc.invalidateQueries({ queryKey: ["private-status"] });
    },
    onError: (e: any) => {
      Alert.alert("Errore", e?.message || "Impossibile salvare la password");
    },
  });

  const columns = width >= 900 ? 5 : width >= 600 ? 4 : 3;
  const gridGap = spacing.sm;
  const horizontalPadding = spacing.lg * 2;
  const tileSize = Math.floor(
    (Math.min(width, 1100) - horizontalPadding - gridGap * (columns - 1)) / columns,
  );

  const items = useMemo(() => listQ.data?.photos || [], [listQ.data]);
  const albums = useMemo(() => listQ.data?.albums || [], [listQ.data]);
  const albumsByYear = useMemo(() => {
    const map = new Map<number, AlbumSummary[]>();
    for (const a of albums) {
      const arr = map.get(a.year) || [];
      arr.push(a);
      map.set(a.year, arr);
    }
    return Array.from(map.entries()).sort((a, b) => b[0] - a[0]);
  }, [albums]);

  const handleUpload = useCallback(async () => {
    const year = parseInt(uploadYear, 10);
    if (!uploadAlbum.trim() || isNaN(year) || year < 1900 || year > 2100) {
      Alert.alert("Dati incompleti", "Compila anno e nome album");
      return;
    }
    try {
      const perm = await ImagePicker.requestMediaLibraryPermissionsAsync();
      if (!perm.granted) {
        if (!perm.canAskAgain) {
          Alert.alert("Permesso negato", "Apri Impostazioni per abilitare l'accesso.");
        }
        return;
      }
      const res = await ImagePicker.launchImageLibraryAsync({
        mediaTypes: ImagePicker.MediaTypeOptions.All,
        allowsMultipleSelection: true,
        selectionLimit: 20,
        quality: 0.85,
        videoMaxDuration: 120,
      });
      if (res.canceled || !res.assets || res.assets.length === 0) return;

      setUploading(true);
      const fd = new FormData();
      fd.append("year", String(year));
      fd.append("album", uploadAlbum.trim());
      if (uploadCaption.trim()) fd.append("caption", uploadCaption.trim());
      for (const a of res.assets) {
        if (Platform.OS === "web") {
          const r = await fetch(a.uri);
          const blob = await r.blob();
          const isVideo = (a.type === "video") || (blob.type || "").startsWith("video/");
          fd.append(
            "files",
            new File(
              [blob],
              a.fileName || `media_${Date.now()}.${isVideo ? "mp4" : "jpg"}`,
              { type: blob.type || (isVideo ? "video/mp4" : "image/jpeg") },
            ),
          );
        } else {
          const isVideo = a.type === "video";
          fd.append("files", {
            uri: a.uri,
            name: a.fileName || `media_${Date.now()}.${isVideo ? "mp4" : "jpg"}`,
            type: a.mimeType || (isVideo ? "video/mp4" : "image/jpeg"),
          } as any);
        }
      }
      const resp = await apiFetch(`/photos/private/upload`, {
        method: "POST",
        body: fd,
        headers: { "X-Private-Password": password },
      });
      if (!resp.ok) {
        const txt = await resp.text().catch(() => "");
        throw new Error(txt || `HTTP ${resp.status}`);
      }
      const json: any = await resp.json();
      Alert.alert("Caricamento riuscito", `${json.inserted} file caricati`);
      setUploadOpen(false);
      setUploadAlbum("");
      setUploadCaption("");
      qc.invalidateQueries({ queryKey: ["private-list"] });
    } catch (e: any) {
      Alert.alert("Errore caricamento", e?.message || "Riprova");
    } finally {
      setUploading(false);
    }
  }, [uploadAlbum, uploadYear, uploadCaption, password, qc]);

  const downloadFile = useCallback(
    async (it: MediaItem) => {
      try {
        if (Platform.OS === "web" && typeof window !== "undefined") {
          const url = thumbUrl(it.id, password);
          const a = window.document.createElement("a");
          a.href = url;
          a.download = it.filename || `media_${it.id}`;
          a.target = "_blank";
          window.document.body.appendChild(a);
          a.click();
          a.remove();
        } else {
          Alert.alert(
            "Download",
            "Il download diretto è disponibile dalla preview web. Usa la condivisione dal lightbox su mobile.",
          );
        }
      } catch (e: any) {
        Alert.alert("Errore", e?.message || "Download fallito");
      }
    },
    [password],
  );

  // ---- UI ----
  if (!statusQ.data) {
    return (
      <View style={[styles.root, styles.center]}>
        <ActivityIndicator color={colors.brandPrimary} size="large" />
      </View>
    );
  }

  if (!statusQ.data.configured) {
    return (
      <View style={[styles.root, { paddingTop: insets.top }]}>
        <View style={styles.header}>
          <Pressable onPress={() => router.back()} style={styles.iconChip} hitSlop={6}>
            <Ionicons name="chevron-back" size={22} color={colors.onSurface} />
          </Pressable>
          <View style={{ flex: 1 }}>
            <Text style={styles.headerLabel}>ARCHIVIO</Text>
            <Text style={styles.headerTitle}>PRIVATO</Text>
          </View>
        </View>
        <View style={[styles.center, { flex: 1, padding: spacing.xl, gap: spacing.md }]}>
          <Ionicons name="lock-open" size={64} color={colors.onSurfaceSecondary} />
          <Text style={styles.gateTitle}>Area privata non ancora attivata</Text>
          <Text style={styles.gateHint}>
            {isAdmin
              ? "Imposta una password condivisa che poi distribuirai agli operatori autorizzati."
              : "Chiedi a un admin di impostare la password dell'area privata."}
          </Text>
          {isAdmin ? (
            <Pressable
              onPress={() => setAdminPwModal(true)}
              style={[styles.gateBtn]}
            >
              <Ionicons name="key" size={16} color={colors.onBrandPrimary} />
              <Text style={styles.gateBtnText}>IMPOSTA PASSWORD</Text>
            </Pressable>
          ) : null}
        </View>
        {renderAdminPwModal()}
      </View>
    );
  }

  if (!unlocked) {
    return (
      <View style={[styles.root, { paddingTop: insets.top }]}>
        <View style={styles.header}>
          <Pressable onPress={() => router.back()} style={styles.iconChip} hitSlop={6}>
            <Ionicons name="chevron-back" size={22} color={colors.onSurface} />
          </Pressable>
          <View style={{ flex: 1 }}>
            <Text style={styles.headerLabel}>ARCHIVIO</Text>
            <Text style={styles.headerTitle}>PRIVATO</Text>
          </View>
          {isAdmin ? (
            <Pressable
              onPress={() => setAdminPwModal(true)}
              style={styles.iconChip}
              hitSlop={6}
            >
              <Ionicons name="settings-outline" size={18} color={colors.brandPrimary} />
            </Pressable>
          ) : null}
        </View>
        <View style={[styles.center, { flex: 1, padding: spacing.xl, gap: spacing.md }]}>
          <Ionicons name="lock-closed" size={64} color={colors.brandPrimary} />
          <Text style={styles.gateTitle}>Area protetta</Text>
          <Text style={styles.gateHint}>
            Inserisci la password condivisa per accedere alle foto e ai video riservati.
          </Text>
          <TextInput
            testID="private-pw-input"
            value={pwDraft}
            onChangeText={(t) => {
              setPwDraft(t);
              setPwError("");
            }}
            placeholder="Password"
            placeholderTextColor={colors.muted}
            style={[styles.input, { minWidth: 260 }]}
            secureTextEntry
            autoCapitalize="none"
            onSubmitEditing={checkPassword}
          />
          {pwError ? <Text style={styles.gateError}>{pwError}</Text> : null}
          <Pressable
            onPress={checkPassword}
            disabled={checking || !pwDraft.trim()}
            style={[styles.gateBtn, (checking || !pwDraft.trim()) && { opacity: 0.5 }]}
          >
            {checking ? (
              <ActivityIndicator color={colors.onBrandPrimary} />
            ) : (
              <>
                <Ionicons name="key" size={16} color={colors.onBrandPrimary} />
                <Text style={styles.gateBtnText}>SBLOCCA</Text>
              </>
            )}
          </Pressable>
        </View>
        {renderAdminPwModal()}
      </View>
    );
  }

  // Unlocked
  const detailTitle = selected ? selected.album : "";
  const detailSubtitle = selected ? `${selected.year}` : "";

  function renderAdminPwModal() {
    return (
      <Modal
        transparent
        visible={adminPwModal}
        animationType="fade"
        onRequestClose={() => setAdminPwModal(false)}
      >
        <View style={styles.modalBackdrop}>
          <View style={styles.modalCard}>
            <View style={styles.modalHeader}>
              <Text style={styles.modalTitle}>PASSWORD AREA PRIVATA</Text>
              <Pressable onPress={() => setAdminPwModal(false)} hitSlop={8}>
                <Ionicons name="close" size={22} color={colors.onSurfaceSecondary} />
              </Pressable>
            </View>
            <Text style={styles.modalHint}>
              Imposta la password condivisa che gli operatori useranno per accedere a foto e
              video riservati. Minimo 4 caratteri.
            </Text>
            <Text style={styles.inputLabel}>NUOVA PASSWORD</Text>
            <TextInput
              value={newPw}
              onChangeText={setNewPw}
              placeholder="Es. furiani2026"
              placeholderTextColor={colors.muted}
              secureTextEntry
              style={styles.input}
              autoCapitalize="none"
            />
            <Text style={styles.inputLabel}>CONFERMA</Text>
            <TextInput
              value={newPw2}
              onChangeText={setNewPw2}
              placeholder="Ripeti password"
              placeholderTextColor={colors.muted}
              secureTextEntry
              style={styles.input}
              autoCapitalize="none"
            />
            <View style={styles.modalActions}>
              <Pressable
                style={[styles.modalBtn, styles.modalBtnGhost]}
                onPress={() => setAdminPwModal(false)}
                disabled={setPasswordMut.isPending}
              >
                <Text style={styles.modalBtnGhostText}>ANNULLA</Text>
              </Pressable>
              <Pressable
                style={[styles.modalBtn, styles.modalBtnPrimary]}
                onPress={() => {
                  if (newPw.length < 4) {
                    Alert.alert("Troppo corta", "Minimo 4 caratteri.");
                    return;
                  }
                  if (newPw !== newPw2) {
                    Alert.alert("Non coincide", "Le due password non coincidono.");
                    return;
                  }
                  setPasswordMut.mutate(newPw);
                }}
                disabled={setPasswordMut.isPending}
              >
                {setPasswordMut.isPending ? (
                  <ActivityIndicator color={colors.onBrandPrimary} />
                ) : (
                  <Text style={styles.modalBtnPrimaryText}>SALVA</Text>
                )}
              </Pressable>
            </View>
          </View>
        </View>
      </Modal>
    );
  }

  return (
    <View style={[styles.root, { paddingTop: insets.top }]} testID="private-photos">
      <View style={styles.header}>
        <Pressable
          onPress={() => (selected ? setSelected(null) : router.back())}
          style={styles.iconChip}
          hitSlop={6}
        >
          <Ionicons name="chevron-back" size={22} color={colors.onSurface} />
        </Pressable>
        <View style={{ flex: 1 }}>
          <Text style={styles.headerLabel}>
            {selected ? detailSubtitle : "ARCHIVIO PRIVATO"}
          </Text>
          <Text style={styles.headerTitle} numberOfLines={1}>
            {selected ? detailTitle : "PRIVATO"}
          </Text>
        </View>
        {isAdmin && !selected ? (
          <Pressable
            onPress={() => setAdminPwModal(true)}
            style={styles.iconChip}
            hitSlop={6}
          >
            <Ionicons name="settings-outline" size={18} color={colors.brandPrimary} />
          </Pressable>
        ) : null}
        {canEdit ? (
          <Pressable
            onPress={() => setUploadOpen(true)}
            style={[styles.iconChip, styles.uploadBtn]}
            hitSlop={6}
          >
            <Ionicons name="cloud-upload" size={18} color={colors.onBrandPrimary} />
          </Pressable>
        ) : null}
      </View>

      <ScrollView
        contentContainerStyle={styles.scrollContent}
        refreshControl={
          <RefreshControl
            refreshing={listQ.isFetching && !listQ.isLoading}
            onRefresh={() => listQ.refetch()}
            tintColor={colors.brandPrimary}
          />
        }
      >
        {listQ.isLoading ? (
          <View style={[styles.center, { paddingVertical: spacing.xxl }]}>
            <ActivityIndicator color={colors.brandPrimary} size="large" />
          </View>
        ) : !selected ? (
          albumsByYear.length === 0 ? (
            <View style={styles.emptyBox}>
              <Ionicons name="lock-closed" size={40} color={colors.onSurfaceSecondary} />
              <Text style={styles.emptyText}>Ancora nessun contenuto riservato</Text>
              {canEdit ? (
                <Text style={styles.emptySubtext}>
                  Tocca &quot;Carica&quot; in alto a destra per aggiungere foto o video
                </Text>
              ) : null}
            </View>
          ) : (
            <View style={{ gap: spacing.lg }}>
              {albumsByYear.map(([year, list]) => (
                <View key={year}>
                  <View style={styles.yearHeaderRow}>
                    <View style={styles.yearBadge}>
                      <Text style={styles.yearBadgeText}>{year}</Text>
                    </View>
                    <Text style={styles.yearHeaderMeta}>
                      {list.reduce((s, a) => s + a.count, 0)} file · {list.length} album
                    </Text>
                  </View>
                  <View style={[styles.grid, { gap: gridGap }]}>
                    {list.map((a) => (
                      <Pressable
                        key={`${a.year}-${a.album}`}
                        onPress={() => setSelected({ year: a.year, album: a.album })}
                        style={({ pressed }) => [
                          styles.albumCard,
                          { width: tileSize, height: tileSize * 1.2 },
                          pressed && { opacity: 0.85 },
                        ]}
                      >
                        {a.cover_id ? (
                          <Image
                            source={{ uri: thumbUrl(a.cover_id, password) }}
                            style={styles.albumCover}
                            contentFit="cover"
                          />
                        ) : (
                          <View style={[styles.albumCover, styles.albumCoverFallback]}>
                            <Ionicons name="lock-closed" size={28} color={colors.onSurfaceSecondary} />
                          </View>
                        )}
                        <View style={styles.albumMeta}>
                          <Text style={styles.albumTitle} numberOfLines={2}>{a.album}</Text>
                          <Text style={styles.albumCount}>{a.count} file</Text>
                        </View>
                      </Pressable>
                    ))}
                  </View>
                </View>
              ))}
            </View>
          )
        ) : (
          <View style={[styles.grid, { gap: gridGap }]}>
            {items.map((p, idx) => (
              <Pressable
                key={p.id}
                onPress={() => setLightbox({ items, index: idx })}
                style={({ pressed }) => [
                  styles.photoThumb,
                  { width: tileSize, height: tileSize },
                  pressed && { opacity: 0.75 },
                ]}
              >
                {p.is_video ? (
                  <View style={[styles.albumCoverFallback, StyleSheet.absoluteFill, { backgroundColor: colors.surfaceSecondary }]}>
                    <Ionicons name="play-circle" size={48} color={colors.brandPrimary} />
                    <Text style={styles.videoLabel} numberOfLines={1}>{p.filename}</Text>
                  </View>
                ) : (
                  <Image
                    source={{ uri: thumbUrl(p.id, password) }}
                    style={StyleSheet.absoluteFill}
                    contentFit="cover"
                    transition={200}
                  />
                )}
              </Pressable>
            ))}
          </View>
        )}
      </ScrollView>

      {/* Lightbox */}
      <Modal
        visible={!!lightbox}
        transparent
        animationType="fade"
        onRequestClose={() => setLightbox(null)}
      >
        {lightbox ? (
          <View style={styles.lightboxRoot}>
            <View style={[styles.lightboxTop, { paddingTop: insets.top + spacing.sm }]}>
              <Text style={styles.lightboxCount}>
                {lightbox.index + 1} / {lightbox.items.length}
              </Text>
              <View style={{ flex: 1 }} />
              <Pressable
                onPress={() => downloadFile(lightbox.items[lightbox.index])}
                style={styles.lightboxBtn}
                hitSlop={6}
              >
                <Ionicons name="download" size={20} color={colors.brandPrimary} />
              </Pressable>
              <Pressable onPress={() => setLightbox(null)} style={styles.lightboxBtn} hitSlop={6}>
                <Ionicons name="close" size={24} color={colors.onSurface} />
              </Pressable>
            </View>
            <View style={styles.lightboxImageWrap}>
              {lightbox.items[lightbox.index].is_video ? (
                <LightboxVideoPlayer
                  key={lightbox.items[lightbox.index].id}
                  uri={thumbUrl(lightbox.items[lightbox.index].id, password)}
                  filename={lightbox.items[lightbox.index].filename}
                />
              ) : (
                <ZoomableImage
                  uri={thumbUrl(lightbox.items[lightbox.index].id, password)}
                  style={styles.lightboxImage}
                  contentFit="contain"
                  onZoomedChange={setZoomedLightbox}
                />
              )}
            </View>
            <View style={[styles.lightboxBottom, { paddingBottom: insets.bottom + spacing.sm }]}>
              <Pressable
                onPress={() =>
                  setLightbox((lb) => (lb ? { ...lb, index: Math.max(0, lb.index - 1) } : lb))
                }
                disabled={lightbox.index === 0 || zoomedLightbox}
                style={[styles.navBtn, (lightbox.index === 0 || zoomedLightbox) && { opacity: 0.3 }]}
                hitSlop={6}
              >
                <Ionicons name="chevron-back" size={28} color={colors.onSurface} />
              </Pressable>
              <View style={{ flex: 1, alignItems: "center" }}>
                <Text style={styles.lightboxAlbum} numberOfLines={1}>
                  {lightbox.items[lightbox.index].album}
                </Text>
                <Text style={styles.lightboxYear}>{lightbox.items[lightbox.index].year}</Text>
                {lightbox.items[lightbox.index].caption ? (
                  <Text style={styles.lightboxCaption} numberOfLines={3}>
                    {lightbox.items[lightbox.index].caption}
                  </Text>
                ) : null}
              </View>
              <Pressable
                onPress={() =>
                  setLightbox((lb) =>
                    lb ? { ...lb, index: Math.min(lb.items.length - 1, lb.index + 1) } : lb,
                  )
                }
                disabled={lightbox.index === lightbox.items.length - 1 || zoomedLightbox}
                style={[
                  styles.navBtn,
                  (lightbox.index === lightbox.items.length - 1 || zoomedLightbox) && { opacity: 0.3 },
                ]}
                hitSlop={6}
              >
                <Ionicons name="chevron-forward" size={28} color={colors.onSurface} />
              </Pressable>
            </View>
          </View>
        ) : null}
      </Modal>

      {/* Upload modal */}
      <Modal
        visible={uploadOpen}
        transparent
        animationType="fade"
        onRequestClose={() => setUploadOpen(false)}
      >
        <View style={styles.modalBackdrop}>
          <View style={styles.modalCard}>
            <View style={styles.modalHeader}>
              <Text style={styles.modalTitle}>CARICA PRIVATO</Text>
              <Pressable onPress={() => setUploadOpen(false)} hitSlop={8}>
                <Ionicons name="close" size={22} color={colors.onSurfaceSecondary} />
              </Pressable>
            </View>
            <Text style={styles.modalHint}>
              Foto E video (max ~200 MB per file). Verranno salvati nell&apos;area privata.
            </Text>
            <Text style={styles.inputLabel}>ANNO</Text>
            <TextInput
              value={uploadYear}
              onChangeText={(t) => setUploadYear(t.replace(/[^0-9]/g, "").slice(0, 4))}
              placeholder="2026"
              placeholderTextColor={colors.muted}
              style={styles.input}
              keyboardType="number-pad"
            />
            <Text style={styles.inputLabel}>NOME ALBUM</Text>
            <TextInput
              value={uploadAlbum}
              onChangeText={setUploadAlbum}
              placeholder="Es. Addestramento 2026"
              placeholderTextColor={colors.muted}
              style={styles.input}
            />
            <Text style={styles.inputLabel}>DIDASCALIA (opz.)</Text>
            <TextInput
              value={uploadCaption}
              onChangeText={setUploadCaption}
              placeholder="Note sul contenuto…"
              placeholderTextColor={colors.muted}
              style={[styles.input, { minHeight: 60, textAlignVertical: "top" }]}
              multiline
            />
            <View style={styles.modalActions}>
              <Pressable
                style={[styles.modalBtn, styles.modalBtnGhost]}
                onPress={() => setUploadOpen(false)}
                disabled={uploading}
              >
                <Text style={styles.modalBtnGhostText}>ANNULLA</Text>
              </Pressable>
              <Pressable
                style={[styles.modalBtn, styles.modalBtnPrimary]}
                onPress={handleUpload}
                disabled={uploading}
              >
                {uploading ? (
                  <ActivityIndicator color={colors.onBrandPrimary} />
                ) : (
                  <View style={{ flexDirection: "row", alignItems: "center", gap: 6 }}>
                    <Ionicons name="cloud-upload" size={14} color={colors.onBrandPrimary} />
                    <Text style={styles.modalBtnPrimaryText}>SCEGLI FILE</Text>
                  </View>
                )}
              </Pressable>
            </View>
          </View>
        </View>
      </Modal>

      {renderAdminPwModal()}
    </View>
  );
}

const styles = StyleSheet.create({
  root: { flex: 1, backgroundColor: colors.surface },
  center: { alignItems: "center", justifyContent: "center" },
  header: {
    flexDirection: "row",
    alignItems: "center",
    gap: spacing.sm,
    paddingHorizontal: spacing.lg,
    paddingVertical: spacing.md,
    borderBottomWidth: StyleSheet.hairlineWidth,
    borderBottomColor: colors.border,
  },
  iconChip: {
    width: 36,
    height: 36,
    borderRadius: radius.lg,
    backgroundColor: colors.surfaceSecondary,
    alignItems: "center",
    justifyContent: "center",
    borderWidth: StyleSheet.hairlineWidth,
    borderColor: colors.border,
  },
  uploadBtn: {
    backgroundColor: colors.brandPrimary,
    borderColor: colors.brandPrimary,
  },
  headerLabel: {
    color: colors.brandPrimary,
    fontSize: 10,
    letterSpacing: 2,
    fontWeight: "800",
  },
  headerTitle: {
    color: colors.onSurface,
    fontSize: 20,
    fontWeight: "900",
    letterSpacing: 1.5,
  },
  gateTitle: {
    color: colors.onSurface,
    fontSize: 18,
    fontWeight: "900",
    letterSpacing: 1,
    textAlign: "center",
  },
  gateHint: {
    color: colors.onSurfaceSecondary,
    fontSize: 13,
    textAlign: "center",
    lineHeight: 18,
    maxWidth: 320,
  },
  gateError: {
    color: colors.error,
    fontSize: 12,
    fontWeight: "800",
  },
  gateBtn: {
    flexDirection: "row",
    alignItems: "center",
    gap: 8,
    paddingHorizontal: spacing.xl,
    paddingVertical: spacing.md,
    borderRadius: radius.pill,
    backgroundColor: colors.brandPrimary,
  },
  gateBtnText: {
    color: colors.onBrandPrimary,
    fontWeight: "900",
    letterSpacing: 2,
    fontSize: 12,
  },

  scrollContent: { padding: spacing.lg, paddingBottom: spacing.xxl },
  grid: { flexDirection: "row", flexWrap: "wrap", alignItems: "flex-start" },

  yearHeaderRow: {
    flexDirection: "row",
    alignItems: "center",
    gap: spacing.sm,
    marginBottom: spacing.sm,
  },
  yearBadge: {
    paddingHorizontal: spacing.md,
    paddingVertical: 4,
    borderRadius: radius.md,
    backgroundColor: colors.brandPrimary,
  },
  yearBadgeText: {
    color: colors.onBrandPrimary,
    fontSize: 14,
    fontWeight: "900",
    letterSpacing: 2,
  },
  yearHeaderMeta: {
    color: colors.onSurfaceSecondary,
    fontSize: 11,
    fontWeight: "700",
  },

  albumCard: {
    borderRadius: radius.lg,
    overflow: "hidden",
    backgroundColor: colors.surfaceSecondary,
    borderWidth: StyleSheet.hairlineWidth,
    borderColor: colors.border,
  },
  albumCover: {
    flex: 1,
    width: "100%",
    backgroundColor: colors.surfaceTertiary,
  },
  albumCoverFallback: { alignItems: "center", justifyContent: "center" },
  albumMeta: { padding: spacing.sm, gap: 4 },
  albumTitle: {
    color: colors.onSurface,
    fontSize: 11,
    fontWeight: "800",
    lineHeight: 14,
  },
  albumCount: {
    color: colors.brandPrimary,
    fontSize: 10,
    fontWeight: "900",
  },

  photoThumb: {
    borderRadius: radius.md,
    overflow: "hidden",
    backgroundColor: colors.surfaceSecondary,
  },
  videoLabel: {
    color: colors.onSurfaceSecondary,
    fontSize: 9,
    textAlign: "center",
    paddingHorizontal: 4,
    marginTop: 4,
  },
  videoHint: {
    color: colors.onSurface,
    fontSize: 13,
    textAlign: "center",
    paddingHorizontal: spacing.xl,
    lineHeight: 18,
  },
  videoFilename: {
    color: colors.onSurfaceSecondary,
    fontSize: 11,
    fontStyle: "italic",
  },

  emptyBox: {
    alignItems: "center",
    paddingVertical: spacing.xxl,
    gap: spacing.sm,
  },
  emptyText: { color: colors.onSurfaceSecondary, fontSize: 14, fontWeight: "700" },
  emptySubtext: {
    color: colors.onSurfaceSecondary,
    fontSize: 11,
    textAlign: "center",
    maxWidth: 280,
  },

  lightboxRoot: { flex: 1, backgroundColor: "rgba(0,0,0,0.95)" },
  lightboxTop: {
    flexDirection: "row",
    alignItems: "center",
    paddingHorizontal: spacing.lg,
    gap: spacing.sm,
  },
  lightboxCount: {
    color: colors.onSurface,
    fontSize: 13,
    fontWeight: "800",
    letterSpacing: 1,
  },
  lightboxBtn: {
    width: 40,
    height: 40,
    borderRadius: 20,
    alignItems: "center",
    justifyContent: "center",
    backgroundColor: "rgba(255,255,255,0.08)",
  },
  lightboxImageWrap: { flex: 1, padding: spacing.sm },
  lightboxImage: { width: "100%", height: "100%" },
  lightboxBottom: {
    flexDirection: "row",
    alignItems: "center",
    paddingHorizontal: spacing.lg,
    paddingTop: spacing.sm,
    gap: spacing.sm,
  },
  navBtn: {
    width: 44,
    height: 44,
    borderRadius: 22,
    alignItems: "center",
    justifyContent: "center",
    backgroundColor: "rgba(255,255,255,0.08)",
  },
  lightboxAlbum: {
    color: colors.onSurface,
    fontSize: 13,
    fontWeight: "800",
    textAlign: "center",
    paddingHorizontal: spacing.sm,
  },
  lightboxYear: {
    color: colors.brandPrimary,
    fontSize: 11,
    fontWeight: "700",
    letterSpacing: 1,
    marginTop: 2,
  },
  lightboxCaption: {
    color: colors.onSurface,
    fontSize: 12,
    marginTop: 6,
    textAlign: "center",
    paddingHorizontal: spacing.sm,
    fontStyle: "italic",
  },

  modalBackdrop: {
    flex: 1,
    backgroundColor: "rgba(0,0,0,0.6)",
    justifyContent: "center",
    alignItems: "center",
    padding: spacing.lg,
  },
  modalCard: {
    backgroundColor: colors.surfaceSecondary,
    borderRadius: radius.lg,
    padding: spacing.lg,
    width: "100%",
    maxWidth: 440,
    borderWidth: StyleSheet.hairlineWidth,
    borderColor: colors.border,
  },
  modalHeader: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
    marginBottom: spacing.sm,
  },
  modalTitle: {
    color: colors.onSurface,
    fontSize: 14,
    fontWeight: "900",
    letterSpacing: 2,
  },
  modalHint: {
    color: colors.onSurfaceSecondary,
    fontSize: 11,
    fontStyle: "italic",
    marginBottom: spacing.md,
  },
  inputLabel: {
    color: colors.brandPrimary,
    fontSize: 10,
    fontWeight: "900",
    letterSpacing: 2,
    marginTop: spacing.sm,
    marginBottom: 4,
  },
  input: {
    backgroundColor: colors.surfaceTertiary,
    borderRadius: radius.lg,
    paddingHorizontal: spacing.md,
    paddingVertical: spacing.sm,
    color: colors.onSurface,
    fontSize: 14,
    borderWidth: StyleSheet.hairlineWidth,
    borderColor: colors.border,
  },
  modalActions: {
    flexDirection: "row",
    gap: spacing.sm,
    marginTop: spacing.lg,
  },
  modalBtn: {
    flex: 1,
    paddingVertical: spacing.md,
    borderRadius: radius.lg,
    alignItems: "center",
    justifyContent: "center",
  },
  modalBtnGhost: {
    backgroundColor: colors.surfaceTertiary,
    borderWidth: StyleSheet.hairlineWidth,
    borderColor: colors.border,
  },
  modalBtnGhostText: {
    color: colors.onSurfaceSecondary,
    fontWeight: "900",
    letterSpacing: 2,
    fontSize: 12,
  },
  modalBtnPrimary: {
    backgroundColor: colors.brandPrimary,
  },
  modalBtnPrimaryText: {
    color: colors.onBrandPrimary,
    fontWeight: "900",
    letterSpacing: 2,
    fontSize: 12,
  },
});
