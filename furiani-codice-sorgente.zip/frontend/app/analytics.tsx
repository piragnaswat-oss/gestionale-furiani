import React, { useEffect, useMemo, useState } from "react";
import { View, Text, StyleSheet, Pressable, ScrollView, ActivityIndicator, RefreshControl } from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import { useRouter } from "expo-router";
import { useQuery } from "@tanstack/react-query";
import { Ionicons } from "@react-native-vector-icons/ionicons";

import { apiJson } from "@/src/api";
import { useAuth } from "@/src/auth-context";
import { colors, spacing, radius } from "@/src/theme";

type Peak = { label: string; count: number };
type Stats = {
  excluded_email: string;
  unique_people: number;
  total_accesses: number;
  peak_weekdays: Peak[];
  peak_hours: Peak[];
  peak_dates: Peak[];
};

const PRESETS = [
  { key: "all", label: "TUTTO" },
  { key: "today", label: "OGGI" },
  { key: "7d", label: "7 GIORNI" },
  { key: "30d", label: "30 GIORNI" },
];

function rangeQs(key: string): string {
  if (key === "all") return "";
  const now = new Date();
  const d = (x: Date) => x.toISOString().slice(0, 10);
  const from = new Date(now);
  if (key === "7d") from.setDate(from.getDate() - 6);
  if (key === "30d") from.setDate(from.getDate() - 29);
  return `?from=${d(from)}&to=${d(now)}`;
}

function fmtDate(iso: string) {
  const [y, m, d] = iso.split("-");
  return d && m && y ? `${d}/${m}/${y}` : iso;
}

export default function AnalyticsScreen() {
  const insets = useSafeAreaInsets();
  const router = useRouter();
  const { user } = useAuth();
  const isAdmin = user?.role === "admin";
  const [preset, setPreset] = useState("all");
  const qs = useMemo(() => rangeQs(preset), [preset]);

  useEffect(() => { if (user && !isAdmin) router.replace("/home"); }, [user, isAdmin, router]);

  const q = useQuery({
    queryKey: ["analytics", "stats", qs],
    queryFn: () => apiJson<Stats>(`/analytics/stats${qs}`),
    enabled: isAdmin,
  });
  const s = q.data;

  return (
    <View style={[styles.root, { paddingTop: insets.top }]} testID="analytics-screen">
      <View style={styles.header}>
        <Pressable testID="back-home" onPress={() => router.push("/home")} style={styles.iconChip} hitSlop={6}>
          <Ionicons name="chevron-back" size={22} color={colors.onSurface} />
        </Pressable>
        <View style={{ flex: 1 }}>
          <Text style={styles.headerLabel}>STATISTICHE ACCESSI</Text>
          <Text style={styles.headerTitle}>CONTAORE</Text>
        </View>
      </View>

      <ScrollView
        contentContainerStyle={{ padding: spacing.lg, gap: spacing.lg, paddingBottom: insets.bottom + spacing.xxl }}
        refreshControl={<RefreshControl refreshing={q.isRefetching} onRefresh={() => q.refetch()} tintColor={colors.brandPrimary} />}
      >
        <View style={styles.presets}>
          {PRESETS.map((p) => {
            const active = preset === p.key;
            return (
              <Pressable key={p.key} testID={`preset-${p.key}`} onPress={() => setPreset(p.key)} style={[styles.chip, active && styles.chipActive]}>
                <Text style={[styles.chipText, active && { color: colors.onBrandPrimary }]}>{p.label}</Text>
              </Pressable>
            );
          })}
        </View>

        {q.isLoading ? (
          <ActivityIndicator color={colors.brandPrimary} style={{ marginTop: spacing.xl }} />
        ) : q.isError || !s ? (
          <Text style={styles.empty} testID="analytics-error">Impossibile caricare le statistiche. Trascina in basso per riprovare.</Text>
        ) : (
          <>
            <View style={styles.counters}>
              <Counter testID="kpi-people" icon="people" value={s.unique_people} label="PERSONE" />
              <Counter testID="kpi-accesses" icon="enter" value={s.total_accesses} label="ACCESSI" />
            </View>

            <PeakCard testID="peak-days" icon="calendar" title="GIORNI DI PUNTA" items={s.peak_weekdays} />
            <PeakCard testID="peak-hours" icon="time" title="ORE DI PUNTA" items={s.peak_hours} />
            <PeakCard testID="peak-dates" icon="flame" title="DATE CON PIÙ ACCESSI" items={s.peak_dates.map((p) => ({ ...p, label: fmtDate(p.label) }))} />

            <Text style={styles.note}>I tuoi accessi da creatore ({s.excluded_email}) non vengono contati.</Text>
          </>
        )}
      </ScrollView>
    </View>
  );
}

function Counter({ icon, value, label, testID }: { icon: string; value: number; label: string; testID: string }) {
  return (
    <View style={styles.counter} testID={testID}>
      <Ionicons name={icon as any} size={22} color={colors.brandPrimary} />
      <Text style={styles.counterValue}>{value}</Text>
      <Text style={styles.counterLabel}>{label}</Text>
    </View>
  );
}

function PeakCard({ icon, title, items, testID }: { icon: string; title: string; items: Peak[]; testID: string }) {
  return (
    <View style={styles.card} testID={testID}>
      <View style={styles.cardHead}>
        <Ionicons name={icon as any} size={16} color={colors.brandPrimary} />
        <Text style={styles.cardTitle}>{title}</Text>
      </View>
      {items.length === 0 ? (
        <Text style={styles.empty}>Nessun accesso nel periodo</Text>
      ) : items.map((p, i) => (
        <View key={p.label} style={styles.peakRow}>
          <Text style={[styles.peakRank, i === 0 && { color: colors.brandPrimary }]}>{i + 1}</Text>
          <Text style={[styles.peakLabel, i === 0 && { fontSize: 18 }]}>{p.label}</Text>
          <Text style={styles.peakCount}>{p.count} accessi</Text>
        </View>
      ))}
    </View>
  );
}

const styles = StyleSheet.create({
  root: { flex: 1, backgroundColor: colors.surface },
  header: {
    flexDirection: "row", alignItems: "center", gap: spacing.md,
    paddingHorizontal: spacing.lg, paddingVertical: spacing.md, borderBottomWidth: 1, borderBottomColor: colors.border,
  },
  headerLabel: { color: colors.brandPrimary, fontSize: 10, letterSpacing: 2, fontWeight: "800" },
  headerTitle: { color: colors.onSurface, fontSize: 22, fontWeight: "900", letterSpacing: 2 },
  iconChip: {
    width: 44, height: 44, borderRadius: radius.sm, backgroundColor: colors.surfaceSecondary,
    alignItems: "center", justifyContent: "center", borderWidth: 1, borderColor: colors.border,
  },
  presets: { flexDirection: "row", flexWrap: "wrap", gap: spacing.sm },
  chip: {
    paddingHorizontal: spacing.md, minHeight: 36, justifyContent: "center", borderRadius: radius.pill,
    backgroundColor: colors.surfaceSecondary, borderWidth: 1, borderColor: colors.border,
  },
  chipActive: { backgroundColor: colors.brandPrimary, borderColor: colors.brandPrimary },
  chipText: { color: colors.onSurfaceSecondary, fontSize: 11, fontWeight: "900", letterSpacing: 1 },
  counters: { flexDirection: "row", gap: spacing.md },
  counter: {
    flex: 1, backgroundColor: colors.brand, borderWidth: 1, borderColor: colors.brandPrimary,
    borderRadius: radius.lg, padding: spacing.lg, alignItems: "center", gap: 4,
  },
  counterValue: { color: colors.onBrand, fontSize: 40, fontWeight: "900" },
  counterLabel: { color: colors.onBrand, opacity: 0.85, fontSize: 11, fontWeight: "800", letterSpacing: 2 },
  card: {
    backgroundColor: colors.surfaceSecondary, borderWidth: 1, borderColor: colors.border,
    borderLeftWidth: 4, borderLeftColor: colors.brandPrimary, borderRadius: radius.sm, padding: spacing.md, gap: spacing.sm,
  },
  cardHead: { flexDirection: "row", alignItems: "center", gap: spacing.sm },
  cardTitle: { color: colors.onSurface, fontSize: 13, fontWeight: "900", letterSpacing: 1.5 },
  peakRow: { flexDirection: "row", alignItems: "center", gap: spacing.md, minHeight: 32 },
  peakRank: { color: colors.muted, fontSize: 14, fontWeight: "900", width: 16 },
  peakLabel: { flex: 1, color: colors.onSurface, fontSize: 15, fontWeight: "800" },
  peakCount: { color: colors.onSurfaceSecondary, fontSize: 12, fontWeight: "700" },
  empty: { color: colors.muted, fontSize: 12, fontStyle: "italic" },
  note: { color: colors.muted, fontSize: 11, textAlign: "center" },
});
