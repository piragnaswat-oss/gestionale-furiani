import React, { useEffect, useState } from "react";
import {
  View, Text, StyleSheet, Pressable, ScrollView, TextInput, ActivityIndicator,
  Platform, Alert, Linking, KeyboardAvoidingView,
} from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import { useRouter } from "expo-router";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { Ionicons } from "@react-native-vector-icons/ionicons";
import * as DocumentPicker from "expo-document-picker";

import { apiJson, apiFetch, BACKEND_URL, getToken } from "@/src/api";
import { useAuth } from "@/src/auth-context";
import { colors, spacing, radius } from "@/src/theme";

type Summary = {
  balance: number; income_annual: number; paid_annual_count: number;
  income_monthly: number; paid_months: number; monthly_fee: number;
  tournaments_total: number; manual_adjustment: number; notes: string;
};
type Tournament = { id: string; name: string; cost: number };
type CassaFile = { file_id: string; filename: string; content_type: string; size: number };

const eur = (n: number) => `${(n || 0).toFixed(2)}€`;
const num = (s: string) => parseFloat((s || "0").replace(",", ".")) || 0;

function confirmAction(msg: string, onYes: () => void) {
  if (Platform.OS === "web") {
    if (typeof window !== "undefined" && window.confirm(msg)) onYes();
    return;
  }
  Alert.alert("Conferma", msg, [
    { text: "Annulla", style: "cancel" },
    { text: "Elimina", style: "destructive", onPress: onYes },
  ]);
}

export default function CassaScreen() {
  const insets = useSafeAreaInsets();
  const router = useRouter();
  const qc = useQueryClient();
  const { user } = useAuth();
  const isAdmin = user?.role === "admin";

  const [notes, setNotes] = useState("");
  const [adj, setAdj] = useState("");
  const [tName, setTName] = useState("");
  const [tCost, setTCost] = useState("");
  const [busy, setBusy] = useState<string | null>(null);
  const [msg, setMsg] = useState<string | null>(null);

  useEffect(() => { if (user && !isAdmin) router.replace("/home"); }, [user, isAdmin, router]);

  const summaryQ = useQuery({ queryKey: ["cassa", "summary"], queryFn: () => apiJson<Summary>("/cassa/summary"), enabled: isAdmin });
  const toursQ = useQuery({ queryKey: ["cassa", "tournaments"], queryFn: async () => (await apiJson<{ tournaments: Tournament[] }>("/cassa/tournaments")).tournaments, enabled: isAdmin });
  const filesQ = useQuery({ queryKey: ["cassa", "files"], queryFn: async () => (await apiJson<{ files: CassaFile[] }>("/cassa/files")).files, enabled: isAdmin });

  useEffect(() => {
    const s = summaryQ.data;
    if (!s) return;
    setNotes(s.notes || "");
    setAdj(s.manual_adjustment ? String(s.manual_adjustment) : "");
  }, [summaryQ.data]);

  const refresh = () => qc.invalidateQueries({ queryKey: ["cassa"] });
  const flash = (m: string) => { setMsg(m); setTimeout(() => setMsg(null), 2500); };

  const run = async (key: string, fn: () => Promise<any>, ok: string) => {
    setBusy(key);
    try { await fn(); refresh(); flash(ok); }
    catch (e: any) { flash(e?.message || "Errore"); }
    finally { setBusy(null); }
  };

  const post = (path: string, body: object) => apiJson(path, { method: "POST", body: JSON.stringify(body) });

  const addTournament = () => {
    if (!tName.trim()) return;
    run("tour", async () => { await post("/cassa/tournaments", { name: tName.trim(), cost: num(tCost) }); setTName(""); setTCost(""); }, "Torneo aggiunto");
  };

  const uploadFile = async () => {
    const result = await DocumentPicker.getDocumentAsync({ type: ["application/pdf", "image/*"], copyToCacheDirectory: true });
    if (result.canceled || !result.assets?.length) return;
    const asset = result.assets[0];
    run("upload", async () => {
      const form = new FormData();
      if (Platform.OS === "web") {
        const b = await (await fetch(asset.uri)).blob();
        form.append("file", b, asset.name || "file");
      } else {
        form.append("file", { uri: asset.uri, name: asset.name || "file", type: asset.mimeType || "application/octet-stream" } as any);
      }
      const res = await apiFetch("/cassa/files", { method: "POST", body: form as any });
      if (!res.ok) throw new Error("Caricamento fallito");
    }, "Documento caricato");
  };

  const openFile = (f: CassaFile) => {
    const url = `${BACKEND_URL}/api/cassa/files/${f.file_id}?token=${encodeURIComponent(getToken() || "")}`;
    if (Platform.OS === "web" && typeof window !== "undefined") window.open(url, "_blank");
    else Linking.openURL(url);
  };

  const s = summaryQ.data;

  return (
    <View style={[styles.root, { paddingTop: insets.top }]} testID="cassa-screen">
      <View style={styles.header}>
        <Pressable testID="back-home" onPress={() => router.push("/home")} style={styles.iconChip} hitSlop={6}>
          <Ionicons name="chevron-back" size={22} color={colors.onSurface} />
        </Pressable>
        <View style={{ flex: 1 }}>
          <Text style={styles.headerLabel}>BILANCIO · TORNEI · DOCUMENTI</Text>
          <Text style={styles.headerTitle}>CASSA SQUADRA</Text>
        </View>
      </View>
      {msg ? <Text style={styles.toast} testID="cassa-toast">{msg}</Text> : null}

      {!s ? (
        <View style={styles.loading}><ActivityIndicator color={colors.brandPrimary} /></View>
      ) : (
        <KeyboardAvoidingView style={{ flex: 1 }} behavior={Platform.OS === "ios" ? "padding" : undefined}>
          <ScrollView contentContainerStyle={{ padding: spacing.lg, gap: spacing.lg, paddingBottom: insets.bottom + spacing.xxl }} keyboardShouldPersistTaps="handled">
            <View style={styles.balance} testID="cassa-balance">
              <Text style={styles.balanceLabel}>CASSA ATTUALE</Text>
              <Text style={styles.balanceValue}>{eur(s.balance)}</Text>
            </View>

            <View style={styles.stats}>
              <Stat label={`TESSERAMENTI ANN. (${s.paid_annual_count})`} value={eur(s.income_annual)} color={colors.success} />
              <Stat label={`MENSILITÀ (${s.paid_months} × ${s.monthly_fee}€)`} value={eur(s.income_monthly)} color={colors.success} />
              <Stat label="SPESE TORNEI" value={`-${eur(s.tournaments_total)}`} color={colors.error} />
              <Stat label="RETTIFICA MANUALE" value={eur(s.manual_adjustment)} color={colors.info} />
            </View>

            <Section title="RETTIFICA MANUALE SALDO">
              <Text style={styles.help}>Aggiungi o sottrai un importo (es. spese extra, contanti) che si somma al saldo calcolato.</Text>
              <View style={styles.inline}>
                <TextInput testID="cassa-adjustment" value={adj} onChangeText={setAdj} placeholder="0 (usa - per sottrarre)" placeholderTextColor={colors.muted} keyboardType="numbers-and-punctuation" style={[styles.input, { flex: 1 }]} />
                <Btn testID="save-adjustment" label="SALVA" loading={busy === "adj"} onPress={() => run("adj", () => post("/cassa/adjustment", { amount: num(adj) }), "Saldo manuale aggiornato")} />
              </View>
            </Section>

            <Section title="TORNEI / SPESE">
              <View style={styles.inline}>
                <TextInput testID="tournament-name" value={tName} onChangeText={setTName} placeholder="Nome torneo" placeholderTextColor={colors.muted} style={[styles.input, { flex: 2 }]} />
                <TextInput testID="tournament-cost" value={tCost} onChangeText={setTCost} placeholder="€" placeholderTextColor={colors.muted} keyboardType="decimal-pad" style={[styles.input, { flex: 1 }]} />
              </View>
              <Btn testID="add-tournament" label="AGGIUNGI" icon="add" loading={busy === "tour"} disabled={!tName.trim()} onPress={addTournament} />
              {(toursQ.data || []).length === 0 ? <Text style={styles.empty}>Nessun torneo registrato</Text> : (toursQ.data || []).map((t) => (
                <View key={t.id} style={styles.item} testID={`tournament-${t.id}`}>
                  <Ionicons name="trophy" size={18} color={colors.brandPrimary} />
                  <Text style={styles.itemName} numberOfLines={1}>{t.name}</Text>
                  <Text style={{ color: colors.error, fontWeight: "900" }}>-{eur(Number(t.cost))}</Text>
                  <Pressable testID={`del-tournament-${t.id}`} hitSlop={8} style={styles.smallBtn}
                    onPress={() => confirmAction(`Rimuovere "${t.name}"?`, () => run("del", () => apiJson(`/cassa/tournaments/${t.id}`, { method: "DELETE" }), "Torneo rimosso"))}>
                    <Ionicons name="trash-outline" size={18} color={colors.error} />
                  </Pressable>
                </View>
              ))}
            </Section>

            <Section title="STORICO CASSA · NOTE A MANO">
              <TextInput testID="cassa-notes" value={notes} onChangeText={setNotes} multiline placeholder="Appunti, storico movimenti, promemoria..." placeholderTextColor={colors.muted} style={[styles.input, { minHeight: 140, textAlignVertical: "top" }]} />
              <Btn testID="save-notes" label="SALVA NOTE" icon="save" loading={busy === "notes"} onPress={() => run("notes", () => post("/cassa/notes", { notes }), "Note salvate")} />
            </Section>

            <Section title="DOCUMENTI (FOTO / PDF)">
              <Btn testID="upload-cassa-file" label="CARICA DOCUMENTO" icon="cloud-upload" loading={busy === "upload"} onPress={uploadFile} />
              {(filesQ.data || []).length === 0 ? <Text style={styles.empty}>Nessun documento</Text> : (filesQ.data || []).map((f) => (
                <View key={f.file_id} style={styles.item} testID={`cassa-file-${f.file_id}`}>
                  <Ionicons name={f.content_type?.startsWith("image/") ? "image" : "document-text"} size={18} color={colors.brandPrimary} />
                  <Text style={styles.itemName} numberOfLines={1}>{f.filename}</Text>
                  <Pressable hitSlop={8} style={styles.smallBtn} onPress={() => openFile(f)} testID={`open-cassa-file-${f.file_id}`}>
                    <Ionicons name="open-outline" size={18} color={colors.onSurface} />
                  </Pressable>
                  <Pressable hitSlop={8} style={styles.smallBtn} testID={`del-cassa-file-${f.file_id}`}
                    onPress={() => confirmAction(`Eliminare "${f.filename}"?`, () => run("delf", () => apiJson(`/cassa/files/${f.file_id}`, { method: "DELETE" }), "Documento eliminato"))}>
                    <Ionicons name="trash-outline" size={18} color={colors.error} />
                  </Pressable>
                </View>
              ))}
            </Section>
          </ScrollView>
        </KeyboardAvoidingView>
      )}
    </View>
  );
}

function Stat({ label, value, color }: { label: string; value: string; color: string }) {
  return (
    <View style={[styles.stat, { borderLeftColor: color }]}>
      <Text style={[styles.statValue, { color }]}>{value}</Text>
      <Text style={styles.statLabel}>{label}</Text>
    </View>
  );
}

function Section({ title, children }: { title: string; children: React.ReactNode }) {
  return (
    <View style={styles.section}>
      <Text style={styles.sectionTitle}>{title}</Text>
      {children}
    </View>
  );
}

function Btn({ label, onPress, testID, icon, loading, disabled }: {
  label: string; onPress: () => void; testID: string; icon?: string; loading?: boolean; disabled?: boolean;
}) {
  return (
    <Pressable testID={testID} onPress={onPress} disabled={disabled || loading} style={[styles.btn, (disabled || loading) && { opacity: 0.6 }]}>
      {loading ? <ActivityIndicator color={colors.onBrandPrimary} /> : (
        <>
          {icon ? <Ionicons name={icon as any} size={16} color={colors.onBrandPrimary} /> : null}
          <Text style={styles.btnText}>{label}</Text>
        </>
      )}
    </Pressable>
  );
}

const styles = StyleSheet.create({
  root: { flex: 1, backgroundColor: colors.surface },
  header: {
    flexDirection: "row", alignItems: "center", gap: spacing.md,
    paddingHorizontal: spacing.lg, paddingVertical: spacing.md, borderBottomWidth: 1, borderBottomColor: colors.border,
  },
  headerLabel: { color: colors.brandPrimary, fontSize: 10, letterSpacing: 2, fontWeight: "800" },
  headerTitle: { color: colors.onSurface, fontSize: 22, fontWeight: "900", letterSpacing: 2 },
  iconChip: {
    width: 44, height: 44, borderRadius: radius.sm, backgroundColor: colors.surfaceSecondary,
    alignItems: "center", justifyContent: "center", borderWidth: 1, borderColor: colors.border,
  },
  toast: { backgroundColor: colors.brandTertiary, color: colors.onBrandTertiary, textAlign: "center", padding: spacing.sm, fontSize: 12, fontWeight: "800" },
  loading: { flex: 1, alignItems: "center", justifyContent: "center" },
  balance: { backgroundColor: colors.brand, borderWidth: 1, borderColor: colors.brandPrimary, borderRadius: radius.lg, padding: spacing.xl, alignItems: "center" },
  balanceLabel: { color: colors.onBrand, opacity: 0.8, fontSize: 12, letterSpacing: 2, fontWeight: "800" },
  balanceValue: { color: colors.onBrand, fontSize: 44, fontWeight: "900" },
  stats: { flexDirection: "row", flexWrap: "wrap", gap: spacing.md },
  stat: {
    flexGrow: 1, flexBasis: "45%", backgroundColor: colors.surfaceSecondary, borderWidth: 1, borderColor: colors.border,
    borderLeftWidth: 4, borderRadius: radius.sm, padding: spacing.md,
  },
  statValue: { fontSize: 20, fontWeight: "900" },
  statLabel: { color: colors.onSurfaceSecondary, fontSize: 10, letterSpacing: 1.5, fontWeight: "700", marginTop: 2 },
  section: { backgroundColor: colors.surfaceSecondary, borderWidth: 1, borderColor: colors.border, borderRadius: radius.sm, padding: spacing.lg, gap: spacing.sm },
  sectionTitle: { color: colors.onSurface, fontSize: 15, fontWeight: "900", letterSpacing: 1 },
  help: { color: colors.onSurfaceSecondary, fontSize: 12 },
  inline: { flexDirection: "row", gap: spacing.sm, alignItems: "center" },
  input: {
    color: colors.onSurface, fontSize: 15, backgroundColor: colors.surfaceTertiary, paddingHorizontal: spacing.md,
    minHeight: 44, paddingVertical: spacing.sm, borderRadius: radius.sm, borderWidth: 1, borderColor: colors.border,
  },
  btn: {
    flexDirection: "row", gap: spacing.sm, alignItems: "center", justifyContent: "center", minHeight: 44,
    paddingHorizontal: spacing.lg, backgroundColor: colors.brandPrimary, borderRadius: radius.sm,
  },
  btnText: { color: colors.onBrandPrimary, fontWeight: "900", letterSpacing: 1.5, fontSize: 12 },
  empty: { color: colors.muted, fontSize: 12, fontStyle: "italic", textAlign: "center", paddingVertical: spacing.md },
  item: {
    flexDirection: "row", alignItems: "center", gap: spacing.md, backgroundColor: colors.surfaceTertiary,
    borderWidth: 1, borderColor: colors.border, borderRadius: radius.sm, paddingHorizontal: spacing.md, minHeight: 48,
  },
  itemName: { flex: 1, color: colors.onSurface, fontSize: 14, fontWeight: "700" },
  smallBtn: { width: 36, height: 36, alignItems: "center", justifyContent: "center" },
});
