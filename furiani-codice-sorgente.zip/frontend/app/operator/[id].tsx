import React, { useMemo, useState, useCallback } from "react";
import {
  View,
  Text,
  StyleSheet,
  Pressable,
  ScrollView,
  ActivityIndicator,
  TextInput,
  KeyboardAvoidingView,
  Platform,
  Alert,
} from "react-native";
import { Image } from "expo-image";
import { LinearGradient } from "expo-linear-gradient";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import { useLocalSearchParams, useRouter } from "expo-router";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Ionicons } from "@react-native-vector-icons/ionicons";
import * as DocumentPicker from "expo-document-picker";
import * as Haptics from "expo-haptics";

import { apiJson, apiFetch, BACKEND_URL, getToken } from "@/src/api";
import { colors, spacing, radius } from "@/src/theme";
import { useAuth } from "@/src/auth-context";
import {
  generateSeasonMonths,
  generateSeasonMonthList,
  isPastDate,
  isToday,
  isCurrentOrPastMonth,
} from "@/src/calendar";

const COVER =
  "https://images.unsplash.com/photo-1673083424160-4bf59a6145c3?crop=entropy&cs=srgb&fm=jpg&ixid=M3w4NjA1Mjh8MHwxfHNlYXJjaHwyfHxkYXJrJTIwbWlsaXRhcnklMjBjYW1vJTIwdGV4dHVyZXxlbnwwfHx8fDE3ODk5NjgwMDJ8MA&ixlib=rb-4.1.0&q=85";

type Operator = {
  id: string;
  battle_name: string;
  real_name: string;
  phone: string;
  rank: string;
  department: string;
  behavioral_notes: string;
  annual_fee_paid: boolean;
  annual_fee_amount: number;
  medical_pdfs: PdfInfo[];
  insurance_pdfs: PdfInfo[];
  medical_pdf: PdfInfo | null;
  insurance_pdf: PdfInfo | null;
};

type PdfInfo = {
  file_id?: string;
  path: string;
  filename: string;
  content_type?: string;
  size: number;
  uploaded_at: string;
};

type AttendanceStatus = "present" | "rest" | "absent";
type AttendanceRec = { date: string; present: boolean; status?: AttendanceStatus };
type PaymentRec = { month: string; paid: boolean };

type TabKey = "medical" | "insurance" | "fitness" | "fitness" | "calendar" | "payment" | "notes";

const TABS: { key: TabKey; label: string; icon: string }[] = [
  { key: "medical", label: "MEDICA", icon: "medkit" },
  { key: "insurance", label: "ASSICURAZ.", icon: "shield-checkmark" },
  { key: "fitness", label: "PROVA FISICA", icon: "fitness" },
  { key: "calendar", label: "PRESENZE", icon: "calendar" },
  { key: "payment", label: "TESSERAM.", icon: "card" },
  { key: "notes", label: "NOTE", icon: "reader" },
];

const MONTHLY_FEE = 10;

export default function OperatorDetail() {
  const { id } = useLocalSearchParams<{ id: string }>();
  const insets = useSafeAreaInsets();
  const router = useRouter();
  const qc = useQueryClient();
  const { user } = useAuth();
  const isAdmin = user?.role === "admin";
  const isEditor = user?.role === "editor";
  const isViewer = user?.role === "viewer";
  const [tab, setTab] = useState<TabKey>("medical");
  const [notes, setNotes] = useState<string>("");
  const [savingNotes, setSavingNotes] = useState(false);
  const [uploadingKind, setUploadingKind] = useState<"medical" | "insurance" | "fitness" | null>(null);

  const opQ = useQuery<Operator>({
    queryKey: ["operator", id],
    queryFn: () => apiJson<Operator>(`/operators/${id}`),
    enabled: !!id,
  });

  const attQ = useQuery<{ records: AttendanceRec[] }>({
    queryKey: ["attendance", id],
    queryFn: () => apiJson(`/operators/${id}/attendance`),
    enabled: !!id,
  });

  const payQ = useQuery<{ records: PaymentRec[] }>({
    queryKey: ["payments", id],
    queryFn: () => apiJson(`/operators/${id}/payments`),
    enabled: !!id,
  });

  React.useEffect(() => {
    if (opQ.data) setNotes(opQ.data.behavioral_notes || "");
  }, [opQ.data]);

  const toggleAtt = useMutation({
    mutationFn: async (payload: { date: string; status: AttendanceStatus }) =>
      apiJson(`/operators/${id}/attendance`, {
        method: "POST",
        body: JSON.stringify({
          date: payload.date,
          status: payload.status,
          present: payload.status === "present",
        }),
      }),
    onMutate: async (payload) => {
      await qc.cancelQueries({ queryKey: ["attendance", id] });
      const prev = qc.getQueryData<{ records: AttendanceRec[] }>(["attendance", id]);
      qc.setQueryData<{ records: AttendanceRec[] }>(["attendance", id], (old) => {
        const records = old?.records ? [...old.records] : [];
        const idx = records.findIndex((r) => r.date === payload.date);
        if (payload.status === "absent") {
          if (idx >= 0) records.splice(idx, 1);
        } else {
          const rec: AttendanceRec = {
            date: payload.date,
            present: payload.status === "present",
            status: payload.status,
          };
          if (idx >= 0) records[idx] = rec;
          else records.push(rec);
        }
        return { records };
      });
      return { prev };
    },
    onError: (_e, _v, ctx) => {
      if (ctx?.prev) qc.setQueryData(["attendance", id], ctx.prev);
    },
    onSettled: () => qc.invalidateQueries({ queryKey: ["attendance", id] }),
  });

  const togglePay = useMutation({
    mutationFn: async (payload: { month: string; paid: boolean }) =>
      apiJson(`/operators/${id}/payments`, {
        method: "POST",
        body: JSON.stringify(payload),
      }),
    onMutate: async (payload) => {
      await qc.cancelQueries({ queryKey: ["payments", id] });
      const prev = qc.getQueryData<{ records: PaymentRec[] }>(["payments", id]);
      qc.setQueryData<{ records: PaymentRec[] }>(["payments", id], (old) => {
        const records = old?.records ? [...old.records] : [];
        const idx = records.findIndex((r) => r.month === payload.month);
        if (idx >= 0) records[idx] = { month: payload.month, paid: payload.paid };
        else records.push({ month: payload.month, paid: payload.paid });
        return { records };
      });
      return { prev };
    },
    onError: (_e, _v, ctx) => {
      if (ctx?.prev) qc.setQueryData(["payments", id], ctx.prev);
    },
    onSettled: () => qc.invalidateQueries({ queryKey: ["payments", id] }),
  });

  const saveNotesMut = useMutation({
    mutationFn: async (text: string) =>
      apiJson(`/operators/${id}`, {
        method: "PATCH",
        body: JSON.stringify({ behavioral_notes: text }),
      }),
    onSuccess: () => qc.invalidateQueries({ queryKey: ["operator", id] }),
  });

  const updateOpMut = useMutation({
    mutationFn: async (patch: Record<string, unknown>) =>
      apiJson(`/operators/${id}`, {
        method: "PATCH",
        body: JSON.stringify(patch),
      }),
    onMutate: async (patch) => {
      await qc.cancelQueries({ queryKey: ["operator", id] });
      const prev = qc.getQueryData<Operator>(["operator", id]);
      qc.setQueryData<Operator | undefined>(["operator", id], (old) =>
        old ? ({ ...old, ...patch } as Operator) : old,
      );
      return { prev };
    },
    onError: (_e, _v, ctx) => {
      if (ctx?.prev) qc.setQueryData(["operator", id], ctx.prev);
    },
    onSettled: () => {
      qc.invalidateQueries({ queryKey: ["operator", id] });
      qc.invalidateQueries({ queryKey: ["operators"] });
    },
  });

  const roleInfoQ = useQuery({
    queryKey: ["operator-role-info", id],
    queryFn: async () =>
      apiJson<{ email: string; has_account: boolean; role: "admin" | "member" | null }>(
        `/operators/${id}/role-info`,
      ),
    enabled: !!id,
  });

  const promoteMut = useMutation({
    mutationFn: async () =>
      apiJson(`/operators/${id}/promote`, { method: "POST", body: "{}" }),
    onSuccess: () => {
      Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
      qc.invalidateQueries({ queryKey: ["operator-role-info", id] });
    },
  });

  const demoteMut = useMutation({
    mutationFn: async () =>
      apiJson(`/operators/${id}/demote`, { method: "POST", body: "{}" }),
    onSuccess: () => {
      Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
      qc.invalidateQueries({ queryKey: ["operator-role-info", id] });
    },
  });

  const deleteMut = useMutation({
    mutationFn: async () => apiJson(`/operators/${id}`, { method: "DELETE" }),
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ["operators"] });
      router.back();
    },
  });

  const attMap = useMemo(() => {
    const map = new Map<string, AttendanceStatus>();
    (attQ.data?.records || []).forEach((r) => {
      const s: AttendanceStatus =
        r.status === "rest" || r.status === "present" || r.status === "absent"
          ? r.status
          : r.present
          ? "present"
          : "absent";
      if (s !== "absent") map.set(r.date, s);
    });
    return map;
  }, [attQ.data]);

  const payMap = useMemo(() => {
    const map = new Map<string, boolean>();
    (payQ.data?.records || []).forEach((r) => map.set(r.month, r.paid));
    return map;
  }, [payQ.data]);

  const months = useMemo(() => generateSeasonMonths(), []);
  const monthList = useMemo(() => generateSeasonMonthList(), []);

  const [showSaturdays, setShowSaturdays] = useState(false);

  const attCounters = useMemo(() => {
    let sundayPresent = 0;
    let saturdayPresent = 0;
    let absent = 0;
    let rest = 0;
    for (const m of months) {
      for (const d of m.days) {
        const status = attMap.get(d.date);
        const isPresent = status === "present";
        const isRest = status === "rest";
        if (d.dow === 0) {
          if (isPresent) sundayPresent += 1;
          else if (isRest) rest += 1;
          else if (isPastDate(d.date)) absent += 1;
        } else if (d.dow === 6) {
          if (isPresent) saturdayPresent += 1;
          else if (isRest) rest += 1;
          // Saturdays are optional: never counted as "assenze"
        }
      }
    }
    return { sundayPresent, saturdayPresent, absent, rest };
  }, [months, attMap]);

  const payCounters = useMemo(() => {
    let paid = 0;
    let unpaid = 0;
    for (const m of monthList) {
      if (payMap.get(m.key)) paid += 1;
      else if (isCurrentOrPastMonth(m.key)) unpaid += 1;
    }
    return { paid, unpaid };
  }, [monthList, payMap]);

  const pickPdf = useCallback(
    async (kind: "medical" | "insurance" | "fitness") => {
      try {
        const result = await DocumentPicker.getDocumentAsync({
          type: [
            "application/pdf",
            "image/*",
            "application/msword",
            "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
            "application/vnd.ms-excel",
            "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
            "text/plain",
          ],
          copyToCacheDirectory: true,
          multiple: false,
        });
        if (result.canceled || !result.assets || result.assets.length === 0) return;
        const asset = result.assets[0];
        setUploadingKind(kind);
        const form = new FormData();
        form.append("kind", kind);
        if (Platform.OS === "web") {
          const resp = await fetch(asset.uri);
          const blob = await resp.blob();
          form.append("file", blob, asset.name || "file");
        } else {
          form.append("file", {
            uri: asset.uri,
            name: asset.name || "file",
            type: asset.mimeType || "application/octet-stream",
          } as any);
        }
        const res = await apiFetch(`/operators/${id}/upload`, {
          method: "POST",
          body: form as any,
        });
        if (!res.ok) throw new Error(`Upload failed: ${res.status}`);
        Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Heavy);
        qc.invalidateQueries({ queryKey: ["operator", id] });
      } catch (e: any) {
        Alert.alert("Errore", e?.message || "Upload fallito");
      } finally {
        setUploadingKind(null);
      }
    },
    [id, qc],
  );

  const openPdf = useCallback(
    async (kind: "medical" | "insurance" | "fitness", fileId?: string) => {
      let title = kind.toUpperCase();
      const list =
        kind === "medical"
          ? opQ.data?.medical_pdfs
          : kind === "insurance"
          ? opQ.data?.insurance_pdfs
          : opQ.data?.fitness_pdfs;
      if (list && list.length > 0) {
        const match = fileId ? list.find((it) => it.file_id === fileId) : list[0];
        if (match?.filename) title = match.filename;
      }
      router.push({
        pathname: "/pdf-viewer",
        params: {
          opId: id,
          kind,
          fileId: fileId || "",
          title: encodeURIComponent(title),
          token: getToken() || "",
        },
      });
    },
    [id, opQ.data, router],
  );

  const deletePdfMut = useMutation({
    mutationFn: async ({ kind, fileId }: { kind: "medical" | "insurance" | "fitness"; fileId?: string }) => {
      const q = new URLSearchParams({ kind });
      if (fileId) q.set("file_id", fileId);
      return apiFetch(`/operators/${id}/upload?${q.toString()}`, { method: "DELETE" });
    },
    onSuccess: () => {
      Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
      qc.invalidateQueries({ queryKey: ["operator", id] });
      qc.invalidateQueries({ queryKey: ["operators"] });
    },
  });

  const confirmDeletePdf = useCallback(
    (kind: "medical" | "insurance" | "fitness", fileId?: string) => {
      const doIt = () => deletePdfMut.mutate({ kind, fileId });
      const msg = "Rimuovere questo documento?";
      if (Platform.OS === "web") {
        if (typeof window !== "undefined" && window.confirm(msg)) doIt();
      } else {
        Alert.alert("Rimuovi PDF", msg, [
          { text: "Annulla", style: "cancel" },
          { text: "Rimuovi", style: "destructive", onPress: doIt },
        ]);
      }
    },
    [deletePdfMut],
  );

  const op = opQ.data;

  return (
    <View style={styles.root} testID="operator-detail-screen">
      {/* Cover */}
      <View style={styles.cover}>
        <Image source={{ uri: COVER }} style={StyleSheet.absoluteFillObject} contentFit="cover" />
        <LinearGradient
          colors={["rgba(16,18,16,0.3)", "rgba(16,18,16,0.85)", "#101210"]}
          style={StyleSheet.absoluteFillObject}
        />
        <View style={[styles.coverTop, { paddingTop: insets.top + spacing.sm }]}>
          <Pressable testID="back-button" onPress={() => router.back()} style={styles.iconChip}>
            <Ionicons name="chevron-back" size={22} color={colors.onSurface} />
          </Pressable>
          {isAdmin ? (
            <Pressable
              testID="delete-operator"
              onPress={() => {
                if (Platform.OS === "web") {
                  if (confirm("Eliminare questo operatore?")) deleteMut.mutate();
                } else {
                  Alert.alert("Elimina operatore", "Sei sicuro?", [
                    { text: "Annulla", style: "cancel" },
                    { text: "Elimina", style: "destructive", onPress: () => deleteMut.mutate() },
                  ]);
                }
              }}
              style={styles.iconChip}
            >
              <Ionicons name="trash-outline" size={20} color={colors.error} />
            </Pressable>
          ) : (
            <View style={styles.iconChip}>
              <Ionicons name="lock-closed" size={16} color={colors.muted} />
            </View>
          )}
        </View>
        <View style={styles.coverBottom}>
          <Text style={styles.coverDept}>{op?.department || "630 ROCS"}</Text>
          {op?.rank ? (
            <Text style={styles.coverRank} testID="cover-rank">
              {op.rank.toUpperCase()}
            </Text>
          ) : null}
          <Text style={styles.coverTitle} numberOfLines={2}>
            {(op?.battle_name || "").toUpperCase() || "..."}
          </Text>
          {op?.real_name ? <Text style={styles.coverSub}>{op.real_name}</Text> : null}
          {op?.phone ? (
            <View style={styles.phoneRow}>
              <Ionicons name="call" size={13} color={colors.brandPrimary} />
              <Text style={styles.phoneText}>{op.phone}</Text>
            </View>
          ) : null}
          <View style={styles.presenceBadgeRow}>
            <View style={styles.presenceBadge} testID="total-presenze-badge">
              <Ionicons name="checkmark-done" size={14} color={colors.onBrandPrimary} />
              <Text style={styles.presenceBadgeNum}>
                {attCounters.sundayPresent + attCounters.saturdayPresent}
              </Text>
              <Text style={styles.presenceBadgeLabel}>TOT. PRESENZE</Text>
            </View>
            {attCounters.rest > 0 ? (
              <View style={[styles.presenceBadge, styles.presenceBadgeRest]}>
                <Ionicons name="bed-outline" size={13} color={colors.onSurface} />
                <Text style={[styles.presenceBadgeNum, { color: colors.onSurface }]}>
                  {attCounters.rest}
                </Text>
                <Text style={[styles.presenceBadgeLabel, { color: colors.onSurface }]}>
                  RIPOSO
                </Text>
              </View>
            ) : null}
          </View>
        </View>
      </View>

      {/* Tabs — always fully visible, no horizontal scroll */}
      <View style={styles.tabsRow}>
        {TABS.map((t) => {
          const active = tab === t.key;
          return (
            <Pressable
              key={t.key}
              testID={`tab-${t.key}`}
              onPress={() => setTab(t.key)}
              style={[styles.tab, active && styles.tabActive]}
            >
              <Ionicons
                name={t.icon as any}
                size={14}
                color={active ? colors.onBrandPrimary : colors.onSurfaceSecondary}
              />
              <Text style={[styles.tabText, active && styles.tabTextActive]}>{t.label}</Text>
            </Pressable>
          );
        })}
      </View>

      {opQ.isLoading ? (
        <View style={styles.loading}>
          <ActivityIndicator color={colors.brandPrimary} />
        </View>
      ) : (
        <>
          {tab === "medical" && (
            <PdfTab
              kind="medical"
              title="VISITA MEDICA"
              items={op?.medical_pdfs || []}
              onPick={() => pickPdf("medical")}
              onOpen={(fileId) => openPdf("medical", fileId)}
              onRemove={(fileId) => confirmDeletePdf("medical", fileId)}
              removing={deletePdfMut.isPending}
              busy={uploadingKind === "medical"}
              canEdit={isAdmin}
              canOpen={isAdmin || isEditor}
              bottomInset={insets.bottom}
            />
          )}
          {tab === "insurance" && (
            <PdfTab
              kind="insurance"
              title="DATI ASSICURATIVI"
              items={op?.insurance_pdfs || []}
              onPick={() => pickPdf("insurance")}
              onOpen={(fileId) => openPdf("insurance", fileId)}
              onRemove={(fileId) => confirmDeletePdf("insurance", fileId)}
              removing={deletePdfMut.isPending}
              busy={uploadingKind === "insurance"}
              canEdit={isAdmin}
              canOpen={isAdmin || isEditor}
              bottomInset={insets.bottom}
            />
          )}
          {tab === "fitness" && (
            <PdfTab
              kind="fitness"
              title="PROVA FISICA"
              items={op?.fitness_pdfs || []}
              onPick={() => pickPdf("fitness")}
              onOpen={(fileId) => openPdf("fitness", fileId)}
              onRemove={(fileId) => confirmDeletePdf("fitness", fileId)}
              removing={deletePdfMut.isPending}
              busy={uploadingKind === "fitness"}
              canEdit={isAdmin}
              canOpen={isAdmin || isEditor || isViewer}
              bottomInset={insets.bottom}
            />
          )}
          {tab === "calendar" && (
            <CalendarTab
              months={months}
              attMap={attMap}
              onCycle={(date) => {
                if (!isAdmin) return;
                const current = attMap.get(date);
                let next: AttendanceStatus;
                if (!current) next = "present";
                else if (current === "present") next = "rest";
                else next = "absent";
                Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Medium);
                toggleAtt.mutate({ date, status: next });
              }}
              counters={attCounters}
              canEdit={isAdmin}
              bottomInset={insets.bottom}
              showSaturdays={showSaturdays}
              onToggleSaturdays={setShowSaturdays}
            />
          )}
          {tab === "payment" && (
            <PaymentTab
              months={monthList}
              payMap={payMap}
              onToggle={(month, paid) => {
                if (!isAdmin) return;
                Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Medium);
                togglePay.mutate({ month, paid });
              }}
              counters={payCounters}
              annualPaid={!!op?.annual_fee_paid}
              annualAmount={op?.annual_fee_amount || 0}
              onAnnualToggle={(paid) => {
                if (!isAdmin) return;
                Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Medium);
                updateOpMut.mutate({ annual_fee_paid: paid });
              }}
              onAnnualAmountSave={(amount) => {
                if (!isAdmin) return;
                updateOpMut.mutate({ annual_fee_amount: amount });
              }}
              canEdit={isAdmin}
              bottomInset={insets.bottom}
            />
          )}
          {tab === "notes" && (
            <NotesTab
              value={notes}
              setValue={setNotes}
              onSave={async () => {
                if (!isAdmin) return;
                setSavingNotes(true);
                try {
                  await saveNotesMut.mutateAsync(notes);
                  Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
                } catch {}
                setSavingNotes(false);
              }}
              saving={savingNotes}
              canEdit={isAdmin}
              bottomInset={insets.bottom}
            />
          )}
        </>
      )}
    </View>
  );
}

function PdfTab({
  kind,
  title,
  items,
  onPick,
  onOpen,
  onRemove,
  removing,
  busy,
  canEdit,
  canOpen,
  bottomInset,
}: {
  kind: "medical" | "insurance" | "fitness";
  title: string;
  items: PdfInfo[];
  onPick: () => void;
  onOpen: (fileId?: string) => void;
  onRemove: (fileId?: string) => void;
  removing: boolean;
  busy: boolean;
  canEdit: boolean;
  canOpen?: boolean;
  bottomInset: number;
}) {
  const canViewFile = canOpen ?? canEdit;
  return (
    <ScrollView
      contentContainerStyle={[styles.tabContent, { paddingBottom: bottomInset + spacing.xl }]}
      testID={`pdf-tab-${kind}`}
    >
      <Text style={styles.sectionTitle}>{title}</Text>
      <Text style={styles.sectionHelp}>
        {canEdit
          ? "Puoi caricare più documenti. Ogni PDF può essere aperto o rimosso singolarmente."
          : canViewFile
          ? "Tocca il pulsante per aprire il documento in una nuova scheda."
          : "Elenco dei documenti caricati (sola lettura)."}
      </Text>

      {items.length > 0 ? (
        <View style={{ gap: spacing.sm, marginTop: spacing.sm }}>
          {items.map((info) => (
            <View style={styles.fileCard} key={info.file_id || info.path} testID={`pdf-file-card-${kind}-${info.file_id || "single"}`}>
              <View style={styles.fileIconBox}>
                <Ionicons name="document-text" size={26} color={colors.brandPrimary} />
              </View>
              <View style={{ flex: 1 }}>
                <Text style={styles.fileName} numberOfLines={1}>
                  {info.filename}
                </Text>
                <Text style={styles.fileMeta}>
                  {(info.size / 1024).toFixed(1)} KB · {new Date(info.uploaded_at).toLocaleDateString("it-IT")}
                </Text>
              </View>
              <Pressable
                onPress={() => onOpen(info.file_id)}
                style={styles.openBtn}
                testID={`open-pdf-${kind}-${info.file_id || "single"}`}
                hitSlop={6}
                disabled={!canViewFile}
              >
                <Ionicons
                  name={canViewFile ? "open-outline" : "lock-closed"}
                  size={18}
                  color={canViewFile ? colors.onSurface : colors.muted}
                />
              </Pressable>
              {canEdit ? (
                <Pressable
                  onPress={() => onRemove(info.file_id)}
                  disabled={removing}
                  style={styles.openBtn}
                  testID={`remove-pdf-${kind}-${info.file_id || "single"}`}
                  hitSlop={6}
                >
                  <Ionicons name="trash-outline" size={18} color={colors.error} />
                </Pressable>
              ) : null}
            </View>
          ))}
        </View>
      ) : (
        <View style={styles.emptyBox}>
          <Ionicons name="cloud-upload-outline" size={40} color={colors.muted} />
          <Text style={styles.emptyText}>Nessun documento caricato</Text>
        </View>
      )}

      {canEdit ? (
        <Pressable
          testID={`upload-pdf-${kind}`}
          onPress={onPick}
          disabled={busy || removing}
          style={({ pressed }) => [
            styles.uploadBtn,
            pressed && { opacity: 0.85 },
            (busy || removing) && { opacity: 0.6 },
          ]}
        >
          {busy ? (
            <ActivityIndicator color={colors.onBrandPrimary} />
          ) : (
            <>
              <Ionicons name="cloud-upload" size={18} color={colors.onBrandPrimary} />
              <Text style={styles.uploadText}>
                {items.length > 0 ? "AGGIUNGI ALTRO PDF" : "CARICA PDF"}
              </Text>
            </>
          )}
        </Pressable>
      ) : null}
    </ScrollView>
  );
}

function CalendarTab({
  months,
  attMap,
  onCycle,
  counters,
  canEdit,
  bottomInset,
  showSaturdays,
  onToggleSaturdays,
}: {
  months: ReturnType<typeof generateSeasonMonths>;
  attMap: Map<string, AttendanceStatus>;
  onCycle: (date: string) => void;
  counters: { sundayPresent: number; saturdayPresent: number; absent: number; rest: number };
  canEdit: boolean;
  bottomInset: number;
  showSaturdays: boolean;
  onToggleSaturdays: (v: boolean) => void;
}) {
  return (
    <ScrollView
      contentContainerStyle={[styles.tabContent, { paddingBottom: bottomInset + spacing.xl }]}
      testID="calendar-tab"
    >
      <View style={styles.metricsRow}>
        <View style={[styles.metric, { borderLeftColor: colors.brandPrimary }]}>
          <Text style={styles.metricNum}>{counters.sundayPresent}</Text>
          <Text style={styles.metricLabel}>DOMENICHE</Text>
        </View>
        {showSaturdays ? (
          <View style={[styles.metric, { borderLeftColor: colors.info }]}>
            <Text style={[styles.metricNum, { color: colors.info }]}>{counters.saturdayPresent}</Text>
            <Text style={styles.metricLabel}>SABATI</Text>
          </View>
        ) : null}
        <View style={[styles.metric, { borderLeftColor: colors.warning }]}>
          <Text style={[styles.metricNum, { color: colors.warning }]}>{counters.rest}</Text>
          <Text style={styles.metricLabel}>RIPOSO</Text>
        </View>
        <View style={[styles.metric, { borderLeftColor: colors.error }]}>
          <Text style={[styles.metricNum, { color: colors.error }]}>{counters.absent}</Text>
          <Text style={styles.metricLabel}>ASSENZE</Text>
        </View>
      </View>

      <Pressable
        testID="toggle-saturdays"
        onPress={() => onToggleSaturdays(!showSaturdays)}
        style={({ pressed }) => [
          styles.satToggle,
          showSaturdays && styles.satToggleActive,
          pressed && { opacity: 0.85 },
        ]}
      >
        <Ionicons
          name={showSaturdays ? "checkbox" : "square-outline"}
          size={16}
          color={showSaturdays ? colors.onBrandPrimary : colors.onSurface}
        />
        <Text
          style={[styles.satToggleText, showSaturdays && { color: colors.onBrandPrimary }]}
        >
          {showSaturdays ? "SABATI ATTIVI" : "ATTIVA SABATI"}
        </Text>
      </Pressable>

      <Text style={styles.legend}>
        <Text style={{ color: colors.brandPrimary }}>■ Verde</Text> = Presente ·{" "}
        <Text style={{ color: colors.warning }}>■ Giallo</Text> = Riposo ·{" "}
        <Text style={{ color: colors.error }}>■ Rosso</Text> = Assente (auto) · Grigio = Futuro
      </Text>

      <Text style={styles.legendHint}>
        Tocca una domenica: 1° tap = Presente · 2° tap = Riposo · 3° tap = reset
      </Text>

      {months.map((m) => {
        const visibleDays = m.days.filter((d) => showSaturdays || d.dow === 0);
        if (visibleDays.length === 0) return null;
        return (
          <View key={m.key} style={styles.monthBlock}>
            <Text style={styles.monthLabel}>{m.label}</Text>
            <View style={styles.chipsGrid}>
              {visibleDays.map((d) => {
                const status = attMap.get(d.date);
                const past = isPastDate(d.date);
                const isPresent = status === "present";
                const isRest = status === "rest";
                const isSaturday = d.dow === 6;
                // Saturdays are optional: never marked red as "absent"
                const isAbsent = !status && past && !isSaturday;
                const today = isToday(d.date);
                const bg = isPresent
                  ? colors.success
                  : isRest
                  ? colors.warning
                  : isAbsent
                  ? colors.error
                  : colors.surfaceTertiary;
                const fg =
                  isPresent || isRest || isAbsent
                    ? colors.onBrandPrimary
                    : colors.onSurfaceSecondary;
                return (
                  <Pressable
                    key={d.date}
                    testID={`day-${d.date}`}
                    onPress={() => canEdit && onCycle(d.date)}
                    disabled={!canEdit}
                    style={[
                      styles.dayChip,
                      { backgroundColor: bg },
                      today && { borderColor: colors.brandPrimary, borderWidth: 2 },
                      !canEdit && { opacity: 0.9 },
                      isSaturday && !isPresent && !isRest && styles.dayChipSaturday,
                    ]}
                  >
                    <Text style={[styles.dayNum, { color: fg }]}>{d.day}</Text>
                    <Text style={[styles.dayDow, { color: fg }]}>
                      {d.dow === 6 ? "SAB" : "DOM"}
                    </Text>
                  </Pressable>
                );
              })}
            </View>
          </View>
        );
      })}
    </ScrollView>
  );
}

function PaymentTab({
  months,
  payMap,
  onToggle,
  counters,
  annualPaid,
  annualAmount,
  onAnnualToggle,
  onAnnualAmountSave,
  canEdit,
  bottomInset,
}: {
  months: ReturnType<typeof generateSeasonMonthList>;
  payMap: Map<string, boolean>;
  onToggle: (month: string, paid: boolean) => void;
  counters: { paid: number; unpaid: number };
  annualPaid: boolean;
  annualAmount: number;
  onAnnualToggle: (paid: boolean) => void;
  onAnnualAmountSave: (amount: number) => void;
  canEdit: boolean;
  bottomInset: number;
}) {
  const totalPaid = counters.paid * MONTHLY_FEE;
  const totalDue = counters.unpaid * MONTHLY_FEE;
  const [amountStr, setAmountStr] = useState<string>(String(annualAmount || ""));
  React.useEffect(() => {
    setAmountStr(annualAmount ? String(annualAmount) : "");
  }, [annualAmount]);

  return (
    <ScrollView
      contentContainerStyle={[styles.tabContent, { paddingBottom: bottomInset + spacing.xl }]}
      testID="payment-tab"
      keyboardShouldPersistTaps="handled"
    >
      {/* Annual membership flag card */}
      <Pressable
        testID="annual-fee-card"
        onPress={() => canEdit && onAnnualToggle(!annualPaid)}
        disabled={!canEdit}
        style={[
          styles.annualCard,
          { borderColor: annualPaid ? colors.success : colors.error },
        ]}
      >
        <View style={styles.annualHeader}>
          <View
            testID="annual-fee-light"
            style={[
              styles.annualLight,
              {
                backgroundColor: annualPaid ? "#B7E4A6" : "#FF6B6B",
                shadowColor: annualPaid ? "#B7E4A6" : "#FF6B6B",
              },
            ]}
          />
          <View style={{ flex: 1 }}>
            <Text style={styles.annualLabel}>TESSERAMENTO ANNUALE</Text>
            <Text
              style={[
                styles.annualStatus,
                { color: annualPaid ? colors.success : colors.error },
              ]}
            >
              {annualPaid ? "PAGATO" : "NON PAGATO"}
            </Text>
          </View>
          <Ionicons
            name={annualPaid ? "checkmark-circle" : "close-circle"}
            size={30}
            color={annualPaid ? colors.success : colors.error}
          />
        </View>
        <View style={styles.annualAmountRow}>
          <Text style={styles.annualAmountLabel}>IMPORTO PAGATO</Text>
          <View style={styles.annualAmountInputWrap}>
            <TextInput
              testID="annual-fee-amount"
              value={amountStr}
              onChangeText={setAmountStr}
              editable={canEdit}
              onEndEditing={() => {
                if (!canEdit) return;
                const n = parseFloat(amountStr.replace(",", "."));
                if (!Number.isNaN(n)) onAnnualAmountSave(n);
                else if (amountStr.trim() === "") onAnnualAmountSave(0);
              }}
              keyboardType="decimal-pad"
              placeholder="0"
              placeholderTextColor={colors.muted}
              style={styles.annualAmountInput}
            />
            <Text style={styles.annualEuro}>€</Text>
          </View>
        </View>
      </Pressable>

      <View style={styles.sectionDivider} />

      <Text style={styles.sectionTitle}>MENSILITÀ</Text>
      <Text style={styles.sectionHelp}>
        Quota {MONTHLY_FEE}€/mese · Stagione 2026/27 · Tocca il mese per marcarlo come pagato.
      </Text>

      <View style={styles.metricsRow}>
        <View style={[styles.metric, { borderLeftColor: colors.brandPrimary }]}>
          <Text style={styles.metricNum}>{counters.paid}</Text>
          <Text style={styles.metricLabel}>PAGATI</Text>
          <Text style={styles.metricAmount}>{totalPaid}€</Text>
        </View>
        <View style={[styles.metric, { borderLeftColor: colors.error }]}>
          <Text style={[styles.metricNum, { color: colors.error }]}>{counters.unpaid}</Text>
          <Text style={styles.metricLabel}>NON PAGATI</Text>
          <Text style={[styles.metricAmount, { color: colors.error }]}>{totalDue}€</Text>
        </View>
      </View>

      <View style={styles.legendRow}>
        <View style={styles.legendItem}>
          <View style={styles.legendDotGreen} />
          <Text style={styles.legendLabel}>Pagato</Text>
        </View>
        <View style={styles.legendItem}>
          <View style={styles.legendDotRed} />
          <Text style={styles.legendLabel}>Da pagare</Text>
        </View>
        <View style={styles.legendItem}>
          <View style={styles.legendDotGray} />
          <Text style={styles.legendLabel}>Futuro</Text>
        </View>
      </View>

      <View style={styles.paymentGrid}>
        {months.map((m) => {
          const paid = payMap.get(m.key) === true;
          const started = isCurrentOrPastMonth(m.key);
          const unpaid = !paid && started;
          const cellBg = paid
            ? colors.success
            : unpaid
            ? colors.error
            : colors.surfaceTertiary;
          const fg = paid || unpaid ? colors.onBrandPrimary : colors.onSurfaceSecondary;
          const [monthName, year] = m.label.split(" ");
          return (
            <Pressable
              key={m.key}
              testID={`month-${m.key}`}
              onPress={() => canEdit && onToggle(m.key, !paid)}
              disabled={!canEdit}
              style={[styles.paymentCell, { backgroundColor: cellBg }]}
            >
              <View
                testID={`payment-light-${m.key}`}
                style={[
                  styles.paymentLight,
                  {
                    backgroundColor: paid
                      ? "#B7E4A6"
                      : unpaid
                      ? "#FF6B6B"
                      : colors.muted,
                    shadowColor: paid ? "#B7E4A6" : unpaid ? "#FF6B6B" : "transparent",
                  },
                ]}
              />
              <Text style={[styles.paymentMonth, { color: fg }]}>{monthName}</Text>
              <Text style={[styles.paymentYear, { color: fg }]}>{year}</Text>
              <Text style={[styles.paymentAmount, { color: fg }]}>{MONTHLY_FEE}€</Text>
            </Pressable>
          );
        })}
      </View>
    </ScrollView>
  );
}

function NotesTab({
  value,
  setValue,
  onSave,
  saving,
  canEdit,
  bottomInset,
}: {
  value: string;
  setValue: (s: string) => void;
  onSave: () => void;
  saving: boolean;
  canEdit: boolean;
  bottomInset: number;
}) {
  return (
    <KeyboardAvoidingView
      behavior={Platform.OS === "ios" ? "padding" : undefined}
      style={{ flex: 1 }}
      keyboardVerticalOffset={80}
    >
      <ScrollView
        contentContainerStyle={[styles.tabContent, { paddingBottom: bottomInset + spacing.xxl }]}
        keyboardShouldPersistTaps="handled"
        testID="notes-tab"
      >
        <Text style={styles.sectionTitle}>SCHEDA COMPORTAMENTALE</Text>
        <Text style={styles.sectionHelp}>Annotazioni operative sull'operatore.</Text>
        <TextInput
          testID="notes-input"
          value={value}
          onChangeText={setValue}
          editable={canEdit}
          multiline
          textAlignVertical="top"
          placeholder={canEdit ? "Scrivi qui le tue annotazioni..." : "Solo lettura"}
          placeholderTextColor={colors.muted}
          style={styles.notesInput}
        />
        {canEdit ? (
          <Pressable
            testID="save-notes"
            onPress={onSave}
            disabled={saving}
            style={({ pressed }) => [
              styles.uploadBtn,
              pressed && { opacity: 0.85 },
              saving && { opacity: 0.6 },
            ]}
          >
            {saving ? (
              <ActivityIndicator color={colors.onBrandPrimary} />
            ) : (
              <>
                <Ionicons name="save" size={18} color={colors.onBrandPrimary} />
                <Text style={styles.uploadText}>SALVA NOTE</Text>
              </>
            )}
          </Pressable>
        ) : null}
      </ScrollView>
    </KeyboardAvoidingView>
  );
}

const styles = StyleSheet.create({
  root: { flex: 1, backgroundColor: colors.surface },
  cover: { height: 260 },
  coverTop: {
    flexDirection: "row",
    justifyContent: "space-between",
    paddingHorizontal: spacing.lg,
  },
  iconChip: {
    width: 40,
    height: 40,
    borderRadius: radius.sm,
    backgroundColor: "rgba(16,18,16,0.7)",
    borderWidth: 1,
    borderColor: colors.borderStrong,
    alignItems: "center",
    justifyContent: "center",
  },
  roleBar: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
    gap: spacing.md,
    paddingHorizontal: spacing.lg,
    paddingVertical: spacing.md,
    backgroundColor: colors.surfaceSecondary,
    borderBottomWidth: 1,
    borderBottomColor: colors.border,
  },
  roleBarLeft: {
    flexDirection: "row",
    alignItems: "center",
    gap: spacing.sm,
    flex: 1,
  },
  roleBarEmail: {
    color: colors.onSurface,
    fontSize: 13,
    fontWeight: "600",
  },
  roleBarStatus: {
    fontSize: 10,
    fontWeight: "900",
    letterSpacing: 1.5,
    marginTop: 2,
  },
  roleBtn: {
    borderWidth: 1.5,
    borderRadius: radius.sm,
    paddingHorizontal: spacing.md,
    paddingVertical: spacing.sm,
    minWidth: 120,
    alignItems: "center",
  },
  roleBtnText: {
    fontSize: 10,
    fontWeight: "900",
    letterSpacing: 1.5,
  },
  coverBottom: {
    position: "absolute",
    bottom: spacing.md,
    left: spacing.lg,
    right: spacing.lg,
  },
  coverDept: {
    color: colors.brandPrimary,
    fontSize: 10,
    letterSpacing: 2,
    fontWeight: "800",
  },
  coverRank: {
    color: colors.onSurface,
    fontSize: 13,
    letterSpacing: 3,
    fontWeight: "800",
    marginTop: 2,
    borderLeftWidth: 3,
    borderLeftColor: colors.brandPrimary,
    paddingLeft: spacing.sm,
  },
  coverTitle: {
    color: colors.onSurface,
    fontSize: 30,
    fontWeight: "900",
    letterSpacing: 2,
    marginTop: 4,
  },
  coverSub: {
    color: colors.onSurfaceSecondary,
    fontSize: 13,
    marginTop: 2,
  },
  phoneRow: {
    flexDirection: "row",
    alignItems: "center",
    gap: spacing.xs,
    marginTop: spacing.xs,
  },
  phoneText: { color: colors.onSurfaceSecondary, fontSize: 12 },
  presenceBadgeRow: {
    flexDirection: "row",
    gap: spacing.sm,
    marginTop: spacing.sm,
    flexWrap: "wrap",
  },
  presenceBadge: {
    flexDirection: "row",
    alignItems: "center",
    gap: 6,
    paddingHorizontal: spacing.md,
    paddingVertical: 6,
    borderRadius: 999,
    backgroundColor: colors.brandPrimary,
    alignSelf: "flex-start",
  },
  presenceBadgeRest: {
    backgroundColor: colors.warning,
  },
  presenceBadgeNum: {
    color: colors.onBrandPrimary,
    fontSize: 16,
    fontWeight: "900",
    letterSpacing: 0.5,
  },
  presenceBadgeLabel: {
    color: colors.onBrandPrimary,
    fontSize: 9,
    fontWeight: "900",
    letterSpacing: 1.5,
    marginLeft: 2,
  },
  tabsRow: {
    flexDirection: "row",
    paddingHorizontal: spacing.sm,
    paddingVertical: spacing.sm,
    gap: 4,
    borderBottomWidth: 1,
    borderBottomColor: colors.border,
    backgroundColor: colors.surface,
  },
  tab: {
    flex: 1,
    flexDirection: "column",
    alignItems: "center",
    justifyContent: "center",
    gap: 2,
    paddingHorizontal: 4,
    paddingVertical: 6,
    borderRadius: radius.sm,
    borderWidth: 1,
    borderColor: colors.border,
    backgroundColor: colors.surfaceSecondary,
    minHeight: 44,
  },
  tabActive: {
    backgroundColor: colors.brandPrimary,
    borderColor: colors.brandPrimary,
  },
  tabText: {
    color: colors.onSurfaceSecondary,
    fontSize: 9,
    fontWeight: "800",
    letterSpacing: 0.5,
    textAlign: "center",
  },
  tabTextActive: { color: colors.onBrandPrimary },
  loading: { flex: 1, alignItems: "center", justifyContent: "center" },
  tabContent: {
    paddingHorizontal: spacing.lg,
    paddingTop: spacing.lg,
    gap: spacing.md,
  },
  sectionTitle: {
    color: colors.onSurface,
    fontSize: 18,
    fontWeight: "900",
    letterSpacing: 2,
  },
  sectionHelp: {
    color: colors.onSurfaceSecondary,
    fontSize: 12,
    marginBottom: spacing.sm,
  },
  fileCard: {
    flexDirection: "row",
    alignItems: "center",
    gap: spacing.md,
    backgroundColor: colors.surfaceSecondary,
    borderWidth: 1,
    borderColor: colors.border,
    borderLeftWidth: 3,
    borderLeftColor: colors.brandPrimary,
    padding: spacing.md,
    borderRadius: radius.sm,
  },
  fileIconBox: {
    width: 44,
    height: 44,
    backgroundColor: colors.surfaceTertiary,
    borderRadius: radius.sm,
    alignItems: "center",
    justifyContent: "center",
  },
  fileName: {
    color: colors.onSurface,
    fontSize: 14,
    fontWeight: "700",
  },
  fileMeta: {
    color: colors.onSurfaceSecondary,
    fontSize: 11,
    marginTop: 2,
  },
  openBtn: {
    width: 40,
    height: 40,
    borderRadius: radius.sm,
    borderWidth: 1,
    borderColor: colors.borderStrong,
    alignItems: "center",
    justifyContent: "center",
  },
  emptyBox: {
    borderWidth: 1,
    borderColor: colors.border,
    borderStyle: "dashed",
    borderRadius: radius.sm,
    paddingVertical: spacing.xxl,
    alignItems: "center",
    justifyContent: "center",
    gap: spacing.sm,
  },
  emptyText: { color: colors.muted, fontSize: 13 },
  uploadBtn: {
    backgroundColor: colors.brandPrimary,
    paddingVertical: spacing.lg,
    borderRadius: radius.sm,
    alignItems: "center",
    justifyContent: "center",
    flexDirection: "row",
    gap: spacing.sm,
    marginTop: spacing.md,
  },
  uploadText: {
    color: colors.onBrandPrimary,
    fontWeight: "900",
    letterSpacing: 2,
    fontSize: 13,
  },
  removeBtn: {
    backgroundColor: "transparent",
    borderWidth: 1.5,
    borderColor: colors.error,
    paddingVertical: spacing.md,
    borderRadius: radius.sm,
    alignItems: "center",
    justifyContent: "center",
    flexDirection: "row",
    gap: spacing.sm,
  },
  removeText: {
    color: colors.error,
    fontWeight: "900",
    letterSpacing: 2,
    fontSize: 13,
  },
  metricsRow: {
    flexDirection: "row",
    gap: spacing.md,
  },
  metric: {
    flex: 1,
    backgroundColor: colors.surfaceSecondary,
    borderWidth: 1,
    borderColor: colors.border,
    borderLeftWidth: 4,
    padding: spacing.md,
    borderRadius: radius.sm,
  },
  metricNum: {
    color: colors.brandPrimary,
    fontSize: 28,
    fontWeight: "900",
  },
  metricLabel: {
    color: colors.onSurfaceSecondary,
    fontSize: 10,
    letterSpacing: 2,
    fontWeight: "700",
    marginTop: 2,
  },
  metricAmount: {
    color: colors.brandPrimary,
    fontSize: 13,
    fontWeight: "800",
    marginTop: spacing.xs,
  },
  legend: {
    color: colors.onSurfaceSecondary,
    fontSize: 11,
    marginBottom: spacing.xs,
  },
  legendHint: {
    color: colors.brandPrimary,
    fontSize: 10,
    fontStyle: "italic",
    marginBottom: spacing.sm,
    letterSpacing: 0.3,
  },
  legendRow: {
    flexDirection: "row",
    gap: spacing.md,
    marginBottom: spacing.sm,
    flexWrap: "wrap",
  },
  legendItem: {
    flexDirection: "row",
    alignItems: "center",
    gap: spacing.xs,
  },
  legendLabel: {
    color: colors.onSurfaceSecondary,
    fontSize: 11,
  },
  legendDotGreen: {
    width: 10,
    height: 10,
    borderRadius: 5,
    backgroundColor: colors.success,
  },
  legendDotRed: {
    width: 10,
    height: 10,
    borderRadius: 5,
    backgroundColor: colors.error,
  },
  legendDotGray: {
    width: 10,
    height: 10,
    borderRadius: 5,
    backgroundColor: colors.muted,
  },
  monthBlock: { gap: spacing.sm, marginTop: spacing.md },
  monthLabel: {
    color: colors.onSurface,
    fontSize: 14,
    fontWeight: "800",
    letterSpacing: 2,
    paddingBottom: spacing.xs,
    borderBottomWidth: 1,
    borderBottomColor: colors.border,
  },
  chipsGrid: {
    flexDirection: "row",
    flexWrap: "wrap",
    gap: spacing.sm,
  },
  dayChip: {
    width: 56,
    height: 56,
    borderRadius: radius.sm,
    alignItems: "center",
    justifyContent: "center",
    borderWidth: 1,
    borderColor: colors.border,
  },
  dayChipSaturday: {
    borderStyle: "dashed",
    borderColor: colors.info,
  },
  satToggle: {
    alignSelf: "flex-start",
    flexDirection: "row",
    alignItems: "center",
    gap: 6,
    paddingHorizontal: spacing.md,
    paddingVertical: 8,
    borderRadius: radius.pill,
    borderWidth: StyleSheet.hairlineWidth,
    borderColor: colors.border,
    backgroundColor: colors.surfaceSecondary,
    marginBottom: spacing.sm,
  },
  satToggleActive: {
    backgroundColor: colors.brandPrimary,
    borderColor: colors.brandPrimary,
  },
  satToggleText: {
    color: colors.onSurface,
    fontSize: 11,
    fontWeight: "900",
    letterSpacing: 1,
  },
  dayNum: {
    fontSize: 18,
    fontWeight: "900",
  },
  dayDow: {
    fontSize: 9,
    letterSpacing: 1,
    fontWeight: "700",
    marginTop: 2,
  },
  notesInput: {
    backgroundColor: colors.surfaceSecondary,
    borderWidth: 1,
    borderColor: colors.border,
    borderRadius: radius.sm,
    color: colors.onSurface,
    padding: spacing.md,
    minHeight: 220,
    fontSize: 14,
    lineHeight: 20,
  },
  paymentGrid: {
    flexDirection: "row",
    flexWrap: "wrap",
    gap: spacing.sm,
    marginTop: spacing.sm,
  },
  annualCard: {
    borderWidth: 2,
    borderRadius: radius.sm,
    backgroundColor: colors.surfaceSecondary,
    padding: spacing.md,
    gap: spacing.md,
  },
  annualHeader: {
    flexDirection: "row",
    alignItems: "center",
    gap: spacing.md,
  },
  annualLight: {
    width: 18,
    height: 18,
    borderRadius: 9,
    shadowOffset: { width: 0, height: 0 },
    shadowOpacity: 0.9,
    shadowRadius: 8,
    elevation: 6,
  },
  annualLabel: {
    color: colors.onSurface,
    fontSize: 13,
    fontWeight: "900",
    letterSpacing: 2,
  },
  annualStatus: {
    fontSize: 12,
    fontWeight: "900",
    letterSpacing: 3,
    marginTop: 2,
  },
  annualAmountRow: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
    borderTopWidth: 1,
    borderTopColor: colors.border,
    paddingTop: spacing.md,
  },
  annualAmountLabel: {
    color: colors.onSurfaceSecondary,
    fontSize: 11,
    letterSpacing: 2,
    fontWeight: "800",
  },
  annualAmountInputWrap: {
    flexDirection: "row",
    alignItems: "center",
    gap: spacing.xs,
    backgroundColor: colors.surfaceTertiary,
    borderWidth: 1,
    borderColor: colors.border,
    borderRadius: radius.sm,
    paddingHorizontal: spacing.md,
    minWidth: 110,
  },
  annualAmountInput: {
    flex: 1,
    color: colors.onSurface,
    fontSize: 18,
    fontWeight: "900",
    paddingVertical: spacing.sm,
    textAlign: "right",
  },
  annualEuro: {
    color: colors.brandPrimary,
    fontSize: 18,
    fontWeight: "900",
  },
  sectionDivider: {
    height: 1,
    backgroundColor: colors.border,
    marginVertical: spacing.md,
  },
  paymentCell: {
    width: "31%",
    borderRadius: radius.sm,
    padding: spacing.sm,
    borderWidth: 1,
    borderColor: colors.border,
    alignItems: "center",
    justifyContent: "center",
    minHeight: 92,
    gap: 2,
  },
  paymentLight: {
    width: 12,
    height: 12,
    borderRadius: 6,
    marginBottom: spacing.xs,
    shadowOffset: { width: 0, height: 0 },
    shadowOpacity: 0.9,
    shadowRadius: 6,
    elevation: 4,
  },
  paymentMonth: {
    fontSize: 11,
    fontWeight: "900",
    letterSpacing: 1.5,
  },
  paymentYear: {
    fontSize: 9,
    fontWeight: "700",
    letterSpacing: 1,
  },
  paymentAmount: {
    fontSize: 13,
    fontWeight: "900",
    marginTop: spacing.xs,
  },
});
