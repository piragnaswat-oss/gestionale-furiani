import React, { useMemo, useState } from "react";
import {
  View,
  Text,
  StyleSheet,
  Pressable,
  FlatList,
  RefreshControl,
  Modal,
  TextInput,
  KeyboardAvoidingView,
  Platform,
  ActivityIndicator,
  ScrollView,
} from "react-native";
import { Image } from "expo-image";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import { useRouter } from "expo-router";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Ionicons } from "@react-native-vector-icons/ionicons";
import * as Haptics from "expo-haptics";
import * as ImagePicker from "expo-image-picker";

import { apiJson, BACKEND_URL, getToken } from "@/src/api";
import { colors, spacing, radius } from "@/src/theme";
import { useAuth } from "@/src/auth-context";

type Operator = {
  id: string;
  battle_name: string;
  real_name: string;
  phone: string;
  rank: string;
  department: string;
  email: string;
  photo?: { path: string; size: number; uploaded_at: string } | null;
};

const MIN_SLOTS = 27;
const DEFAULT_DEPARTMENT = "630";
const DEPARTMENT_OPTIONS = [
  "630",
  "ROCS",
  "DIRETTIVO",
  "AMMINISTRAZIONE",
  "ISTRUTTORE",
  "FURIANO SEMPLICE",
] as const;
const FILTER_OPTIONS = [
  "TUTTI",
  "630",
  "ROCS",
  "DIRETTIVO",
  "AMMINISTRAZIONE",
  "ISTRUTTORE",
  "FURIANO SEMPLICE",
] as const;
type FilterKey = (typeof FILTER_OPTIONS)[number];

function parseDepartments(s: string | undefined | null): string[] {
  if (!s) return [];
  return s
    .split(",")
    .map((x) => x.trim().toUpperCase())
    .filter(Boolean);
}

function photoUrlFor(opId: string, cacheBust?: string | number): string {
  const t = getToken() || "";
  const cb = cacheBust ? `&v=${cacheBust}` : "";
  return `${BACKEND_URL}/api/operators/${opId}/photo?token=${encodeURIComponent(t)}${cb}`;
}

async function fetchOperators(): Promise<Operator[]> {
  return apiJson<Operator[]>("/operators");
}

export default function RosterScreen() {
  const insets = useSafeAreaInsets();
  const router = useRouter();
  const qc = useQueryClient();
  const { user, signOut } = useAuth();
  const isAdmin = user?.role === "admin";
  const [modalVisible, setModalVisible] = useState(false);
  const [filter, setFilter] = useState<FilterKey>("TUTTI");
  const [editingId, setEditingId] = useState<string | null>(null);
  const [battleName, setBattleName] = useState("");
  const [realName, setRealName] = useState("");
  const [phone, setPhone] = useState("");
  const [rank, setRank] = useState("");
  const [email, setEmail] = useState("");
  const [departments, setDepartments] = useState<string[]>([DEFAULT_DEPARTMENT]);
  const [photoUri, setPhotoUri] = useState<string | null>(null);
  const [photoBlob, setPhotoBlob] = useState<Blob | null>(null);
  const [photoName, setPhotoName] = useState<string>("photo.jpg");
  const [saving, setSaving] = useState(false);

  const { data: operators = [], isLoading, refetch, isRefetching } = useQuery({
    queryKey: ["operators"],
    queryFn: fetchOperators,
  });

  const createMut = useMutation({
    mutationFn: async (payload: {
      battle_name: string;
      real_name: string;
      phone: string;
      rank: string;
      department: string;
      email: string;
    }) =>
      apiJson<Operator>("/operators", { method: "POST", body: JSON.stringify(payload) }),
    onSuccess: () => qc.invalidateQueries({ queryKey: ["operators"] }),
  });

  const updateMut = useMutation({
    mutationFn: async ({ id, patch }: { id: string; patch: Record<string, unknown> }) =>
      apiJson<Operator>(`/operators/${id}`, {
        method: "PATCH",
        body: JSON.stringify(patch),
      }),
    onSuccess: (_data, vars) => {
      qc.invalidateQueries({ queryKey: ["operators"] });
      qc.invalidateQueries({ queryKey: ["operator", vars.id] });
    },
  });

  const slots = useMemo(() => {
    const filtered =
      filter === "TUTTI"
        ? operators
        : operators.filter((o) => parseDepartments(o.department).includes(filter));
    if (!isAdmin) {
      return filtered;
    }
    if (filter !== "TUTTI") {
      return [...filtered, null] as (Operator | null)[];
    }
    const finalCount =
      operators.length >= MIN_SLOTS ? operators.length + 1 : MIN_SLOTS;
    return Array.from({ length: finalCount }).map((_, i) => operators[i] ?? null);
  }, [operators, isAdmin, filter]);

  const filledCount =
    filter === "TUTTI"
      ? operators.length
      : operators.filter((o) => parseDepartments(o.department).includes(filter)).length;

  const openCreate = () => {
    setEditingId(null);
    setBattleName("");
    setRealName("");
    setPhone("");
    setRank("");
    setEmail("");
    setDepartments([DEFAULT_DEPARTMENT]);
    setPhotoUri(null);
    setPhotoBlob(null);
    setModalVisible(true);
  };

  const openEdit = (op: Operator) => {
    setEditingId(op.id);
    setBattleName(op.battle_name || "");
    setRealName(op.real_name || "");
    setPhone(op.phone || "");
    setRank(op.rank || "");
    setEmail(op.email || "");
    const parsed = parseDepartments(op.department);
    setDepartments(parsed.length ? parsed : [DEFAULT_DEPARTMENT]);
    setPhotoUri(op.photo ? photoUrlFor(op.id) : null);
    setPhotoBlob(null);
    setModalVisible(true);
  };

  const toggleDepartment = (opt: string) => {
    setDepartments((prev) => {
      if (prev.includes(opt)) {
        const next = prev.filter((x) => x !== opt);
        return next.length ? next : [opt]; // never leave empty
      }
      return [...prev, opt];
    });
  };

  const pickPhoto = async () => {
    try {
      const perm = await ImagePicker.requestMediaLibraryPermissionsAsync();
      if (!perm.granted && perm.canAskAgain === false) {
        return;
      }
      const res = await ImagePicker.launchImageLibraryAsync({
        mediaTypes: ImagePicker.MediaTypeOptions.Images,
        allowsEditing: true,
        aspect: [1, 1],
        quality: 0.7,
      });
      if (res.canceled || !res.assets?.length) return;
      const asset = res.assets[0];
      setPhotoUri(asset.uri);
      const r = await fetch(asset.uri);
      const b = await r.blob();
      setPhotoBlob(b);
      setPhotoName(asset.fileName || `photo-${Date.now()}.jpg`);
    } catch {}
  };

  const uploadPhoto = async (opId: string) => {
    if (!photoBlob) return;
    const fd = new FormData();
    if (Platform.OS === "web") {
      fd.append("file", photoBlob, photoName);
    } else {
      // @ts-ignore RN FormData accepts { uri, name, type }
      fd.append("file", { uri: photoUri, name: photoName, type: photoBlob.type || "image/jpeg" });
    }
    const token = getToken() || "";
    await fetch(`${BACKEND_URL}/api/operators/${opId}/photo`, {
      method: "POST",
      headers: { Authorization: `Bearer ${token}` },
      body: fd,
    });
  };

  const submitCreate = async () => {
    if (!battleName.trim()) return;
    setSaving(true);
    try {
      const payload = {
        battle_name: battleName.trim(),
        real_name: realName.trim(),
        phone: phone.trim(),
        rank: rank.trim(),
        department: (departments.length ? departments : [DEFAULT_DEPARTMENT]).join(","),
        email: email.trim().toLowerCase(),
      };
      let opId = editingId;
      if (editingId) {
        await updateMut.mutateAsync({ id: editingId, patch: payload });
      } else {
        const created = await createMut.mutateAsync(payload);
        opId = created.id;
      }
      if (opId && photoBlob) {
        await uploadPhoto(opId);
        qc.invalidateQueries({ queryKey: ["operators"] });
        qc.invalidateQueries({ queryKey: ["operator", opId] });
      }
      Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Medium);
      setModalVisible(false);
    } catch {}
    setSaving(false);
  };

  const renderItem = ({ item, index }: { item: Operator | null; index: number }) => {
    const slotNumber = String(index + 1).padStart(2, "0");
    if (!item) {
      if (!isAdmin) return null;
      return (
        <Pressable
          testID={`empty-slot-${index}`}
          onPress={openCreate}
          style={({ pressed }) => [styles.card, styles.cardEmpty, pressed && { opacity: 0.7 }]}
        >
          <Text style={styles.slotNum}>#{slotNumber}</Text>
          <View style={styles.emptyIconWrap}>
            <Ionicons name="add" size={28} color={colors.brandPrimary} />
          </View>
          <Text style={styles.emptyLabel}>AGGIUNGI</Text>
        </Pressable>
      );
    }
    return (
      <Pressable
        testID={`operator-card-${item.id}`}
        onPress={() => router.push(`/operator/${item.id}`)}
        style={({ pressed }) => [styles.card, styles.cardFilled, pressed && { opacity: 0.8 }]}
      >
        <View style={styles.cardTopRow}>
          <Text style={styles.slotNum}>#{slotNumber}</Text>
          <View style={styles.cardTopRight}>
            {isAdmin ? (
              <Pressable
                testID={`edit-operator-${item.id}`}
                onPress={(e) => {
                  e.stopPropagation?.();
                  openEdit(item);
                }}
                hitSlop={10}
                style={styles.editBtn}
              >
                <Ionicons name="create-outline" size={14} color={colors.brandPrimary} />
              </Pressable>
            ) : null}
            <View style={styles.statusDot} />
          </View>
        </View>
        {item.photo ? (
          <Image
            source={{ uri: photoUrlFor(item.id, item.photo.uploaded_at) }}
            style={styles.cardPhoto}
            contentFit="cover"
            testID={`operator-photo-${item.id}`}
          />
        ) : (
          <View style={[styles.cardPhoto, styles.cardPhotoPlaceholder]}>
            <Ionicons name="person" size={20} color={colors.onSurfaceSecondary} />
          </View>
        )}
        {item.rank ? (
          <Text style={styles.rankText} numberOfLines={2} testID={`operator-rank-${item.id}`}>
            {item.rank.toUpperCase()}
          </Text>
        ) : null}
        <Text style={styles.battleName} numberOfLines={1}>
          {item.battle_name.toUpperCase()}
        </Text>
        {item.real_name ? (
          <Text style={styles.realName} numberOfLines={1}>
            {item.real_name}
          </Text>
        ) : null}
        {item.phone ? (
          <View style={styles.phoneRow}>
            <Ionicons name="call" size={11} color={colors.onSurfaceSecondary} />
            <Text style={styles.phone} numberOfLines={1}>
              {item.phone}
            </Text>
          </View>
        ) : null}
        {parseDepartments(item.department).length ? (
          <View style={styles.deptChipRow}>
            {parseDepartments(item.department).map((d) => (
              <View key={d} style={styles.deptTagChip}>
                <Text style={styles.deptTagText}>{d}</Text>
              </View>
            ))}
          </View>
        ) : null}
      </Pressable>
    );
  };

  return (
    <View style={[styles.root, { paddingTop: insets.top }]} testID="roster-screen">
      {/* Header */}
      <View style={styles.header}>
        <View style={styles.headerLeft}>
          <Image
            source={require("../assets/images/furiani-logo.jpeg")}
            style={styles.headerLogo}
            contentFit="contain"
          />
          <View>
            <Text style={styles.headerLabel}>BATTAGLIONE FURIANI</Text>
            <Text style={styles.headerTitle}>ROSTER</Text>
          </View>
        </View>
        <View style={styles.headerRight}>
          <View style={styles.counter}>
            <Text style={styles.counterNum}>{filledCount}</Text>
            <Text style={styles.counterLabel}>ATTIVI</Text>
          </View>
          <Pressable
            testID="back-to-calendar"
            onPress={() => router.push("/events")}
            style={styles.iconBtn}
            hitSlop={8}
          >
            <Ionicons name="calendar" size={20} color={colors.brandPrimary} />
          </Pressable>
          {isAdmin ? (
            <Pressable
              testID="team-button"
              onPress={() => router.push("/team")}
              style={styles.iconBtn}
              hitSlop={8}
            >
              <Ionicons name="people" size={20} color={colors.brandPrimary} />
            </Pressable>
          ) : null}
          <Pressable
            testID="logout-button"
            onPress={signOut}
            style={styles.iconBtn}
            hitSlop={8}
          >
            <Ionicons name="log-out-outline" size={20} color={colors.onSurfaceSecondary} />
          </Pressable>
        </View>
      </View>

      {user ? (
        <View style={styles.userBar}>
          <Ionicons
            name={isAdmin ? "shield-checkmark" : "person-circle-outline"}
            size={16}
            color={colors.brandPrimary}
          />
          <Text style={styles.userText} numberOfLines={1}>
            {user.name || user.email}
          </Text>
          <View style={styles.rolePill}>
            <Text style={styles.rolePillText}>
              {isAdmin ? "ADMIN" : "MEMBRO"}
            </Text>
          </View>
        </View>
      ) : null}

      {/* Reparto filter tabs — compact text-only scrollable row */}
      <ScrollView
        horizontal
        showsHorizontalScrollIndicator={false}
        contentContainerStyle={styles.filterBar}
        style={{ maxHeight: 32, backgroundColor: colors.surface }}
      >
        {FILTER_OPTIONS.map((f) => {
          const active = filter === f;
          const count =
            f === "TUTTI"
              ? operators.length
              : operators.filter((o) => parseDepartments(o.department).includes(f)).length;
          return (
            <Pressable
              key={f}
              testID={`filter-${f}`}
              onPress={() => setFilter(f)}
              style={styles.filterTab}
              hitSlop={6}
            >
              <Text
                style={[styles.filterTabText, active && styles.filterTabTextActive]}
                numberOfLines={1}
              >
                {f} <Text style={styles.filterTabCount}>({count})</Text>
              </Text>
              {active ? <View style={styles.filterUnderline} /> : null}
            </Pressable>
          );
        })}
      </ScrollView>

      {isLoading ? (
        <View style={styles.loading}>
          <ActivityIndicator color={colors.brandPrimary} />
        </View>
      ) : (
        <FlatList
          testID="roster-grid"
          style={{ flex: 1 }}
          data={slots}
          keyExtractor={(item, idx) => (item ? item.id : `empty-${idx}`)}
          renderItem={renderItem}
          numColumns={2}
          columnWrapperStyle={{ gap: spacing.md }}
          contentContainerStyle={{
            paddingHorizontal: spacing.lg,
            paddingBottom: insets.bottom + spacing.xxl,
            gap: spacing.md,
          }}
          refreshControl={
            <RefreshControl
              refreshing={isRefetching}
              onRefresh={refetch}
              tintColor={colors.brandPrimary}
            />
          }
        />
      )}

      {/* Add Operator Modal */}
      <Modal
        visible={modalVisible}
        transparent
        animationType="fade"
        onRequestClose={() => setModalVisible(false)}
      >
        <KeyboardAvoidingView
          behavior={Platform.OS === "ios" ? "padding" : "height"}
          style={styles.modalOverlay}
        >
          <Pressable style={StyleSheet.absoluteFillObject} onPress={() => setModalVisible(false)} />
          <View style={styles.modalCard} testID="add-operator-modal">
            <View style={styles.modalHeader}>
              <Text style={styles.modalTitle}>
                {editingId ? "MODIFICA OPERATORE" : "NUOVO OPERATORE"}
              </Text>
              <Pressable onPress={() => setModalVisible(false)} hitSlop={8}>
                <Ionicons name="close" size={22} color={colors.onSurfaceSecondary} />
              </Pressable>
            </View>
            <ScrollView keyboardShouldPersistTaps="handled" showsVerticalScrollIndicator={false}>
              <Text style={styles.label}>REPARTO</Text>
              <Text style={styles.help}>
                Puoi selezionare più di un reparto (es. 630 + DIRETTIVO).
              </Text>
              <View style={styles.deptRow}>
                {DEPARTMENT_OPTIONS.map((opt) => {
                  const active = departments.includes(opt);
                  return (
                    <Pressable
                      key={opt}
                      testID={`department-${opt}`}
                      onPress={() => toggleDepartment(opt)}
                      style={[
                        styles.deptSelector,
                        active && styles.deptSelectorActive,
                      ]}
                    >
                      <Ionicons
                        name={active ? "checkbox" : "square-outline"}
                        size={16}
                        color={active ? colors.onBrandPrimary : colors.onSurfaceSecondary}
                      />
                      <Text
                        style={[
                          styles.deptSelectorText,
                          active && { color: colors.onBrandPrimary },
                        ]}
                      >
                        {opt}
                      </Text>
                    </Pressable>
                  );
                })}
              </View>

              <Text style={styles.label}>FOTO OPERATORE</Text>
              <Pressable
                testID="photo-picker"
                onPress={pickPhoto}
                style={styles.photoPicker}
              >
                {photoUri ? (
                  <Image
                    source={{ uri: photoUri }}
                    style={styles.photoPreview}
                    contentFit="cover"
                  />
                ) : (
                  <View style={styles.photoPlaceholder}>
                    <Ionicons name="camera" size={26} color={colors.brandPrimary} />
                  </View>
                )}
                <View style={{ flex: 1 }}>
                  <Text style={styles.photoPickerText}>
                    {photoUri ? "CAMBIA FOTO" : "AGGIUNGI FOTO"}
                  </Text>
                  <Text style={styles.help}>Verrà mostrata sulla casella dell&apos;operatore.</Text>
                </View>
              </Pressable>

              <Text style={styles.label}>GRADO</Text>
              <TextInput
                testID="input-rank"
                value={rank}
                onChangeText={setRank}
                style={styles.input}
                placeholder="Es. Vice Presidente"
                placeholderTextColor={colors.muted}
              />

              <Text style={styles.label}>NOME OPERATORE</Text>
              <TextInput
                testID="input-real-name"
                value={realName}
                onChangeText={setRealName}
                style={styles.input}
                placeholder="Mario Rossi"
                placeholderTextColor={colors.muted}
              />

              <Text style={styles.label}>NOME DI BATTAGLIA *</Text>
              <TextInput
                testID="input-battle-name"
                value={battleName}
                onChangeText={setBattleName}
                style={styles.input}
                placeholder="Es. Ghost"
                placeholderTextColor={colors.muted}
                autoCapitalize="characters"
              />

              <Text style={styles.label}>NUMERO CELLULARE</Text>
              <TextInput
                testID="input-phone"
                value={phone}
                onChangeText={setPhone}
                style={styles.input}
                placeholder="+39 ..."
                placeholderTextColor={colors.muted}
                keyboardType="phone-pad"
              />

              <Text style={styles.label}>EMAIL GOOGLE (opzionale)</Text>
              <TextInput
                testID="input-email"
                value={email}
                onChangeText={setEmail}
                style={styles.input}
                placeholder="mario.rossi@gmail.com"
                placeholderTextColor={colors.muted}
                keyboardType="email-address"
                autoCapitalize="none"
                autoCorrect={false}
              />
              <Text style={styles.help}>
                Serve per collegare l&apos;operatore al suo account app e permettere agli admin di promuoverlo.
              </Text>
              <Pressable
                testID="submit-operator"
                onPress={submitCreate}
                disabled={!battleName.trim() || saving}
                style={({ pressed }) => [
                  styles.submitBtn,
                  (!battleName.trim() || saving) && { opacity: 0.5 },
                  pressed && { opacity: 0.85 },
                ]}
              >
                {saving ? (
                  <ActivityIndicator color={colors.onBrandPrimary} />
                ) : (
                  <Text style={styles.submitText}>
                    {editingId ? "SALVA MODIFICHE" : "ARRUOLA OPERATORE"}
                  </Text>
                )}
              </Pressable>
            </ScrollView>
          </View>
        </KeyboardAvoidingView>
      </Modal>
    </View>
  );
}

const styles = StyleSheet.create({
  root: { flex: 1, backgroundColor: colors.surface },
  header: {
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "center",
    paddingHorizontal: spacing.lg,
    paddingTop: spacing.md,
    paddingBottom: spacing.sm,
  },
  headerLeft: { flexDirection: "row", alignItems: "center", gap: spacing.md, flex: 1 },
  headerLogo: { width: 44, height: 44 },
  headerLabel: {
    color: colors.brandPrimary,
    fontSize: 9,
    letterSpacing: 2,
    fontWeight: "700",
    marginBottom: 2,
  },
  headerTitle: {
    color: colors.onSurface,
    fontSize: 26,
    fontWeight: "900",
    letterSpacing: 3,
  },
  headerRight: { flexDirection: "row", alignItems: "center", gap: spacing.md },
  counter: {
    alignItems: "center",
    paddingHorizontal: spacing.md,
    paddingVertical: spacing.xs,
    borderWidth: 1,
    borderColor: colors.border,
    borderRadius: radius.sm,
    backgroundColor: colors.surfaceSecondary,
    minWidth: 56,
  },
  counterNum: {
    color: colors.brandPrimary,
    fontSize: 20,
    fontWeight: "900",
    letterSpacing: 1,
  },
  counterLabel: {
    color: colors.onSurfaceSecondary,
    fontSize: 9,
    letterSpacing: 1.5,
    fontWeight: "700",
  },
  iconBtn: { padding: spacing.xs },
  userBar: {
    flexDirection: "row",
    alignItems: "center",
    gap: spacing.xs,
    paddingHorizontal: spacing.lg,
    paddingBottom: spacing.sm,
    borderBottomWidth: 1,
    borderBottomColor: colors.border,
  },
  userText: { color: colors.onSurfaceSecondary, fontSize: 12, flex: 1 },
  rolePill: {
    backgroundColor: colors.brandPrimary,
    paddingHorizontal: spacing.sm,
    paddingVertical: 2,
    borderRadius: 4,
  },
  rolePillText: {
    color: colors.onBrandPrimary,
    fontSize: 9,
    fontWeight: "900",
    letterSpacing: 1.5,
  },
  filterBar: {
    flexDirection: "row",
    alignItems: "center",
    paddingHorizontal: spacing.lg,
    paddingTop: 4,
    paddingBottom: 6,
    gap: 12,
  },
  filterTab: {
    paddingVertical: 2,
    paddingHorizontal: 2,
    minWidth: 0,
  },
  filterTabText: {
    color: colors.onSurfaceSecondary,
    fontSize: 11,
    fontWeight: "700",
    letterSpacing: 0.6,
  },
  filterTabTextActive: {
    color: colors.brandPrimary,
    fontWeight: "900",
  },
  filterTabCount: {
    color: colors.muted,
    fontSize: 10,
    fontWeight: "700",
  },
  filterUnderline: {
    height: 2,
    marginTop: 2,
    backgroundColor: colors.brandPrimary,
    borderRadius: 1,
  },
  loading: { flex: 1, alignItems: "center", justifyContent: "center" },
  card: {
    flex: 1,
    minHeight: 140,
    borderRadius: radius.sm,
    padding: spacing.md,
    justifyContent: "flex-start",
  },
  cardFilled: {
    backgroundColor: colors.surfaceSecondary,
    borderWidth: 1,
    borderColor: colors.border,
    borderLeftWidth: 3,
    borderLeftColor: colors.brandPrimary,
  },
  cardEmpty: {
    backgroundColor: "transparent",
    borderWidth: 1,
    borderColor: colors.border,
    borderStyle: "dashed",
    alignItems: "center",
    justifyContent: "center",
  },
  cardTopRow: {
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "center",
  },
  cardPhoto: {
    width: 56,
    height: 56,
    borderRadius: 28,
    marginTop: spacing.sm,
    marginBottom: spacing.xs,
    borderWidth: 2,
    borderColor: colors.brandPrimary,
    alignSelf: "flex-start",
    backgroundColor: colors.surfaceTertiary,
  },
  cardPhotoPlaceholder: {
    alignItems: "center",
    justifyContent: "center",
    borderColor: colors.border,
  },
  photoPicker: {
    flexDirection: "row",
    alignItems: "center",
    gap: spacing.md,
    backgroundColor: colors.surfaceTertiary,
    borderRadius: radius.sm,
    borderWidth: 1,
    borderColor: colors.border,
    padding: spacing.md,
  },
  photoPreview: {
    width: 64,
    height: 64,
    borderRadius: 32,
    borderWidth: 2,
    borderColor: colors.brandPrimary,
  },
  photoPlaceholder: {
    width: 64,
    height: 64,
    borderRadius: 32,
    borderWidth: 2,
    borderColor: colors.border,
    borderStyle: "dashed",
    alignItems: "center",
    justifyContent: "center",
    backgroundColor: colors.surface,
  },
  photoPickerText: {
    color: colors.brandPrimary,
    fontSize: 13,
    fontWeight: "800",
    letterSpacing: 1.5,
  },
  slotNum: {
    color: colors.muted,
    fontSize: 10,
    fontWeight: "700",
    letterSpacing: 1.5,
  },
  statusDot: {
    width: 6,
    height: 6,
    borderRadius: 3,
    backgroundColor: colors.brandPrimary,
  },
  rankText: {
    color: colors.brandPrimary,
    fontSize: 10,
    letterSpacing: 1.2,
    fontWeight: "800",
    marginTop: spacing.sm,
    lineHeight: 13,
  },
  battleName: {
    color: colors.onSurface,
    fontSize: 17,
    fontWeight: "900",
    letterSpacing: 1,
    marginTop: 2,
  },
  realName: {
    color: colors.onSurfaceSecondary,
    fontSize: 11,
    marginTop: 2,
  },
  phoneRow: {
    flexDirection: "row",
    alignItems: "center",
    gap: spacing.xs,
    marginTop: spacing.xs,
  },
  phone: {
    color: colors.onSurfaceSecondary,
    fontSize: 11,
    flex: 1,
  },
  deptTag: {
    color: colors.muted,
    fontSize: 9,
    letterSpacing: 1.5,
    fontWeight: "700",
    marginTop: spacing.xs,
    borderTopWidth: 1,
    borderTopColor: colors.border,
    paddingTop: spacing.xs,
  },
  deptChipRow: {
    flexDirection: "row",
    flexWrap: "wrap",
    gap: 4,
    marginTop: spacing.sm,
    paddingTop: spacing.xs,
    borderTopWidth: 1,
    borderTopColor: colors.border,
  },
  deptTagChip: {
    paddingHorizontal: spacing.sm,
    paddingVertical: 3,
    borderRadius: 3,
    backgroundColor: colors.brandPrimary,
  },
  deptTagText: {
    color: colors.onBrandPrimary,
    fontSize: 9,
    fontWeight: "900",
    letterSpacing: 1,
  },
  emptyIconWrap: {
    width: 36,
    height: 36,
    borderRadius: 18,
    borderWidth: 1,
    borderColor: colors.borderStrong,
    alignItems: "center",
    justifyContent: "center",
    marginTop: spacing.sm,
  },
  emptyLabel: {
    color: colors.brandPrimary,
    fontSize: 10,
    letterSpacing: 2,
    fontWeight: "800",
    marginTop: spacing.sm,
  },
  modalOverlay: {
    flex: 1,
    backgroundColor: "rgba(0,0,0,0.75)",
    justifyContent: "flex-end",
  },
  modalCard: {
    backgroundColor: colors.surfaceSecondary,
    borderTopWidth: 3,
    borderTopColor: colors.brandPrimary,
    paddingHorizontal: spacing.lg,
    paddingTop: spacing.lg,
    paddingBottom: spacing.xxl,
    maxHeight: "88%",
  },
  modalHeader: {
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "center",
    marginBottom: spacing.md,
  },
  modalTitle: {
    color: colors.onSurface,
    fontSize: 18,
    fontWeight: "900",
    letterSpacing: 2,
  },
  label: {
    color: colors.brandPrimary,
    fontSize: 10,
    letterSpacing: 2,
    fontWeight: "800",
    marginBottom: spacing.xs,
    marginTop: spacing.md,
  },
  input: {
    backgroundColor: colors.surfaceTertiary,
    borderWidth: 1,
    borderColor: colors.border,
    borderRadius: radius.sm,
    color: colors.onSurface,
    paddingHorizontal: spacing.md,
    paddingVertical: spacing.md,
    fontSize: 15,
  },
  help: {
    color: colors.muted,
    fontSize: 11,
    marginTop: spacing.xs,
    lineHeight: 15,
  },
  cardTopRight: {
    flexDirection: "row",
    alignItems: "center",
    gap: spacing.xs,
  },
  editBtn: {
    width: 22,
    height: 22,
    borderRadius: 4,
    borderWidth: 1,
    borderColor: colors.borderStrong,
    alignItems: "center",
    justifyContent: "center",
    backgroundColor: colors.surfaceTertiary,
  },
  deptRow: {
    flexDirection: "row",
    flexWrap: "wrap",
    gap: spacing.sm,
  },
  deptSelector: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "center",
    gap: spacing.xs,
    backgroundColor: colors.surfaceTertiary,
    borderWidth: 1,
    borderColor: colors.border,
    borderRadius: radius.sm,
    paddingHorizontal: spacing.md,
    paddingVertical: spacing.sm,
  },
  deptSelectorActive: {
    backgroundColor: colors.brandPrimary,
    borderColor: colors.brandPrimary,
  },
  deptSelectorText: {
    color: colors.onSurface,
    fontSize: 12,
    fontWeight: "800",
    letterSpacing: 1,
  },
  submitBtn: {
    backgroundColor: colors.brandPrimary,
    paddingVertical: spacing.lg,
    borderRadius: radius.sm,
    alignItems: "center",
    marginTop: spacing.xl,
  },
  submitText: {
    color: colors.onBrandPrimary,
    fontWeight: "900",
    letterSpacing: 2,
    fontSize: 14,
  },
});
