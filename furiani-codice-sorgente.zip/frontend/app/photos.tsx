import React, { useCallback, useMemo, useState } from "react";
import {
  View,
  Text,
  StyleSheet,
  Pressable,
  ScrollView,
  ActivityIndicator,
  RefreshControl,
  Modal,
  Alert,
  TextInput,
  Platform,
  useWindowDimensions,
} from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import { useRouter } from "expo-router";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Ionicons } from "@react-native-vector-icons/ionicons";
import { Image } from "expo-image";
import * as ImagePicker from "expo-image-picker";
import * as Haptics from "expo-haptics";

import { apiJson, apiFetch, BACKEND_URL, getToken } from "@/src/api";
import { useAuth } from "@/src/auth-context";
import { colors, spacing, radius } from "@/src/theme";
import ZoomableImage from "@/src/components/zoomable-image";
import LightboxVideoPlayer from "@/src/components/lightbox-video-player";

type Photo = {
  id: string;
  year: number;
  album: string;
  caption: string;
  filename: string;
  content_type: string;
  is_video?: boolean;
  size: number;
  source: "blog" | "upload" | string;
  source_url?: string | null;
  uploaded_at: string | null;
  post_url?: string | null;
  order: number;
};

type AlbumSummary = {
  year: number;
  album: string;
  count: number;
  cover_id: string | null;
  source: string;
  latest: string | null;
};

type YearSummary = { year: number; count: number; cover_id: string | null };

type AlbumsResponse = { albums: AlbumSummary[]; years: YearSummary[] };

type PhotosResponse = { photos: Photo[] };

function thumbUrl(photoId: string) {
  const token = getToken();
  const q = token ? `?token=${encodeURIComponent(token)}` : "";
  return `${BACKEND_URL}/api/photos/file/${photoId}${q}`;
}

export default function PhotosScreen() {
  const insets = useSafeAreaInsets();
  const router = useRouter();
  const qc = useQueryClient();
  const { width } = useWindowDimensions();
  const { user } = useAuth();
  const isAdmin = user?.role === "admin";
  const isEditor = user?.role === "editor";
  const canEdit = isAdmin || isEditor;

  const [view, setView] = useState<"albums" | "years">("albums");
  const [selected, setSelected] = useState<
    | { kind: "album"; year: number; album: string }
    | { kind: "year"; year: number }
    | null
  >(null);
  const [lightbox, setLightbox] = useState<{ photos: Photo[]; index: number } | null>(null);
  const [uploadOpen, setUploadOpen] = useState(false);
  const [uploadYear, setUploadYear] = useState(new Date().getFullYear().toString());
  const [uploadAlbum, setUploadAlbum] = useState("");
  const [uploadCaption, setUploadCaption] = useState("");
  const [uploading, setUploading] = useState(false);
  const [captionEditOpen, setCaptionEditOpen] = useState(false);
  const [captionDraft, setCaptionDraft] = useState("");
  const [zoomedLightbox, setZoomedLightbox] = useState(false);
  const [selectMode, setSelectMode] = useState(false);
  const [selectedIds, setSelectedIds] = useState<Set<string>>(new Set());

  // Exit selection when leaving an album
  React.useEffect(() => {
    if (!selected || selected.kind !== "album") {
      if (selectMode) setSelectMode(false);
      if (selectedIds.size > 0) setSelectedIds(new Set());
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [selected]);

  const albumsQ = useQuery({
    queryKey: ["photos-albums"],
    queryFn: async () => await apiJson<AlbumsResponse>("/photos/albums"),
    refetchOnWindowFocus: true,
  });

  const selectedQ = useQuery({
    queryKey: [
      "photos-list",
      selected?.kind,
      selected?.year,
      selected?.kind === "album" ? selected.album : null,
    ],
    queryFn: async () => {
      if (!selected) return { photos: [] } as PhotosResponse;
      const parts = [`year=${selected.year}`];
      if (selected.kind === "album") parts.push(`album=${encodeURIComponent(selected.album)}`);
      return await apiJson<PhotosResponse>(`/photos?${parts.join("&")}`);
    },
    enabled: !!selected,
  });

  const deletePhotoMut = useMutation({
    mutationFn: async (id: string) =>
      await apiJson(`/photos/${id}`, { method: "DELETE" }),
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ["photos-list"] });
      qc.invalidateQueries({ queryKey: ["photos-albums"] });
    },
  });

  const batchDeleteMut = useMutation({
    mutationFn: async (ids: string[]) =>
      await apiJson<{ ok: boolean; deleted: number }>(`/photos/batch-delete`, {
        method: "POST",
        body: JSON.stringify({ ids }),
      }),
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ["photos-list"] });
      qc.invalidateQueries({ queryKey: ["photos-albums"] });
    },
  });

  const deleteAlbumMut = useMutation({
    mutationFn: async (p: { year: number; album: string }) =>
      await apiJson<{ ok: boolean; deleted: number }>(
        `/photos/album?year=${p.year}&album=${encodeURIComponent(p.album)}`,
        { method: "DELETE" },
      ),
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ["photos-list"] });
      qc.invalidateQueries({ queryKey: ["photos-albums"] });
    },
  });

  const columns = width >= 900 ? 5 : width >= 600 ? 4 : 3;
  const gridGap = spacing.sm;
  const horizontalPadding = spacing.lg * 2;
  const tileSize = Math.floor((Math.min(width, 1100) - horizontalPadding - gridGap * (columns - 1)) / columns);

  // Group albums by year (for the "per album" view)
  const albumsByYear = useMemo(() => {
    const map = new Map<number, AlbumSummary[]>();
    for (const a of albumsQ.data?.albums || []) {
      const arr = map.get(a.year) || [];
      arr.push(a);
      map.set(a.year, arr);
    }
    return Array.from(map.entries()).sort((a, b) => b[0] - a[0]);
  }, [albumsQ.data]);

  const totals = useMemo(() => {
    const yearsArr = albumsQ.data?.years || [];
    const totalPhotos = yearsArr.reduce((s, y) => s + y.count, 0);
    const totalAlbums = albumsQ.data?.albums.length || 0;
    return { totalPhotos, totalAlbums, totalYears: yearsArr.length };
  }, [albumsQ.data]);

  const handleUpload = useCallback(async () => {
    const year = parseInt(uploadYear, 10);
    if (!uploadAlbum.trim() || isNaN(year) || year < 1900 || year > 2100) {
      Alert.alert("Dati incompleti", "Compila anno (es. 2026) e nome evento/album");
      return;
    }
    try {
      const perm = await ImagePicker.requestMediaLibraryPermissionsAsync();
      if (!perm.granted) {
        if (!perm.canAskAgain) {
          Alert.alert(
            "Permesso negato",
            "Apri Impostazioni per abilitare l'accesso alla galleria.",
          );
        }
        return;
      }
      const res = await ImagePicker.launchImageLibraryAsync({
        mediaTypes: ImagePicker.MediaTypeOptions.All,
        allowsMultipleSelection: true,
        selectionLimit: 30,
        quality: 0.85,
        videoMaxDuration: 180,
      });
      if (res.canceled || !res.assets || res.assets.length === 0) return;

      setUploading(true);
      try { Haptics.selectionAsync(); } catch {}
      const fd = new FormData();
      fd.append("year", String(year));
      fd.append("album", uploadAlbum.trim());
      if (uploadCaption.trim()) fd.append("caption", uploadCaption.trim());
      for (const a of res.assets) {
        if (Platform.OS === "web") {
          const r = await fetch(a.uri);
          const blob = await r.blob();
          const isVideo = (a.type === "video") || (blob.type || "").startsWith("video/");
          fd.append(
            "files",
            new File(
              [blob],
              a.fileName || `media_${Date.now()}.${isVideo ? "mp4" : "jpg"}`,
              { type: blob.type || (isVideo ? "video/mp4" : "image/jpeg") },
            ),
          );
        } else {
          const isVideo = a.type === "video";
          fd.append("files", {
            uri: a.uri,
            name: a.fileName || `media_${Date.now()}.${isVideo ? "mp4" : "jpg"}`,
            type: a.mimeType || (isVideo ? "video/mp4" : "image/jpeg"),
          } as any);
        }
      }
      const resp = await apiFetch(`/photos`, {
        method: "POST",
        body: fd,
      });
      if (!resp.ok) {
        const txt = await resp.text().catch(() => "");
        throw new Error(txt || `HTTP ${resp.status}`);
      }
      const json: any = await resp.json();
      Alert.alert("Caricamento riuscito", `${json.inserted} file caricati`);
      setUploadOpen(false);
      setUploadAlbum("");
      setUploadCaption("");
      qc.invalidateQueries({ queryKey: ["photos-albums"] });
      qc.invalidateQueries({ queryKey: ["photos-list"] });
    } catch (e: any) {
      Alert.alert("Errore caricamento", e?.message || "Riprova");
    } finally {
      setUploading(false);
    }
  }, [uploadAlbum, uploadYear, uploadCaption, qc]);

  const updateCaptionMut = useMutation({
    mutationFn: async (vars: { id: string; caption: string }) =>
      await apiJson<Photo>(`/photos/${vars.id}`, {
        method: "PATCH",
        body: JSON.stringify({ caption: vars.caption }),
      }),
    onSuccess: (updated) => {
      // Patch the lightbox local state so the new caption appears instantly
      setLightbox((lb) => {
        if (!lb) return null;
        return {
          ...lb,
          photos: lb.photos.map((p) =>
            p.id === updated.id ? { ...p, caption: updated.caption } : p,
          ),
        };
      });
      qc.invalidateQueries({ queryKey: ["photos-list"] });
    },
    onError: (e: any) => {
      Alert.alert("Errore", e?.message || "Impossibile salvare la didascalia");
    },
  });

  const exitSelectMode = useCallback(() => {
    setSelectMode(false);
    setSelectedIds(new Set());
  }, []);

  const toggleSelected = useCallback((id: string) => {
    setSelectedIds((prev) => {
      const next = new Set(prev);
      if (next.has(id)) next.delete(id);
      else next.add(id);
      return next;
    });
  }, []);

  const handleBatchDelete = useCallback(() => {
    const ids = Array.from(selectedIds);
    if (ids.length === 0) return;
    const confirmMsg = `Eliminare ${ids.length} ${ids.length === 1 ? "foto" : "foto"} selezionate? L'azione è irreversibile.`;
    const run = () => {
      batchDeleteMut.mutate(ids, {
        onSuccess: (res) => {
          exitSelectMode();
          Alert.alert("Eliminate", `${res?.deleted ?? ids.length} file eliminati`);
        },
        onError: (e: any) => {
          Alert.alert("Errore", e?.message || "Impossibile eliminare la selezione");
        },
      });
    };
    if (Platform.OS === "web") {
      if (typeof window !== "undefined" && window.confirm(confirmMsg)) run();
    } else {
      Alert.alert("Elimina selezione", confirmMsg, [
        { text: "Annulla", style: "cancel" },
        { text: "Elimina", style: "destructive", onPress: run },
      ]);
    }
  }, [selectedIds, batchDeleteMut, exitSelectMode]);

  const handleDeleteAlbum = useCallback(() => {
    if (!selected || selected.kind !== "album") return;
    const { year, album } = selected;
    const confirmMsg = `Svuotare l'album "${album}" (${year})? Verranno eliminate TUTTE le foto e video al suo interno. L'azione è irreversibile.`;
    const run = () => {
      deleteAlbumMut.mutate(
        { year, album },
        {
          onSuccess: (res) => {
            exitSelectMode();
            setSelected(null);
            Alert.alert("Album svuotato", `${res?.deleted ?? 0} file eliminati`);
          },
          onError: (e: any) => {
            Alert.alert("Errore", e?.message || "Impossibile svuotare l'album");
          },
        },
      );
    };
    if (Platform.OS === "web") {
      if (typeof window !== "undefined" && window.confirm(confirmMsg)) run();
    } else {
      Alert.alert("Svuota album", confirmMsg, [
        { text: "Annulla", style: "cancel" },
        { text: "Svuota", style: "destructive", onPress: run },
      ]);
    }
  }, [selected, deleteAlbumMut, exitSelectMode]);

  const handleDelete = useCallback(
    (photo: Photo) => {
      const confirmMsg = `Vuoi eliminare questa foto?${
        photo.caption ? `\n"${photo.caption}"` : ""
      }`;
      const run = () => {
        deletePhotoMut.mutate(photo.id, {
          onSuccess: () => {
            setLightbox((lb) => {
              if (!lb) return null;
              const remaining = lb.photos.filter((p) => p.id !== photo.id);
              if (remaining.length === 0) return null;
              return {
                photos: remaining,
                index: Math.min(lb.index, remaining.length - 1),
              };
            });
          },
          onError: (e: any) => {
            Alert.alert("Errore", e?.message || "Impossibile eliminare la foto");
          },
        });
      };
      if (Platform.OS === "web") {
        if (typeof window !== "undefined" && window.confirm(confirmMsg)) run();
      } else {
        Alert.alert("Elimina foto", confirmMsg, [
          { text: "Annulla", style: "cancel" },
          { text: "Elimina", style: "destructive", onPress: run },
        ]);
      }
    },
    [deletePhotoMut],
  );

  const renderYearGrid = () => {
    const years = albumsQ.data?.years || [];
    if (years.length === 0) {
      return (
        <View style={styles.emptyBox}>
          <Ionicons name="images-outline" size={40} color={colors.onSurfaceSecondary} />
          <Text style={styles.emptyText}>Ancora nessuna foto nell&apos;archivio</Text>
        </View>
      );
    }
    return (
      <View style={[styles.grid, { gap: gridGap }]}>
        {years.map((y) => (
          <Pressable
            key={y.year}
            testID={`year-${y.year}`}
            onPress={() => setSelected({ kind: "year", year: y.year })}
            style={({ pressed }) => [
              styles.yearCard,
              { width: tileSize * 1.5 + gridGap / 2, height: tileSize * 1.5 },
              pressed && { opacity: 0.85 },
            ]}
          >
            {y.cover_id ? (
              <Image
                source={{ uri: thumbUrl(y.cover_id) }}
                style={StyleSheet.absoluteFill}
                contentFit="cover"
              />
            ) : null}
            <View style={styles.yearOverlay}>
              <Text style={styles.yearNumber}>{y.year}</Text>
              <Text style={styles.yearCount}>{y.count} foto</Text>
            </View>
          </Pressable>
        ))}
      </View>
    );
  };

  const renderAlbumsView = () => {
    if (albumsByYear.length === 0) {
      return (
        <View style={styles.emptyBox}>
          <Ionicons name="images-outline" size={40} color={colors.onSurfaceSecondary} />
          <Text style={styles.emptyText}>Ancora nessuna foto nell&apos;archivio</Text>
        </View>
      );
    }
    return (
      <View style={{ gap: spacing.lg }}>
        {albumsByYear.map(([year, albums]) => (
          <View key={year}>
            <View style={styles.yearHeaderRow}>
              <View style={styles.yearBadge}>
                <Text style={styles.yearBadgeText}>{year}</Text>
              </View>
              <Text style={styles.yearHeaderMeta}>
                {albums.reduce((s, a) => s + a.count, 0)} foto · {albums.length} album
              </Text>
            </View>
            <View style={[styles.grid, { gap: gridGap }]}>
              {albums.map((a) => (
                <Pressable
                  key={`${a.year}-${a.album}`}
                  testID={`album-${a.year}-${a.album}`}
                  onPress={() => setSelected({ kind: "album", year: a.year, album: a.album })}
                  style={({ pressed }) => [
                    styles.albumCard,
                    { width: tileSize, height: tileSize * 1.2 },
                    pressed && { opacity: 0.85 },
                  ]}
                >
                  {a.cover_id ? (
                    <Image
                      source={{ uri: thumbUrl(a.cover_id) }}
                      style={styles.albumCover}
                      contentFit="cover"
                    />
                  ) : (
                    <View style={[styles.albumCover, styles.albumCoverFallback]}>
                      <Ionicons name="images" size={28} color={colors.onSurfaceSecondary} />
                    </View>
                  )}
                  <View style={styles.albumMeta}>
                    <Text style={styles.albumTitle} numberOfLines={2}>
                      {a.album}
                    </Text>
                    <View style={styles.albumBottomRow}>
                      <Text style={styles.albumCount}>{a.count} foto</Text>
                      {a.source === "blog" ? (
                        <View style={styles.sourcePill}>
                          <Ionicons name="archive" size={9} color={colors.brandPrimary} />
                          <Text style={styles.sourcePillText}>STORICO</Text>
                        </View>
                      ) : null}
                    </View>
                  </View>
                </Pressable>
              ))}
            </View>
          </View>
        ))}
      </View>
    );
  };

  const renderPhotoGrid = (photos: Photo[]) => (
    <View style={[styles.grid, { gap: gridGap }]}>
      {photos.map((p, idx) => {
        const isSelected = selectedIds.has(p.id);
        const onTap = () => {
          if (selectMode) {
            toggleSelected(p.id);
          } else {
            setLightbox({ photos, index: idx });
          }
        };
        const onLongTap = () => {
          if (!isAdmin) return;
          if (!selectMode) {
            try { Haptics.selectionAsync(); } catch {}
            setSelectMode(true);
          }
          toggleSelected(p.id);
        };
        return (
          <Pressable
            key={p.id}
            onPress={onTap}
            onLongPress={onLongTap}
            delayLongPress={300}
            style={({ pressed }) => [
              styles.photoThumb,
              { width: tileSize, height: tileSize },
              pressed && { opacity: 0.75 },
              isSelected && styles.photoThumbSelected,
            ]}
          >
            {p.is_video ? (
              <View style={[StyleSheet.absoluteFill, styles.videoTile]}>
                <Ionicons name="play-circle" size={48} color={colors.brandPrimary} />
                <Text style={styles.videoTileLabel} numberOfLines={1}>
                  {p.filename}
                </Text>
              </View>
            ) : (
              <Image
                source={{ uri: thumbUrl(p.id) }}
                style={StyleSheet.absoluteFill}
                contentFit="cover"
                transition={200}
              />
            )}
            {selectMode ? (
              <View style={styles.selectOverlay}>
                <View
                  style={[
                    styles.selectCircle,
                    isSelected && styles.selectCircleActive,
                  ]}
                >
                  {isSelected ? (
                    <Ionicons name="checkmark" size={16} color={colors.onBrandPrimary} />
                  ) : null}
                </View>
              </View>
            ) : null}
          </Pressable>
        );
      })}
    </View>
  );

  const detailTitle = (() => {
    if (!selected) return "";
    if (selected.kind === "year") return `${selected.year}`;
    return selected.album;
  })();
  const detailSubtitle = (() => {
    if (!selected) return "";
    if (selected.kind === "year") return "Tutte le foto dell'anno";
    return `${selected.year}`;
  })();

  return (
    <View style={[styles.root, { paddingTop: insets.top }]} testID="photos-screen">
      <View style={styles.header}>
        <Pressable
          onPress={() => {
            if (selectMode) {
              exitSelectMode();
              return;
            }
            if (selected) setSelected(null);
            else router.back();
          }}
          style={styles.iconChip}
          hitSlop={6}
        >
          <Ionicons
            name={selectMode ? "close" : "chevron-back"}
            size={22}
            color={colors.onSurface}
          />
        </Pressable>
        <View style={{ flex: 1 }}>
          <Text style={styles.headerLabel}>
            {selectMode
              ? "SELEZIONE"
              : selected
              ? detailSubtitle.toUpperCase()
              : "FURIANI GESTIONALE"}
          </Text>
          <Text style={styles.headerTitle} numberOfLines={1}>
            {selectMode
              ? `${selectedIds.size} selezionate`
              : selected
              ? detailTitle
              : "ARCHIVIO FOTO"}
          </Text>
        </View>
        {!selected ? (
          <Pressable
            testID="private-area-btn"
            onPress={() => router.push("/private-photos")}
            style={[styles.iconChip, styles.privateBtn]}
            hitSlop={6}
          >
            <Ionicons name="lock-closed" size={16} color={colors.brandPrimary} />
          </Pressable>
        ) : null}
        {canEdit && !selected ? (
          <Pressable
            testID="upload-photo-btn"
            onPress={() => setUploadOpen(true)}
            style={[styles.iconChip, styles.uploadBtn]}
            hitSlop={6}
          >
            <Ionicons name="cloud-upload" size={18} color={colors.onBrandPrimary} />
          </Pressable>
        ) : null}
        {/* Album actions (admin only, inside an album, not in select mode) */}
        {isAdmin && selected?.kind === "album" && !selectMode ? (
          <>
            <Pressable
              testID="select-mode-btn"
              onPress={() => setSelectMode(true)}
              style={styles.iconChip}
              hitSlop={6}
            >
              <Ionicons
                name="checkmark-circle-outline"
                size={20}
                color={colors.brandPrimary}
              />
            </Pressable>
            <Pressable
              testID="delete-album-btn"
              onPress={handleDeleteAlbum}
              style={[styles.iconChip, { backgroundColor: colors.error }]}
              hitSlop={6}
            >
              <Ionicons name="trash" size={18} color={colors.onBrandPrimary} />
            </Pressable>
          </>
        ) : null}
        {/* Delete selection button in select mode */}
        {selectMode ? (
          <Pressable
            testID="batch-delete-btn"
            onPress={handleBatchDelete}
            disabled={selectedIds.size === 0 || batchDeleteMut.isPending}
            style={[
              styles.iconChip,
              { backgroundColor: colors.error },
              (selectedIds.size === 0 || batchDeleteMut.isPending) && { opacity: 0.4 },
            ]}
            hitSlop={6}
          >
            {batchDeleteMut.isPending ? (
              <ActivityIndicator color={colors.onBrandPrimary} size="small" />
            ) : (
              <Ionicons name="trash" size={18} color={colors.onBrandPrimary} />
            )}
          </Pressable>
        ) : null}
      </View>

      {!selected ? (
        <>
          <View style={styles.topBar}>
            <View style={styles.selector}>
              <Pressable
                testID="view-albums"
                onPress={() => setView("albums")}
                style={[styles.selectorBtn, view === "albums" && styles.selectorBtnActive]}
              >
                <Text
                  style={[styles.selectorText, view === "albums" && styles.selectorTextActive]}
                >
                  PER EVENTO
                </Text>
              </Pressable>
              <Pressable
                testID="view-years"
                onPress={() => setView("years")}
                style={[styles.selectorBtn, view === "years" && styles.selectorBtnActive]}
              >
                <Text
                  style={[styles.selectorText, view === "years" && styles.selectorTextActive]}
                >
                  PER ANNO
                </Text>
              </Pressable>
            </View>
            <View style={styles.statRow}>
              <View style={styles.stat}>
                <Text style={styles.statValue}>{totals.totalPhotos}</Text>
                <Text style={styles.statLabel}>foto</Text>
              </View>
              <View style={styles.stat}>
                <Text style={styles.statValue}>{totals.totalAlbums}</Text>
                <Text style={styles.statLabel}>album</Text>
              </View>
              <View style={styles.stat}>
                <Text style={styles.statValue}>{totals.totalYears}</Text>
                <Text style={styles.statLabel}>anni</Text>
              </View>
            </View>
          </View>

          <ScrollView
            contentContainerStyle={styles.scrollContent}
            refreshControl={
              <RefreshControl
                refreshing={albumsQ.isFetching && !albumsQ.isLoading}
                onRefresh={() => albumsQ.refetch()}
                tintColor={colors.brandPrimary}
              />
            }
          >
            {albumsQ.isLoading ? (
              <View style={[styles.center, { paddingVertical: spacing.xxl }]}>
                <ActivityIndicator color={colors.brandPrimary} size="large" />
              </View>
            ) : view === "years" ? (
              renderYearGrid()
            ) : (
              renderAlbumsView()
            )}
          </ScrollView>
        </>
      ) : (
        <ScrollView
          contentContainerStyle={styles.scrollContent}
          refreshControl={
            <RefreshControl
              refreshing={selectedQ.isFetching && !selectedQ.isLoading}
              onRefresh={() => selectedQ.refetch()}
              tintColor={colors.brandPrimary}
            />
          }
        >
          {selectedQ.isLoading ? (
            <View style={[styles.center, { paddingVertical: spacing.xxl }]}>
              <ActivityIndicator color={colors.brandPrimary} size="large" />
            </View>
          ) : (
            renderPhotoGrid(selectedQ.data?.photos || [])
          )}
        </ScrollView>
      )}

      {/* Lightbox */}
      <Modal
        visible={!!lightbox}
        transparent
        animationType="fade"
        onRequestClose={() => setLightbox(null)}
      >
        {lightbox ? (
          <View style={styles.lightboxRoot}>
            <View style={[styles.lightboxTop, { paddingTop: insets.top + spacing.sm }]}>
              <Text style={styles.lightboxCount}>
                {lightbox.index + 1} / {lightbox.photos.length}
              </Text>
              <View style={{ flex: 1 }} />
              {canEdit ? (
                <Pressable
                  testID="download-photo-btn"
                  onPress={() => {
                    const p = lightbox.photos[lightbox.index];
                    if (Platform.OS === "web" && typeof window !== "undefined") {
                      const a = window.document.createElement("a");
                      a.href = thumbUrl(p.id);
                      a.download = p.filename || `photo_${p.id}.jpg`;
                      a.target = "_blank";
                      window.document.body.appendChild(a);
                      a.click();
                      a.remove();
                    } else {
                      Alert.alert(
                        "Download",
                        "Il download diretto è disponibile dalla preview web.",
                      );
                    }
                  }}
                  style={styles.lightboxBtn}
                  hitSlop={6}
                >
                  <Ionicons name="download" size={20} color={colors.brandPrimary} />
                </Pressable>
              ) : null}
              {isAdmin ? (
                <Pressable
                  onPress={() => handleDelete(lightbox.photos[lightbox.index])}
                  style={styles.lightboxBtn}
                  hitSlop={6}
                >
                  <Ionicons name="trash" size={20} color={colors.error} />
                </Pressable>
              ) : null}
              <Pressable
                onPress={() => setLightbox(null)}
                style={styles.lightboxBtn}
                hitSlop={6}
              >
                <Ionicons name="close" size={24} color={colors.onSurface} />
              </Pressable>
            </View>

            <View style={styles.lightboxImageWrap}>
              {lightbox.photos[lightbox.index].is_video ? (
                <LightboxVideoPlayer
                  key={lightbox.photos[lightbox.index].id}
                  uri={thumbUrl(lightbox.photos[lightbox.index].id)}
                  filename={lightbox.photos[lightbox.index].filename}
                />
              ) : (
                <ZoomableImage
                  uri={thumbUrl(lightbox.photos[lightbox.index].id)}
                  style={styles.lightboxImage}
                  contentFit="contain"
                  onZoomedChange={setZoomedLightbox}
                />
              )}
            </View>

            <View style={[styles.lightboxBottom, { paddingBottom: insets.bottom + spacing.sm }]}>
              <Pressable
                onPress={() =>
                  setLightbox((lb) =>
                    lb ? { ...lb, index: Math.max(0, lb.index - 1) } : lb,
                  )
                }
                disabled={lightbox.index === 0 || zoomedLightbox}
                style={[
                  styles.navBtn,
                  (lightbox.index === 0 || zoomedLightbox) && { opacity: 0.3 },
                ]}
                hitSlop={6}
              >
                <Ionicons name="chevron-back" size={28} color={colors.onSurface} />
              </Pressable>
              <View style={{ flex: 1, alignItems: "center" }}>
                <Text style={styles.lightboxAlbum} numberOfLines={1}>
                  {lightbox.photos[lightbox.index].album}
                </Text>
                <Text style={styles.lightboxYear}>{lightbox.photos[lightbox.index].year}</Text>
                {lightbox.photos[lightbox.index].caption ? (
                  <Text style={styles.lightboxCaption} numberOfLines={3}>
                    {lightbox.photos[lightbox.index].caption}
                  </Text>
                ) : null}
                {isAdmin ? (
                  <Pressable
                    testID="edit-caption-btn"
                    onPress={() => {
                      setCaptionDraft(lightbox.photos[lightbox.index].caption || "");
                      setCaptionEditOpen(true);
                    }}
                    style={styles.editCaptionBtn}
                    hitSlop={6}
                  >
                    <Ionicons
                      name={
                        lightbox.photos[lightbox.index].caption
                          ? "create-outline"
                          : "add-circle-outline"
                      }
                      size={13}
                      color={colors.brandPrimary}
                    />
                    <Text style={styles.editCaptionBtnText}>
                      {lightbox.photos[lightbox.index].caption
                        ? "MODIFICA DIDASCALIA"
                        : "AGGIUNGI DIDASCALIA"}
                    </Text>
                  </Pressable>
                ) : null}
                <Text style={styles.zoomHint}>Pizzica per zoom · Doppio tap</Text>
              </View>
              <Pressable
                onPress={() =>
                  setLightbox((lb) =>
                    lb
                      ? { ...lb, index: Math.min(lb.photos.length - 1, lb.index + 1) }
                      : lb,
                  )
                }
                disabled={
                  lightbox.index === lightbox.photos.length - 1 || zoomedLightbox
                }
                style={[
                  styles.navBtn,
                  (lightbox.index === lightbox.photos.length - 1 || zoomedLightbox) && {
                    opacity: 0.3,
                  },
                ]}
                hitSlop={6}
              >
                <Ionicons name="chevron-forward" size={28} color={colors.onSurface} />
              </Pressable>
            </View>
          </View>
        ) : null}
      </Modal>

      {/* Upload modal */}
      <Modal
        visible={uploadOpen}
        transparent
        animationType="fade"
        onRequestClose={() => setUploadOpen(false)}
      >
        <View style={styles.modalBackdrop}>
          <View style={styles.modalCard}>
            <View style={styles.modalHeader}>
              <Text style={styles.modalTitle}>CARICA FOTO E VIDEO</Text>
              <Pressable onPress={() => setUploadOpen(false)} hitSlop={8}>
                <Ionicons name="close" size={22} color={colors.onSurfaceSecondary} />
              </Pressable>
            </View>
            <Text style={styles.modalHint}>
              Indica anno (obbligatorio) e nome evento/album (obbligatorio). Puoi
              selezionare più foto o video in una volta (max 200 MB per file).
            </Text>

            <Text style={styles.inputLabel}>ANNO</Text>
            <TextInput
              testID="upload-year"
              value={uploadYear}
              onChangeText={(t) => setUploadYear(t.replace(/[^0-9]/g, "").slice(0, 4))}
              placeholder="2026"
              placeholderTextColor={colors.muted}
              style={styles.input}
              keyboardType="number-pad"
              maxLength={4}
            />
            <Text style={styles.inputLabel}>NOME EVENTO / ALBUM</Text>
            <TextInput
              testID="upload-album"
              value={uploadAlbum}
              onChangeText={setUploadAlbum}
              placeholder="Es. Torneo La Fortezza V - giugno 2026"
              placeholderTextColor={colors.muted}
              style={styles.input}
            />
            <Text style={styles.inputLabel}>DIDASCALIA (facoltativa)</Text>
            <TextInput
              testID="upload-caption"
              value={uploadCaption}
              onChangeText={setUploadCaption}
              placeholder="Es. Luogo, operatori presenti, dettagli…"
              placeholderTextColor={colors.muted}
              style={[styles.input, { minHeight: 70, textAlignVertical: "top" }]}
              multiline
              maxLength={500}
            />

            <View style={styles.modalActions}>
              <Pressable
                style={[styles.modalBtn, styles.modalBtnGhost]}
                onPress={() => setUploadOpen(false)}
                disabled={uploading}
              >
                <Text style={styles.modalBtnGhostText}>ANNULLA</Text>
              </Pressable>
              <Pressable
                testID="upload-start"
                style={[styles.modalBtn, styles.modalBtnPrimary]}
                onPress={handleUpload}
                disabled={uploading}
              >
                {uploading ? (
                  <ActivityIndicator color={colors.onBrandPrimary} />
                ) : (
                  <View style={{ flexDirection: "row", alignItems: "center", gap: 6 }}>
                    <Ionicons name="cloud-upload" size={14} color={colors.onBrandPrimary} />
                    <Text style={styles.modalBtnPrimaryText}>SCEGLI FOTO</Text>
                  </View>
                )}
              </Pressable>
            </View>
          </View>
        </View>
      </Modal>

      {/* Caption edit modal */}
      <Modal
        visible={captionEditOpen}
        transparent
        animationType="fade"
        onRequestClose={() => setCaptionEditOpen(false)}
      >
        <View style={styles.modalBackdrop}>
          <View style={styles.modalCard}>
            <View style={styles.modalHeader}>
              <Text style={styles.modalTitle}>DIDASCALIA FOTO</Text>
              <Pressable onPress={() => setCaptionEditOpen(false)} hitSlop={8}>
                <Ionicons name="close" size={22} color={colors.onSurfaceSecondary} />
              </Pressable>
            </View>
            <TextInput
              testID="caption-input"
              value={captionDraft}
              onChangeText={setCaptionDraft}
              placeholder="Nomi operatori, luogo, dettagli…"
              placeholderTextColor={colors.muted}
              style={[styles.input, { minHeight: 110, textAlignVertical: "top" }]}
              multiline
              autoFocus
              maxLength={500}
            />
            <Text style={styles.captionCounter}>{captionDraft.length}/500</Text>
            <View style={styles.modalActions}>
              <Pressable
                style={[styles.modalBtn, styles.modalBtnGhost]}
                onPress={() => setCaptionEditOpen(false)}
                disabled={updateCaptionMut.isPending}
              >
                <Text style={styles.modalBtnGhostText}>ANNULLA</Text>
              </Pressable>
              <Pressable
                style={[styles.modalBtn, styles.modalBtnPrimary]}
                onPress={() => {
                  const current = lightbox?.photos[lightbox.index];
                  if (!current) return;
                  updateCaptionMut.mutate(
                    { id: current.id, caption: captionDraft },
                    { onSuccess: () => setCaptionEditOpen(false) },
                  );
                }}
                disabled={updateCaptionMut.isPending}
              >
                {updateCaptionMut.isPending ? (
                  <ActivityIndicator color={colors.onBrandPrimary} />
                ) : (
                  <Text style={styles.modalBtnPrimaryText}>SALVA</Text>
                )}
              </Pressable>
            </View>
          </View>
        </View>
      </Modal>
    </View>
  );
}

const styles = StyleSheet.create({
  root: { flex: 1, backgroundColor: colors.surface },
  center: { alignItems: "center", justifyContent: "center" },
  header: {
    flexDirection: "row",
    alignItems: "center",
    gap: spacing.sm,
    paddingHorizontal: spacing.lg,
    paddingVertical: spacing.md,
    borderBottomWidth: StyleSheet.hairlineWidth,
    borderBottomColor: colors.border,
  },
  iconChip: {
    width: 36,
    height: 36,
    borderRadius: radius.lg,
    backgroundColor: colors.surfaceSecondary,
    alignItems: "center",
    justifyContent: "center",
    borderWidth: StyleSheet.hairlineWidth,
    borderColor: colors.border,
  },
  uploadBtn: {
    backgroundColor: colors.brandPrimary,
    borderColor: colors.brandPrimary,
  },
  privateBtn: {
    backgroundColor: colors.brandTertiary,
    borderColor: colors.brandPrimary,
  },
  headerLabel: {
    color: colors.brandPrimary,
    fontSize: 10,
    letterSpacing: 2,
    fontWeight: "800",
  },
  headerTitle: {
    color: colors.onSurface,
    fontSize: 20,
    fontWeight: "900",
    letterSpacing: 1.5,
  },

  topBar: {
    paddingHorizontal: spacing.lg,
    paddingVertical: spacing.md,
    gap: spacing.sm,
    borderBottomWidth: StyleSheet.hairlineWidth,
    borderBottomColor: colors.border,
  },
  selector: {
    flexDirection: "row",
    backgroundColor: colors.surfaceTertiary,
    borderRadius: radius.lg,
    padding: 2,
    alignSelf: "flex-start",
  },
  selectorBtn: {
    paddingHorizontal: spacing.md,
    paddingVertical: 6,
    borderRadius: radius.md,
  },
  selectorBtnActive: { backgroundColor: colors.brandPrimary },
  selectorText: {
    color: colors.onSurfaceSecondary,
    fontSize: 10,
    fontWeight: "800",
    letterSpacing: 1,
  },
  selectorTextActive: { color: colors.onBrandPrimary },

  statRow: { flexDirection: "row", gap: spacing.md, marginTop: 4 },
  stat: {
    flexDirection: "row",
    alignItems: "baseline",
    gap: 4,
  },
  statValue: {
    color: colors.brandPrimary,
    fontSize: 15,
    fontWeight: "900",
    letterSpacing: 0.5,
  },
  statLabel: {
    color: colors.onSurfaceSecondary,
    fontSize: 11,
    fontWeight: "700",
  },

  scrollContent: {
    padding: spacing.lg,
    paddingBottom: spacing.xxl,
  },
  grid: {
    flexDirection: "row",
    flexWrap: "wrap",
    alignItems: "flex-start",
  },

  yearCard: {
    borderRadius: radius.lg,
    overflow: "hidden",
    backgroundColor: colors.surfaceSecondary,
    borderWidth: StyleSheet.hairlineWidth,
    borderColor: colors.border,
  },
  yearOverlay: {
    position: "absolute",
    bottom: 0,
    left: 0,
    right: 0,
    padding: spacing.md,
    backgroundColor: "rgba(0,0,0,0.55)",
  },
  yearNumber: {
    color: colors.onSurface,
    fontSize: 36,
    fontWeight: "900",
    letterSpacing: 2,
  },
  yearCount: {
    color: colors.brandPrimary,
    fontSize: 11,
    fontWeight: "800",
    letterSpacing: 1,
    marginTop: 2,
  },

  yearHeaderRow: {
    flexDirection: "row",
    alignItems: "center",
    gap: spacing.sm,
    marginBottom: spacing.sm,
  },
  yearBadge: {
    paddingHorizontal: spacing.md,
    paddingVertical: 4,
    borderRadius: radius.md,
    backgroundColor: colors.brandPrimary,
  },
  yearBadgeText: {
    color: colors.onBrandPrimary,
    fontSize: 14,
    fontWeight: "900",
    letterSpacing: 2,
  },
  yearHeaderMeta: {
    color: colors.onSurfaceSecondary,
    fontSize: 11,
    fontWeight: "700",
  },

  albumCard: {
    borderRadius: radius.lg,
    overflow: "hidden",
    backgroundColor: colors.surfaceSecondary,
    borderWidth: StyleSheet.hairlineWidth,
    borderColor: colors.border,
  },
  albumCover: {
    flex: 1,
    width: "100%",
    backgroundColor: colors.surfaceTertiary,
  },
  albumCoverFallback: {
    alignItems: "center",
    justifyContent: "center",
  },
  albumMeta: {
    padding: spacing.sm,
    gap: 4,
  },
  albumTitle: {
    color: colors.onSurface,
    fontSize: 11,
    fontWeight: "800",
    lineHeight: 14,
  },
  albumBottomRow: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
    gap: 4,
  },
  albumCount: {
    color: colors.brandPrimary,
    fontSize: 10,
    fontWeight: "900",
  },
  sourcePill: {
    flexDirection: "row",
    alignItems: "center",
    gap: 2,
    paddingHorizontal: 5,
    paddingVertical: 1,
    borderRadius: radius.pill,
    backgroundColor: colors.brandTertiary,
  },
  sourcePillText: {
    color: colors.brandPrimary,
    fontSize: 8,
    fontWeight: "900",
    letterSpacing: 1,
  },

  photoThumb: {
    borderRadius: radius.md,
    overflow: "hidden",
    backgroundColor: colors.surfaceSecondary,
  },
  photoThumbSelected: {
    borderWidth: 3,
    borderColor: colors.brandPrimary,
  },
  selectOverlay: {
    position: "absolute",
    top: 6,
    right: 6,
  },
  selectCircle: {
    width: 24,
    height: 24,
    borderRadius: 12,
    backgroundColor: "rgba(0,0,0,0.5)",
    borderWidth: 2,
    borderColor: "rgba(255,255,255,0.9)",
    alignItems: "center",
    justifyContent: "center",
  },
  selectCircleActive: {
    backgroundColor: colors.brandPrimary,
    borderColor: colors.brandPrimary,
  },
  videoTile: {
    alignItems: "center",
    justifyContent: "center",
    backgroundColor: colors.surfaceSecondary,
    gap: 4,
  },
  videoTileLabel: {
    color: colors.onSurfaceSecondary,
    fontSize: 9,
    paddingHorizontal: 4,
    textAlign: "center",
  },

  emptyBox: {
    alignItems: "center",
    paddingVertical: spacing.xxl,
    gap: spacing.sm,
  },
  emptyText: {
    color: colors.onSurfaceSecondary,
    fontSize: 13,
  },

  // Lightbox
  lightboxRoot: {
    flex: 1,
    backgroundColor: "rgba(0,0,0,0.95)",
  },
  lightboxTop: {
    flexDirection: "row",
    alignItems: "center",
    paddingHorizontal: spacing.lg,
    gap: spacing.sm,
  },
  lightboxCount: {
    color: colors.onSurface,
    fontSize: 13,
    fontWeight: "800",
    letterSpacing: 1,
  },
  lightboxBtn: {
    width: 40,
    height: 40,
    borderRadius: 20,
    alignItems: "center",
    justifyContent: "center",
    backgroundColor: "rgba(255,255,255,0.08)",
  },
  lightboxImageWrap: {
    flex: 1,
    padding: spacing.sm,
  },
  lightboxImage: {
    width: "100%",
    height: "100%",
  },
  lightboxBottom: {
    flexDirection: "row",
    alignItems: "center",
    paddingHorizontal: spacing.lg,
    paddingTop: spacing.sm,
    gap: spacing.sm,
  },
  navBtn: {
    width: 44,
    height: 44,
    borderRadius: 22,
    alignItems: "center",
    justifyContent: "center",
    backgroundColor: "rgba(255,255,255,0.08)",
  },
  lightboxAlbum: {
    color: colors.onSurface,
    fontSize: 13,
    fontWeight: "800",
    textAlign: "center",
    paddingHorizontal: spacing.sm,
  },
  lightboxYear: {
    color: colors.brandPrimary,
    fontSize: 11,
    fontWeight: "700",
    letterSpacing: 1,
    marginTop: 2,
  },
  lightboxCaption: {
    color: colors.onSurface,
    fontSize: 12,
    marginTop: 6,
    textAlign: "center",
    paddingHorizontal: spacing.sm,
    fontStyle: "italic",
    lineHeight: 16,
  },
  editCaptionBtn: {
    flexDirection: "row",
    alignItems: "center",
    gap: 4,
    marginTop: 6,
    paddingHorizontal: spacing.sm,
    paddingVertical: 4,
    borderRadius: radius.pill,
    borderWidth: StyleSheet.hairlineWidth,
    borderColor: colors.brandPrimary,
  },
  editCaptionBtnText: {
    color: colors.brandPrimary,
    fontSize: 10,
    fontWeight: "900",
    letterSpacing: 1,
  },
  zoomHint: {
    color: colors.onSurfaceSecondary,
    fontSize: 9,
    marginTop: 6,
    fontWeight: "600",
    letterSpacing: 1,
    opacity: 0.6,
  },
  captionCounter: {
    color: colors.onSurfaceSecondary,
    fontSize: 10,
    textAlign: "right",
    marginTop: 4,
    fontWeight: "700",
  },

  // Upload modal
  modalBackdrop: {
    flex: 1,
    backgroundColor: "rgba(0,0,0,0.6)",
    justifyContent: "center",
    alignItems: "center",
    padding: spacing.lg,
  },
  modalCard: {
    backgroundColor: colors.surfaceSecondary,
    borderRadius: radius.lg,
    padding: spacing.lg,
    width: "100%",
    maxWidth: 440,
    borderWidth: StyleSheet.hairlineWidth,
    borderColor: colors.border,
  },
  modalHeader: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
    marginBottom: spacing.sm,
  },
  modalTitle: {
    color: colors.onSurface,
    fontSize: 14,
    fontWeight: "900",
    letterSpacing: 2,
  },
  modalHint: {
    color: colors.onSurfaceSecondary,
    fontSize: 11,
    fontStyle: "italic",
    marginBottom: spacing.md,
  },
  inputLabel: {
    color: colors.brandPrimary,
    fontSize: 10,
    fontWeight: "900",
    letterSpacing: 2,
    marginTop: spacing.sm,
    marginBottom: 4,
  },
  input: {
    backgroundColor: colors.surfaceTertiary,
    borderRadius: radius.lg,
    paddingHorizontal: spacing.md,
    paddingVertical: spacing.sm,
    color: colors.onSurface,
    fontSize: 14,
    borderWidth: StyleSheet.hairlineWidth,
    borderColor: colors.border,
  },
  modalActions: {
    flexDirection: "row",
    gap: spacing.sm,
    marginTop: spacing.lg,
  },
  modalBtn: {
    flex: 1,
    paddingVertical: spacing.md,
    borderRadius: radius.lg,
    alignItems: "center",
    justifyContent: "center",
  },
  modalBtnGhost: {
    backgroundColor: colors.surfaceTertiary,
    borderWidth: StyleSheet.hairlineWidth,
    borderColor: colors.border,
  },
  modalBtnGhostText: {
    color: colors.onSurfaceSecondary,
    fontWeight: "900",
    letterSpacing: 2,
    fontSize: 12,
  },
  modalBtnPrimary: {
    backgroundColor: colors.brandPrimary,
  },
  modalBtnPrimaryText: {
    color: colors.onBrandPrimary,
    fontWeight: "900",
    letterSpacing: 2,
    fontSize: 12,
  },
});
