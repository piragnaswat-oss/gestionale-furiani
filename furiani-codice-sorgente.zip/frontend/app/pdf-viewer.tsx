import React, { useEffect, useMemo, useState } from "react";
import {
  View,
  Text,
  StyleSheet,
  Pressable,
  ActivityIndicator,
  Platform,
  ScrollView,
  Alert,
  useWindowDimensions,
} from "react-native";
import { useLocalSearchParams, useRouter } from "expo-router";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import { Ionicons } from "@react-native-vector-icons/ionicons";
import { Image } from "expo-image";

import { colors, spacing, radius } from "@/src/theme";
import { apiJson, BACKEND_URL } from "@/src/api";
import { useAuth } from "@/src/auth-context";

type FileInfo = {
  file_id?: string;
  filename: string;
  content_type: string;
  is_pdf: boolean;
  pages: number;
};

export default function PdfViewerScreen() {
  const insets = useSafeAreaInsets();
  const router = useRouter();
  const { user } = useAuth();
  const isAdmin = user?.role === "admin";
  const { opId, kind, fileId, title, token } = useLocalSearchParams<{
    opId?: string;
    kind?: string;
    fileId?: string;
    title?: string;
    token?: string;
  }>();
  const { width } = useWindowDimensions();
  const [info, setInfo] = useState<FileInfo | null>(null);
  const [infoError, setInfoError] = useState<string | null>(null);

  const docTitle = typeof title === "string" ? decodeURIComponent(title) : "DOCUMENTO";
  const opIdStr = typeof opId === "string" ? opId : "";
  const kindStr = typeof kind === "string" ? kind : "";
  const fileIdStr = typeof fileId === "string" ? fileId : "";
  const tokenStr = typeof token === "string" ? token : "";

  const infoUrl = useMemo(() => {
    if (!opIdStr || !kindStr) return "";
    const q = new URLSearchParams();
    if (fileIdStr) q.set("file_id", fileIdStr);
    const qs = q.toString();
    return `/files/${opIdStr}/${kindStr}/info${qs ? `?${qs}` : ""}`;
  }, [opIdStr, kindStr, fileIdStr]);

  const pageUrl = (pageIndex: number) => {
    const q = new URLSearchParams();
    if (fileIdStr) q.set("file_id", fileIdStr);
    if (tokenStr) q.set("token", tokenStr);
    q.set("v", String(pageIndex));
    return `${BACKEND_URL}/api/files/${opIdStr}/${kindStr}/page/${pageIndex}?${q.toString()}`;
  };

  useEffect(() => {
    if (!infoUrl) return;
    let cancel = false;
    (async () => {
      try {
        const data = await apiJson<FileInfo>(infoUrl);
        if (!cancel) setInfo(data);
      } catch (e: any) {
        if (!cancel) setInfoError(e?.message || "Impossibile caricare il documento");
      }
    })();
    return () => {
      cancel = true;
    };
  }, [infoUrl]);

  // Admin-only: scarica il file originale (editori sempre bloccati dal backend).
  const handleAdminDownload = () => {
    if (!isAdmin) return;
    const confirmMsg =
      "Scaricare il documento originale per manutenzione?\n\n" +
      "⚠️ Questo è un privilegio admin: il file verrà salvato in chiaro sul tuo dispositivo. " +
      "Usalo solo se necessario (es. invio alla federazione).";
    const run = () => {
      const q = new URLSearchParams();
      if (fileIdStr) q.set("file_id", fileIdStr);
      if (tokenStr) q.set("token", tokenStr);
      const dlUrl = `${BACKEND_URL}/api/files/${opIdStr}/${kindStr}?${q.toString()}`;
      if (Platform.OS === "web" && typeof window !== "undefined") {
        const a = window.document.createElement("a");
        a.href = dlUrl;
        a.download = info?.filename || `${kindStr}_${opIdStr}`;
        a.rel = "noopener noreferrer";
        window.document.body.appendChild(a);
        a.click();
        a.remove();
      } else {
        // Native: apre nel browser esterno dove l'utente può salvare
        import("expo-linking").then(({ default: Linking }) => Linking.openURL(dlUrl));
      }
    };
    if (Platform.OS === "web") {
      if (typeof window !== "undefined" && window.confirm(confirmMsg)) run();
    } else {
      Alert.alert("Scarica originale", confirmMsg, [
        { text: "Annulla", style: "cancel" },
        { text: "Scarica", style: "destructive", onPress: run },
      ]);
    }
  };

  // Disable right-click / long-press context menu + text selection + Ctrl+S on web.
  useEffect(() => {
    if (Platform.OS !== "web" || typeof window === "undefined") return;
    const blockEvt = (e: Event) => {
      e.preventDefault();
      return false;
    };
    const blockKeys = (e: KeyboardEvent) => {
      const key = (e.key || "").toLowerCase();
      // Block Ctrl/Cmd+S, Ctrl/Cmd+P (save, print)
      if ((e.ctrlKey || e.metaKey) && (key === "s" || key === "p")) {
        e.preventDefault();
        e.stopPropagation();
      }
    };
    window.addEventListener("contextmenu", blockEvt);
    window.addEventListener("dragstart", blockEvt);
    window.addEventListener("keydown", blockKeys);
    return () => {
      window.removeEventListener("contextmenu", blockEvt);
      window.removeEventListener("dragstart", blockEvt);
      window.removeEventListener("keydown", blockKeys);
    };
  }, []);

  const pageWidth = Math.min(width, 1100) - spacing.lg * 2;
  const userLabel = (user?.name || user?.email || "SOLA LETTURA").toUpperCase();

  if (!opIdStr || !kindStr) {
    return (
      <View style={[styles.root, styles.center]}>
        <Ionicons name="alert-circle" size={48} color={colors.error} />
        <Text style={styles.errorTitle}>Parametri mancanti</Text>
      </View>
    );
  }

  return (
    <View style={[styles.root, { paddingTop: insets.top }]} testID="pdf-viewer-screen">
      <View style={styles.header}>
        <Pressable
          onPress={() => router.back()}
          style={styles.iconChip}
          hitSlop={6}
          testID="pdf-viewer-back"
        >
          <Ionicons name="chevron-back" size={22} color={colors.onSurface} />
        </Pressable>
        <View style={{ flex: 1 }}>
          <Text style={styles.headerLabel}>
            {isAdmin ? "DOCUMENTO · ADMIN" : "DOCUMENTO · SOLA LETTURA"}
          </Text>
          <Text style={styles.headerTitle} numberOfLines={1}>
            {docTitle}
          </Text>
        </View>
        {isAdmin ? (
          <Pressable
            onPress={handleAdminDownload}
            style={[styles.iconChip, styles.downloadBtn]}
            hitSlop={6}
            testID="pdf-viewer-admin-download"
          >
            <Ionicons name="download" size={18} color={colors.onBrandPrimary} />
          </Pressable>
        ) : (
          <View style={[styles.iconChip, { backgroundColor: "transparent", borderWidth: 0 }]}>
            <Ionicons name="eye" size={18} color={colors.brandPrimary} />
          </View>
        )}
      </View>

      <ScrollView
        style={styles.viewerWrap}
        contentContainerStyle={styles.scrollContent}
        showsVerticalScrollIndicator
      >
        {infoError ? (
          <View style={[styles.center, { padding: spacing.xl }]}>
            <Ionicons name="alert-circle" size={44} color={colors.error} />
            <Text style={styles.errorTitle}>Errore</Text>
            <Text style={styles.hint}>{infoError}</Text>
          </View>
        ) : !info ? (
          <View style={[styles.center, { padding: spacing.xxl }]}>
            <ActivityIndicator color={colors.brandPrimary} size="large" />
            <Text style={styles.hint}>Caricamento documento…</Text>
          </View>
        ) : (
          <View style={{ gap: spacing.md, alignItems: "center" }}>
            {Array.from({ length: info.pages }).map((_, idx) => (
              <PageImage
                key={idx}
                src={pageUrl(idx)}
                pageWidth={pageWidth}
                pageIndex={idx + 1}
                total={info.pages}
                watermark={userLabel}
              />
            ))}
          </View>
        )}
      </ScrollView>

      {/* Lock badge sempre visibile */}
      <View pointerEvents="none" style={[styles.watermark, { top: insets.top + 46 }]}>
        <Ionicons
          name={isAdmin ? "shield-checkmark" : "lock-closed"}
          size={10}
          color={colors.onBrandPrimary}
        />
        <Text style={styles.watermarkText}>
          {isAdmin ? "ADMIN" : "SOLA LETTURA"}
        </Text>
      </View>
    </View>
  );
}

function PageImage({
  src,
  pageWidth,
  pageIndex,
  total,
  watermark,
}: {
  src: string;
  pageWidth: number;
  pageIndex: number;
  total: number;
  watermark: string;
}) {
  const [loaded, setLoaded] = useState(false);
  const [err, setErr] = useState(false);
  const minHeight = pageWidth * 1.414; // A4 ratio placeholder
  const watermarkText = `${watermark} · ${new Date().toLocaleDateString("it-IT")}`;
  const renderWatermarkOverlay = () => (
    <View pointerEvents="none" style={styles.watermarkOverlay}>
      {Array.from({ length: 6 }).map((_, row) => (
        <View key={row} style={styles.watermarkRow}>
          {Array.from({ length: 3 }).map((_, col) => (
            <Text key={col} style={styles.watermarkDynamic} numberOfLines={1}>
              {watermarkText}
            </Text>
          ))}
        </View>
      ))}
    </View>
  );
  // On web use <img> with CSS protections (user-select, pointer-events on wrapper)
  // On native use expo-image with full gesture guard
  if (Platform.OS === "web") {
    return (
      <View
        style={[
          styles.pageWrap,
          { width: pageWidth },
          !loaded && { minHeight },
        ]}
        // @ts-expect-error web-only attr via RN
        onContextMenu={(e: any) => e?.preventDefault?.()}
      >
        <img
          src={src}
          alt={`Pagina ${pageIndex} di ${total}`}
          draggable={false}
          onLoad={() => setLoaded(true)}
          onError={() => setErr(true)}
          style={{
            width: "100%",
            height: "auto",
            display: "block",
            userSelect: "none",
            WebkitUserSelect: "none",
            pointerEvents: "none",
          } as any}
        />
        {loaded && !err ? renderWatermarkOverlay() : null}
        {!loaded && !err ? (
          <View style={styles.pageOverlay} pointerEvents="none">
            <ActivityIndicator color={colors.brandPrimary} />
          </View>
        ) : null}
        {err ? (
          <View style={styles.pageOverlay}>
            <Ionicons name="warning" size={28} color={colors.error} />
            <Text style={styles.hint}>Pagina non caricata</Text>
          </View>
        ) : null}
        <Text style={styles.pageLabel}>
          Pagina {pageIndex} / {total}
        </Text>
      </View>
    );
  }
  return (
    <View style={[styles.pageWrap, { width: pageWidth, minHeight }]}>
      <Image
        source={{ uri: src }}
        style={{ width: pageWidth, minHeight }}
        contentFit="contain"
        onLoad={() => setLoaded(true)}
        onError={() => setErr(true)}
      />
      {loaded && !err ? renderWatermarkOverlay() : null}
      {!loaded && !err ? (
        <View style={styles.pageOverlay} pointerEvents="none">
          <ActivityIndicator color={colors.brandPrimary} />
        </View>
      ) : null}
      {err ? (
        <View style={styles.pageOverlay}>
          <Ionicons name="warning" size={28} color={colors.error} />
          <Text style={styles.hint}>Pagina non caricata</Text>
        </View>
      ) : null}
      <Text style={styles.pageLabel}>
        Pagina {pageIndex} / {total}
      </Text>
    </View>
  );
}

const styles = StyleSheet.create({
  root: { flex: 1, backgroundColor: colors.surface },
  center: { alignItems: "center", justifyContent: "center" },
  header: {
    flexDirection: "row",
    alignItems: "center",
    gap: spacing.sm,
    paddingHorizontal: spacing.lg,
    paddingVertical: spacing.md,
    borderBottomWidth: StyleSheet.hairlineWidth,
    borderBottomColor: colors.border,
  },
  iconChip: {
    width: 36,
    height: 36,
    borderRadius: radius.lg,
    backgroundColor: colors.surfaceSecondary,
    alignItems: "center",
    justifyContent: "center",
    borderWidth: StyleSheet.hairlineWidth,
    borderColor: colors.border,
  },
  headerLabel: {
    color: colors.brandPrimary,
    fontSize: 10,
    letterSpacing: 2,
    fontWeight: "800",
  },
  headerTitle: {
    color: colors.onSurface,
    fontSize: 16,
    fontWeight: "900",
    letterSpacing: 1,
  },
  viewerWrap: { flex: 1, backgroundColor: colors.surface },
  scrollContent: {
    padding: spacing.lg,
    alignItems: "center",
    paddingBottom: spacing.xxl,
  },
  pageWrap: {
    backgroundColor: "#fff",
    borderRadius: radius.sm,
    overflow: "hidden",
    position: "relative",
    borderWidth: StyleSheet.hairlineWidth,
    borderColor: colors.border,
  },
  pageOverlay: {
    position: "absolute",
    top: 0,
    left: 0,
    right: 0,
    bottom: 0,
    alignItems: "center",
    justifyContent: "center",
    gap: spacing.sm,
    backgroundColor: "rgba(16,18,16,0.4)",
  },
  pageLabel: {
    position: "absolute",
    bottom: 6,
    right: 10,
    color: "#fff",
    fontSize: 10,
    fontWeight: "900",
    letterSpacing: 1.5,
    backgroundColor: "rgba(0,0,0,0.5)",
    paddingHorizontal: 6,
    paddingVertical: 2,
    borderRadius: 4,
  },
  hint: {
    color: colors.onSurface,
    fontSize: 13,
    textAlign: "center",
  },
  errorTitle: {
    color: colors.onSurface,
    fontSize: 16,
    fontWeight: "900",
    letterSpacing: 1,
  },
  watermark: {
    position: "absolute",
    right: spacing.sm,
    flexDirection: "row",
    alignItems: "center",
    gap: 4,
    paddingHorizontal: 8,
    paddingVertical: 4,
    borderRadius: 999,
    backgroundColor: "rgba(106, 153, 78, 0.9)",
  },
  watermarkText: {
    color: colors.onBrandPrimary,
    fontSize: 9,
    fontWeight: "900",
    letterSpacing: 1.5,
  },
  downloadBtn: {
    backgroundColor: colors.brandPrimary,
    borderColor: colors.brandPrimary,
  },
  watermarkOverlay: {
    ...StyleSheet.absoluteFillObject,
    justifyContent: "space-around",
    alignItems: "stretch",
    paddingVertical: spacing.lg,
    paddingHorizontal: spacing.lg,
  },
  watermarkRow: {
    flexDirection: "row",
    justifyContent: "space-around",
    alignItems: "center",
    transform: [{ rotate: "-25deg" }],
  },
  watermarkDynamic: {
    color: "rgba(106, 153, 78, 0.28)",
    fontSize: 14,
    fontWeight: "900",
    letterSpacing: 2,
  },
});
