import React, { useMemo } from "react";
import {
  View,
  Text,
  StyleSheet,
  Pressable,
  ScrollView,
  ActivityIndicator,
  useWindowDimensions,
} from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import { useRouter } from "expo-router";
import { useQuery } from "@tanstack/react-query";
import { Ionicons } from "@react-native-vector-icons/ionicons";
import { Image } from "expo-image";

import { BACKEND_URL } from "@/src/api";
import { colors, spacing, radius } from "@/src/theme";

type PublicOperator = {
  id: string;
  battle_name: string;
  rank: string;
  department: string | string[];
  has_photo: boolean;
};

async function fetchPublic<T>(path: string): Promise<T> {
  const res = await fetch(`${BACKEND_URL}/api${path}`, {
    headers: { "Content-Type": "application/json" },
  });
  if (!res.ok) throw new Error(`HTTP ${res.status}`);
  return (await res.json()) as T;
}

function photoUrl(opId: string) {
  return `${BACKEND_URL}/api/public/operators/${opId}/photo`;
}

const DEPARTMENTS = [
  "630",
  "ROCS",
  "DIRETTIVO",
  "AMMINISTRAZIONE",
  "ISTRUTTORE",
  "FURIANO SEMPLICE",
];

export default function PublicRoster() {
  const insets = useSafeAreaInsets();
  const router = useRouter();
  const { width } = useWindowDimensions();

  const rosterQ = useQuery({
    queryKey: ["public-operators"],
    queryFn: async () =>
      await fetchPublic<{ operators: PublicOperator[] }>(`/public/operators`),
  });

  const [filter, setFilter] = React.useState<Set<string>>(new Set());

  const operators = useMemo(() => rosterQ.data?.operators || [], [rosterQ.data]);
  const filtered = useMemo(() => {
    if (filter.size === 0) return operators;
    return operators.filter((op) => {
      const depts = Array.isArray(op.department)
        ? op.department
        : op.department
        ? [op.department]
        : [];
      return depts.some((d) => filter.has((d || "").toUpperCase()));
    });
  }, [operators, filter]);

  const columns = width >= 1000 ? 4 : width >= 650 ? 3 : 2;
  const gap = spacing.sm;
  const horizontalPadding = spacing.lg * 2;
  const tileSize = Math.floor(
    (Math.min(width, 1100) - horizontalPadding - gap * (columns - 1)) / columns,
  );

  const toggleDept = (d: string) => {
    const upd = new Set(filter);
    if (upd.has(d)) upd.delete(d);
    else upd.add(d);
    setFilter(upd);
  };

  return (
    <View style={[styles.root, { paddingTop: insets.top }]} testID="public-roster">
      <View style={styles.header}>
        <Pressable
          onPress={() => router.back()}
          style={styles.iconChip}
          hitSlop={6}
        >
          <Ionicons name="chevron-back" size={22} color={colors.onSurface} />
        </Pressable>
        <View style={{ flex: 1 }}>
          <Text style={styles.headerLabel}>VETRINA PUBBLICA</Text>
          <Text style={styles.headerTitle}>GESTIONALE</Text>
        </View>
        <View style={styles.publicPill}>
          <Ionicons name="eye" size={11} color={colors.brandPrimary} />
          <Text style={styles.publicPillText}>SOLA LETTURA</Text>
        </View>
      </View>

      <View style={styles.deptBar}>
        {DEPARTMENTS.map((d) => {
          const active = filter.has(d);
          return (
            <Pressable
              key={d}
              onPress={() => toggleDept(d)}
              style={[styles.deptChip, active && styles.deptChipActive]}
            >
              <Text style={[styles.deptText, active && styles.deptTextActive]}>{d}</Text>
            </Pressable>
          );
        })}
        {filter.size > 0 ? (
          <Pressable onPress={() => setFilter(new Set())} style={styles.deptClear}>
            <Ionicons name="close" size={11} color={colors.onSurfaceSecondary} />
            <Text style={styles.deptClearText}>PULISCI</Text>
          </Pressable>
        ) : null}
      </View>

      <ScrollView contentContainerStyle={{ padding: spacing.lg, paddingBottom: spacing.xxl }}>
        {rosterQ.isLoading ? (
          <View style={[styles.center, { paddingVertical: spacing.xxl }]}>
            <ActivityIndicator color={colors.brandPrimary} size="large" />
          </View>
        ) : rosterQ.isError ? (
          <View style={styles.emptyBox}>
            <Ionicons name="warning" size={28} color={colors.error} />
            <Text style={styles.emptyText}>Impossibile caricare gli operatori</Text>
          </View>
        ) : filtered.length === 0 ? (
          <View style={styles.emptyBox}>
            <Ionicons name="people-outline" size={32} color={colors.onSurfaceSecondary} />
            <Text style={styles.emptyText}>Nessun operatore corrisponde ai filtri</Text>
          </View>
        ) : (
          <View style={[styles.grid, { gap }]}>
            {filtered.map((op) => (
              <View
                key={op.id}
                style={[styles.card, { width: tileSize, minHeight: tileSize * 1.35 }]}
              >
                {op.rank ? (
                  <View style={styles.rankBadge}>
                    <Text style={styles.rankText}>{op.rank.toUpperCase()}</Text>
                  </View>
                ) : null}
                <View style={styles.avatarWrap}>
                  {op.has_photo ? (
                    <Image
                      source={{ uri: photoUrl(op.id) }}
                      style={styles.avatar}
                      contentFit="cover"
                    />
                  ) : (
                    <View style={[styles.avatar, styles.avatarFallback]}>
                      <Text style={styles.avatarInitial}>
                        {(op.battle_name || "?").trim()[0]?.toUpperCase() || "?"}
                      </Text>
                    </View>
                  )}
                </View>
                <Text style={styles.battleName} numberOfLines={2}>
                  {op.battle_name || "—"}
                </Text>
                {Array.isArray(op.department) && op.department.length > 0 ? (
                  <View style={styles.deptWrap}>
                    {op.department.map((d) => (
                      <View key={d} style={styles.deptBadge}>
                        <Text style={styles.deptBadgeText}>{d}</Text>
                      </View>
                    ))}
                  </View>
                ) : typeof op.department === "string" && op.department ? (
                  <View style={styles.deptWrap}>
                    <View style={styles.deptBadge}>
                      <Text style={styles.deptBadgeText}>{op.department}</Text>
                    </View>
                  </View>
                ) : null}
              </View>
            ))}
          </View>
        )}

        <View style={styles.privacyNotice}>
          <Ionicons name="lock-closed" size={13} color={colors.onSurfaceSecondary} />
          <Text style={styles.privacyText}>
            I dati personali (nome reale, contatti, documenti) sono riservati e non accessibili
            dall&apos;area pubblica.
          </Text>
        </View>
      </ScrollView>
    </View>
  );
}

const styles = StyleSheet.create({
  root: { flex: 1, backgroundColor: colors.surface },
  center: { alignItems: "center", justifyContent: "center" },
  header: {
    flexDirection: "row",
    alignItems: "center",
    gap: spacing.sm,
    paddingHorizontal: spacing.lg,
    paddingVertical: spacing.md,
    borderBottomWidth: StyleSheet.hairlineWidth,
    borderBottomColor: colors.border,
  },
  iconChip: {
    width: 36,
    height: 36,
    borderRadius: radius.lg,
    backgroundColor: colors.surfaceSecondary,
    alignItems: "center",
    justifyContent: "center",
    borderWidth: StyleSheet.hairlineWidth,
    borderColor: colors.border,
  },
  headerLabel: {
    color: colors.brandPrimary,
    fontSize: 10,
    letterSpacing: 2,
    fontWeight: "800",
  },
  headerTitle: {
    color: colors.onSurface,
    fontSize: 22,
    fontWeight: "900",
    letterSpacing: 2,
  },
  publicPill: {
    flexDirection: "row",
    alignItems: "center",
    gap: 4,
    paddingHorizontal: spacing.sm,
    paddingVertical: 4,
    borderRadius: radius.pill,
    backgroundColor: colors.brandTertiary,
    borderWidth: StyleSheet.hairlineWidth,
    borderColor: colors.brandPrimary,
  },
  publicPillText: {
    color: colors.brandPrimary,
    fontSize: 9,
    fontWeight: "900",
    letterSpacing: 1,
  },

  deptBar: {
    flexDirection: "row",
    flexWrap: "wrap",
    gap: spacing.sm,
    alignItems: "center",
    paddingHorizontal: spacing.lg,
    paddingVertical: spacing.md,
    borderBottomWidth: StyleSheet.hairlineWidth,
    borderBottomColor: colors.border,
    backgroundColor: colors.surface,
  },
  deptChip: {
    paddingHorizontal: spacing.md,
    paddingVertical: 8,
    borderRadius: radius.pill,
    backgroundColor: colors.surfaceSecondary,
    borderWidth: StyleSheet.hairlineWidth,
    borderColor: colors.border,
  },
  deptChipActive: {
    backgroundColor: colors.brandPrimary,
    borderColor: colors.brandPrimary,
  },
  deptText: {
    color: colors.onSurfaceSecondary,
    fontSize: 10,
    fontWeight: "800",
    letterSpacing: 1,
  },
  deptTextActive: { color: colors.onBrandPrimary },
  deptClear: {
    flexDirection: "row",
    alignItems: "center",
    gap: 3,
    paddingHorizontal: spacing.sm,
    paddingVertical: 5,
    borderRadius: radius.pill,
    backgroundColor: "transparent",
  },
  deptClearText: {
    color: colors.onSurfaceSecondary,
    fontSize: 9,
    fontWeight: "900",
    letterSpacing: 1,
  },

  grid: {
    flexDirection: "row",
    flexWrap: "wrap",
    alignItems: "flex-start",
  },
  card: {
    backgroundColor: colors.surfaceSecondary,
    borderRadius: radius.lg,
    borderWidth: StyleSheet.hairlineWidth,
    borderColor: colors.border,
    padding: spacing.md,
    alignItems: "center",
    gap: spacing.sm,
  },
  rankBadge: {
    position: "absolute",
    top: 8,
    left: 8,
    paddingHorizontal: 6,
    paddingVertical: 2,
    borderRadius: 4,
    backgroundColor: colors.brandPrimary,
    zIndex: 2,
  },
  rankText: {
    color: colors.onBrandPrimary,
    fontSize: 8,
    fontWeight: "900",
    letterSpacing: 1,
  },
  avatarWrap: {
    marginTop: spacing.sm,
  },
  avatar: {
    width: 80,
    height: 80,
    borderRadius: 40,
    backgroundColor: colors.surfaceTertiary,
    borderWidth: 2,
    borderColor: colors.brandPrimary,
  },
  avatarFallback: {
    alignItems: "center",
    justifyContent: "center",
  },
  avatarInitial: {
    color: colors.brandPrimary,
    fontSize: 30,
    fontWeight: "900",
  },
  battleName: {
    color: colors.onSurface,
    fontSize: 13,
    fontWeight: "900",
    letterSpacing: 1,
    textAlign: "center",
  },
  deptWrap: {
    flexDirection: "row",
    flexWrap: "wrap",
    gap: 4,
    justifyContent: "center",
  },
  deptBadge: {
    paddingHorizontal: 6,
    paddingVertical: 2,
    borderRadius: radius.pill,
    backgroundColor: colors.brandTertiary,
  },
  deptBadgeText: {
    color: colors.brandPrimary,
    fontSize: 8,
    fontWeight: "900",
    letterSpacing: 0.5,
  },

  emptyBox: {
    alignItems: "center",
    paddingVertical: spacing.xxl,
    gap: spacing.sm,
  },
  emptyText: {
    color: colors.onSurfaceSecondary,
    fontSize: 13,
  },

  privacyNotice: {
    flexDirection: "row",
    alignItems: "center",
    gap: 8,
    padding: spacing.md,
    borderRadius: radius.lg,
    backgroundColor: colors.surfaceSecondary,
    borderWidth: StyleSheet.hairlineWidth,
    borderColor: colors.border,
    marginTop: spacing.lg,
  },
  privacyText: {
    color: colors.onSurfaceSecondary,
    fontSize: 11,
    flex: 1,
    lineHeight: 16,
    fontStyle: "italic",
  },
});
