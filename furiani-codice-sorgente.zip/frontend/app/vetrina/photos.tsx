import React, { useMemo, useState } from "react";
import {
  View,
  Text,
  StyleSheet,
  Pressable,
  ScrollView,
  ActivityIndicator,
  RefreshControl,
  Modal,
  useWindowDimensions,
} from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import { useRouter } from "expo-router";
import { useQuery } from "@tanstack/react-query";
import { Ionicons } from "@react-native-vector-icons/ionicons";
import { Image } from "expo-image";

import { BACKEND_URL } from "@/src/api";
import { colors, spacing, radius } from "@/src/theme";
import ZoomableImage from "@/src/components/zoomable-image";

type Photo = {
  id: string;
  year: number;
  album: string;
  caption: string;
  filename: string;
  content_type: string;
  size: number;
  source: string;
  source_url?: string | null;
  uploaded_at: string | null;
  post_url?: string | null;
  order: number;
};

type AlbumSummary = {
  year: number;
  album: string;
  count: number;
  cover_id: string | null;
  source: string;
  latest: string | null;
};
type YearSummary = { year: number; count: number; cover_id: string | null };
type AlbumsResponse = { albums: AlbumSummary[]; years: YearSummary[] };
type PhotosResponse = { photos: Photo[] };

async function fetchPublic<T>(path: string): Promise<T> {
  const res = await fetch(`${BACKEND_URL}/api${path}`, {
    headers: { "Content-Type": "application/json" },
  });
  if (!res.ok) throw new Error(`HTTP ${res.status}`);
  return (await res.json()) as T;
}

function thumbUrl(photoId: string) {
  return `${BACKEND_URL}/api/public/photos/file/${photoId}`;
}

export default function PublicPhotos() {
  const insets = useSafeAreaInsets();
  const router = useRouter();
  const { width } = useWindowDimensions();

  const [view, setView] = useState<"albums" | "years">("albums");
  const [selected, setSelected] = useState<
    | { kind: "album"; year: number; album: string }
    | { kind: "year"; year: number }
    | null
  >(null);
  const [lightbox, setLightbox] = useState<{ photos: Photo[]; index: number } | null>(null);
  const [zoomedLightbox, setZoomedLightbox] = useState(false);

  const albumsQ = useQuery({
    queryKey: ["public-albums"],
    queryFn: async () => await fetchPublic<AlbumsResponse>("/public/photos/albums"),
    refetchOnWindowFocus: true,
  });

  const selectedQ = useQuery({
    queryKey: [
      "public-photos-list",
      selected?.kind,
      selected?.year,
      selected?.kind === "album" ? selected.album : null,
    ],
    queryFn: async () => {
      if (!selected) return { photos: [] } as PhotosResponse;
      const parts = [`year=${selected.year}`];
      if (selected.kind === "album") parts.push(`album=${encodeURIComponent(selected.album)}`);
      return await fetchPublic<PhotosResponse>(`/public/photos?${parts.join("&")}`);
    },
    enabled: !!selected,
  });

  const columns = width >= 900 ? 5 : width >= 600 ? 4 : 3;
  const gridGap = spacing.sm;
  const horizontalPadding = spacing.lg * 2;
  const tileSize = Math.floor(
    (Math.min(width, 1100) - horizontalPadding - gridGap * (columns - 1)) / columns,
  );

  const albumsByYear = useMemo(() => {
    const map = new Map<number, AlbumSummary[]>();
    for (const a of albumsQ.data?.albums || []) {
      const arr = map.get(a.year) || [];
      arr.push(a);
      map.set(a.year, arr);
    }
    return Array.from(map.entries()).sort((a, b) => b[0] - a[0]);
  }, [albumsQ.data]);

  const totals = useMemo(() => {
    const yearsArr = albumsQ.data?.years || [];
    const totalPhotos = yearsArr.reduce((s, y) => s + y.count, 0);
    const totalAlbums = albumsQ.data?.albums.length || 0;
    return { totalPhotos, totalAlbums, totalYears: yearsArr.length };
  }, [albumsQ.data]);

  const detailTitle = selected
    ? selected.kind === "year"
      ? `${selected.year}`
      : selected.album
    : "";
  const detailSubtitle = selected
    ? selected.kind === "year"
      ? "Tutte le foto dell'anno"
      : `${selected.year}`
    : "";

  const renderYearGrid = () => {
    const years = albumsQ.data?.years || [];
    if (years.length === 0) {
      return (
        <View style={styles.emptyBox}>
          <Ionicons name="images-outline" size={40} color={colors.onSurfaceSecondary} />
          <Text style={styles.emptyText}>Nessuna foto disponibile</Text>
        </View>
      );
    }
    return (
      <View style={[styles.grid, { gap: gridGap }]}>
        {years.map((y) => (
          <Pressable
            key={y.year}
            onPress={() => setSelected({ kind: "year", year: y.year })}
            style={({ pressed }) => [
              styles.yearCard,
              { width: tileSize * 1.5 + gridGap / 2, height: tileSize * 1.5 },
              pressed && { opacity: 0.85 },
            ]}
          >
            {y.cover_id ? (
              <Image
                source={{ uri: thumbUrl(y.cover_id) }}
                style={StyleSheet.absoluteFill}
                contentFit="cover"
              />
            ) : null}
            <View style={styles.yearOverlay}>
              <Text style={styles.yearNumber}>{y.year}</Text>
              <Text style={styles.yearCount}>{y.count} foto</Text>
            </View>
          </Pressable>
        ))}
      </View>
    );
  };

  const renderAlbumsView = () => {
    if (albumsByYear.length === 0) {
      return (
        <View style={styles.emptyBox}>
          <Ionicons name="images-outline" size={40} color={colors.onSurfaceSecondary} />
          <Text style={styles.emptyText}>Nessuna foto disponibile</Text>
        </View>
      );
    }
    return (
      <View style={{ gap: spacing.lg }}>
        {albumsByYear.map(([year, albums]) => (
          <View key={year}>
            <View style={styles.yearHeaderRow}>
              <View style={styles.yearBadge}>
                <Text style={styles.yearBadgeText}>{year}</Text>
              </View>
              <Text style={styles.yearHeaderMeta}>
                {albums.reduce((s, a) => s + a.count, 0)} foto · {albums.length} album
              </Text>
            </View>
            <View style={[styles.grid, { gap: gridGap }]}>
              {albums.map((a) => (
                <Pressable
                  key={`${a.year}-${a.album}`}
                  onPress={() => setSelected({ kind: "album", year: a.year, album: a.album })}
                  style={({ pressed }) => [
                    styles.albumCard,
                    { width: tileSize, height: tileSize * 1.2 },
                    pressed && { opacity: 0.85 },
                  ]}
                >
                  {a.cover_id ? (
                    <Image
                      source={{ uri: thumbUrl(a.cover_id) }}
                      style={styles.albumCover}
                      contentFit="cover"
                    />
                  ) : (
                    <View style={[styles.albumCover, styles.albumCoverFallback]}>
                      <Ionicons name="images" size={28} color={colors.onSurfaceSecondary} />
                    </View>
                  )}
                  <View style={styles.albumMeta}>
                    <Text style={styles.albumTitle} numberOfLines={2}>
                      {a.album}
                    </Text>
                    <View style={styles.albumBottomRow}>
                      <Text style={styles.albumCount}>{a.count} foto</Text>
                      {a.source === "blog" ? (
                        <View style={styles.sourcePill}>
                          <Ionicons name="archive" size={9} color={colors.brandPrimary} />
                          <Text style={styles.sourcePillText}>STORICO</Text>
                        </View>
                      ) : null}
                    </View>
                  </View>
                </Pressable>
              ))}
            </View>
          </View>
        ))}
      </View>
    );
  };

  const renderPhotoGrid = (photos: Photo[]) => (
    <View style={[styles.grid, { gap: gridGap }]}>
      {photos.map((p, idx) => (
        <Pressable
          key={p.id}
          onPress={() => setLightbox({ photos, index: idx })}
          style={({ pressed }) => [
            styles.photoThumb,
            { width: tileSize, height: tileSize },
            pressed && { opacity: 0.75 },
          ]}
        >
          <Image
            source={{ uri: thumbUrl(p.id) }}
            style={StyleSheet.absoluteFill}
            contentFit="cover"
            transition={200}
          />
        </Pressable>
      ))}
    </View>
  );

  return (
    <View style={[styles.root, { paddingTop: insets.top }]} testID="public-photos">
      <View style={styles.header}>
        <Pressable
          onPress={() => (selected ? setSelected(null) : router.back())}
          style={styles.iconChip}
          hitSlop={6}
        >
          <Ionicons name="chevron-back" size={22} color={colors.onSurface} />
        </Pressable>
        <View style={{ flex: 1 }}>
          <Text style={styles.headerLabel}>
            {selected ? detailSubtitle.toUpperCase() : "VETRINA PUBBLICA"}
          </Text>
          <Text style={styles.headerTitle} numberOfLines={1}>
            {selected ? detailTitle : "ARCHIVIO FOTO"}
          </Text>
        </View>
        <View style={styles.publicPill}>
          <Ionicons name="eye" size={11} color={colors.brandPrimary} />
          <Text style={styles.publicPillText}>PUBBLICO</Text>
        </View>
      </View>

      {!selected ? (
        <>
          <View style={styles.topBar}>
            <View style={styles.selector}>
              <Pressable
                onPress={() => setView("albums")}
                style={[styles.selectorBtn, view === "albums" && styles.selectorBtnActive]}
              >
                <Text style={[styles.selectorText, view === "albums" && styles.selectorTextActive]}>
                  PER EVENTO
                </Text>
              </Pressable>
              <Pressable
                onPress={() => setView("years")}
                style={[styles.selectorBtn, view === "years" && styles.selectorBtnActive]}
              >
                <Text style={[styles.selectorText, view === "years" && styles.selectorTextActive]}>
                  PER ANNO
                </Text>
              </Pressable>
            </View>
            <View style={styles.statRow}>
              <View style={styles.stat}>
                <Text style={styles.statValue}>{totals.totalPhotos}</Text>
                <Text style={styles.statLabel}>foto</Text>
              </View>
              <View style={styles.stat}>
                <Text style={styles.statValue}>{totals.totalAlbums}</Text>
                <Text style={styles.statLabel}>album</Text>
              </View>
              <View style={styles.stat}>
                <Text style={styles.statValue}>{totals.totalYears}</Text>
                <Text style={styles.statLabel}>anni</Text>
              </View>
            </View>
          </View>

          <ScrollView
            contentContainerStyle={styles.scrollContent}
            refreshControl={
              <RefreshControl
                refreshing={albumsQ.isFetching && !albumsQ.isLoading}
                onRefresh={() => albumsQ.refetch()}
                tintColor={colors.brandPrimary}
              />
            }
          >
            {albumsQ.isLoading ? (
              <View style={[styles.center, { paddingVertical: spacing.xxl }]}>
                <ActivityIndicator color={colors.brandPrimary} size="large" />
              </View>
            ) : view === "years" ? (
              renderYearGrid()
            ) : (
              renderAlbumsView()
            )}
          </ScrollView>
        </>
      ) : (
        <ScrollView
          contentContainerStyle={styles.scrollContent}
          refreshControl={
            <RefreshControl
              refreshing={selectedQ.isFetching && !selectedQ.isLoading}
              onRefresh={() => selectedQ.refetch()}
              tintColor={colors.brandPrimary}
            />
          }
        >
          {selectedQ.isLoading ? (
            <View style={[styles.center, { paddingVertical: spacing.xxl }]}>
              <ActivityIndicator color={colors.brandPrimary} size="large" />
            </View>
          ) : (
            renderPhotoGrid(selectedQ.data?.photos || [])
          )}
        </ScrollView>
      )}

      <Modal
        visible={!!lightbox}
        transparent
        animationType="fade"
        onRequestClose={() => setLightbox(null)}
      >
        {lightbox ? (
          <View style={styles.lightboxRoot}>
            <View style={[styles.lightboxTop, { paddingTop: insets.top + spacing.sm }]}>
              <Text style={styles.lightboxCount}>
                {lightbox.index + 1} / {lightbox.photos.length}
              </Text>
              <View style={{ flex: 1 }} />
              <Pressable
                onPress={() => setLightbox(null)}
                style={styles.lightboxBtn}
                hitSlop={6}
              >
                <Ionicons name="close" size={24} color={colors.onSurface} />
              </Pressable>
            </View>

            <View style={styles.lightboxImageWrap}>
              <ZoomableImage
                uri={thumbUrl(lightbox.photos[lightbox.index].id)}
                style={styles.lightboxImage}
                contentFit="contain"
                onZoomedChange={setZoomedLightbox}
              />
            </View>

            <View style={[styles.lightboxBottom, { paddingBottom: insets.bottom + spacing.sm }]}>
              <Pressable
                onPress={() =>
                  setLightbox((lb) => (lb ? { ...lb, index: Math.max(0, lb.index - 1) } : lb))
                }
                disabled={lightbox.index === 0 || zoomedLightbox}
                style={[
                  styles.navBtn,
                  (lightbox.index === 0 || zoomedLightbox) && { opacity: 0.3 },
                ]}
                hitSlop={6}
              >
                <Ionicons name="chevron-back" size={28} color={colors.onSurface} />
              </Pressable>
              <View style={{ flex: 1, alignItems: "center" }}>
                <Text style={styles.lightboxAlbum} numberOfLines={1}>
                  {lightbox.photos[lightbox.index].album}
                </Text>
                <Text style={styles.lightboxYear}>{lightbox.photos[lightbox.index].year}</Text>
                {lightbox.photos[lightbox.index].caption ? (
                  <Text style={styles.lightboxCaption} numberOfLines={3}>
                    {lightbox.photos[lightbox.index].caption}
                  </Text>
                ) : null}
                <Text style={styles.zoomHint}>Pizzica per zoom · Doppio tap</Text>
              </View>
              <Pressable
                onPress={() =>
                  setLightbox((lb) =>
                    lb
                      ? { ...lb, index: Math.min(lb.photos.length - 1, lb.index + 1) }
                      : lb,
                  )
                }
                disabled={
                  lightbox.index === lightbox.photos.length - 1 || zoomedLightbox
                }
                style={[
                  styles.navBtn,
                  (lightbox.index === lightbox.photos.length - 1 || zoomedLightbox) && {
                    opacity: 0.3,
                  },
                ]}
                hitSlop={6}
              >
                <Ionicons name="chevron-forward" size={28} color={colors.onSurface} />
              </Pressable>
            </View>
          </View>
        ) : null}
      </Modal>
    </View>
  );
}

const styles = StyleSheet.create({
  root: { flex: 1, backgroundColor: colors.surface },
  center: { alignItems: "center", justifyContent: "center" },
  header: {
    flexDirection: "row",
    alignItems: "center",
    gap: spacing.sm,
    paddingHorizontal: spacing.lg,
    paddingVertical: spacing.md,
    borderBottomWidth: StyleSheet.hairlineWidth,
    borderBottomColor: colors.border,
  },
  iconChip: {
    width: 36,
    height: 36,
    borderRadius: radius.lg,
    backgroundColor: colors.surfaceSecondary,
    alignItems: "center",
    justifyContent: "center",
    borderWidth: StyleSheet.hairlineWidth,
    borderColor: colors.border,
  },
  headerLabel: {
    color: colors.brandPrimary,
    fontSize: 10,
    letterSpacing: 2,
    fontWeight: "800",
  },
  headerTitle: {
    color: colors.onSurface,
    fontSize: 20,
    fontWeight: "900",
    letterSpacing: 1.5,
  },
  publicPill: {
    flexDirection: "row",
    alignItems: "center",
    gap: 4,
    paddingHorizontal: spacing.sm,
    paddingVertical: 4,
    borderRadius: radius.pill,
    backgroundColor: colors.brandTertiary,
    borderWidth: StyleSheet.hairlineWidth,
    borderColor: colors.brandPrimary,
  },
  publicPillText: {
    color: colors.brandPrimary,
    fontSize: 9,
    fontWeight: "900",
    letterSpacing: 1,
  },

  topBar: {
    paddingHorizontal: spacing.lg,
    paddingVertical: spacing.md,
    gap: spacing.sm,
    borderBottomWidth: StyleSheet.hairlineWidth,
    borderBottomColor: colors.border,
  },
  selector: {
    flexDirection: "row",
    backgroundColor: colors.surfaceTertiary,
    borderRadius: radius.lg,
    padding: 2,
    alignSelf: "flex-start",
  },
  selectorBtn: {
    paddingHorizontal: spacing.md,
    paddingVertical: 6,
    borderRadius: radius.md,
  },
  selectorBtnActive: { backgroundColor: colors.brandPrimary },
  selectorText: {
    color: colors.onSurfaceSecondary,
    fontSize: 10,
    fontWeight: "800",
    letterSpacing: 1,
  },
  selectorTextActive: { color: colors.onBrandPrimary },

  statRow: { flexDirection: "row", gap: spacing.md, marginTop: 4 },
  stat: { flexDirection: "row", alignItems: "baseline", gap: 4 },
  statValue: {
    color: colors.brandPrimary,
    fontSize: 15,
    fontWeight: "900",
  },
  statLabel: {
    color: colors.onSurfaceSecondary,
    fontSize: 11,
    fontWeight: "700",
  },

  scrollContent: { padding: spacing.lg, paddingBottom: spacing.xxl },
  grid: { flexDirection: "row", flexWrap: "wrap", alignItems: "flex-start" },

  yearCard: {
    borderRadius: radius.lg,
    overflow: "hidden",
    backgroundColor: colors.surfaceSecondary,
    borderWidth: StyleSheet.hairlineWidth,
    borderColor: colors.border,
  },
  yearOverlay: {
    position: "absolute",
    bottom: 0,
    left: 0,
    right: 0,
    padding: spacing.md,
    backgroundColor: "rgba(0,0,0,0.55)",
  },
  yearNumber: {
    color: colors.onSurface,
    fontSize: 36,
    fontWeight: "900",
    letterSpacing: 2,
  },
  yearCount: {
    color: colors.brandPrimary,
    fontSize: 11,
    fontWeight: "800",
    marginTop: 2,
  },

  yearHeaderRow: {
    flexDirection: "row",
    alignItems: "center",
    gap: spacing.sm,
    marginBottom: spacing.sm,
  },
  yearBadge: {
    paddingHorizontal: spacing.md,
    paddingVertical: 4,
    borderRadius: radius.md,
    backgroundColor: colors.brandPrimary,
  },
  yearBadgeText: {
    color: colors.onBrandPrimary,
    fontSize: 14,
    fontWeight: "900",
    letterSpacing: 2,
  },
  yearHeaderMeta: {
    color: colors.onSurfaceSecondary,
    fontSize: 11,
    fontWeight: "700",
  },

  albumCard: {
    borderRadius: radius.lg,
    overflow: "hidden",
    backgroundColor: colors.surfaceSecondary,
    borderWidth: StyleSheet.hairlineWidth,
    borderColor: colors.border,
  },
  albumCover: { flex: 1, width: "100%", backgroundColor: colors.surfaceTertiary },
  albumCoverFallback: { alignItems: "center", justifyContent: "center" },
  albumMeta: { padding: spacing.sm, gap: 4 },
  albumTitle: {
    color: colors.onSurface,
    fontSize: 11,
    fontWeight: "800",
    lineHeight: 14,
  },
  albumBottomRow: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
    gap: 4,
  },
  albumCount: {
    color: colors.brandPrimary,
    fontSize: 10,
    fontWeight: "900",
  },
  sourcePill: {
    flexDirection: "row",
    alignItems: "center",
    gap: 2,
    paddingHorizontal: 5,
    paddingVertical: 1,
    borderRadius: radius.pill,
    backgroundColor: colors.brandTertiary,
  },
  sourcePillText: {
    color: colors.brandPrimary,
    fontSize: 8,
    fontWeight: "900",
    letterSpacing: 1,
  },

  photoThumb: {
    borderRadius: radius.md,
    overflow: "hidden",
    backgroundColor: colors.surfaceSecondary,
  },

  emptyBox: {
    alignItems: "center",
    paddingVertical: spacing.xxl,
    gap: spacing.sm,
  },
  emptyText: {
    color: colors.onSurfaceSecondary,
    fontSize: 13,
  },

  lightboxRoot: { flex: 1, backgroundColor: "rgba(0,0,0,0.95)" },
  lightboxTop: {
    flexDirection: "row",
    alignItems: "center",
    paddingHorizontal: spacing.lg,
    gap: spacing.sm,
  },
  lightboxCount: {
    color: colors.onSurface,
    fontSize: 13,
    fontWeight: "800",
    letterSpacing: 1,
  },
  lightboxBtn: {
    width: 40,
    height: 40,
    borderRadius: 20,
    alignItems: "center",
    justifyContent: "center",
    backgroundColor: "rgba(255,255,255,0.08)",
  },
  lightboxImageWrap: { flex: 1, padding: spacing.sm },
  lightboxImage: { width: "100%", height: "100%" },
  lightboxBottom: {
    flexDirection: "row",
    alignItems: "center",
    paddingHorizontal: spacing.lg,
    paddingTop: spacing.sm,
    gap: spacing.sm,
  },
  navBtn: {
    width: 44,
    height: 44,
    borderRadius: 22,
    alignItems: "center",
    justifyContent: "center",
    backgroundColor: "rgba(255,255,255,0.08)",
  },
  lightboxAlbum: {
    color: colors.onSurface,
    fontSize: 13,
    fontWeight: "800",
    textAlign: "center",
    paddingHorizontal: spacing.sm,
  },
  lightboxYear: {
    color: colors.brandPrimary,
    fontSize: 11,
    fontWeight: "700",
    letterSpacing: 1,
    marginTop: 2,
  },
  lightboxCaption: {
    color: colors.onSurface,
    fontSize: 12,
    marginTop: 6,
    textAlign: "center",
    paddingHorizontal: spacing.sm,
    fontStyle: "italic",
    lineHeight: 16,
  },
  zoomHint: {
    color: colors.onSurfaceSecondary,
    fontSize: 9,
    marginTop: 6,
    fontWeight: "600",
    letterSpacing: 1,
    opacity: 0.6,
  },
});
