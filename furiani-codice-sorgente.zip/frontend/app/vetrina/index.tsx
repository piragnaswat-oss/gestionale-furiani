import React from "react";
import { View, Text, StyleSheet, Pressable, ScrollView, Platform } from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import { useRouter } from "expo-router";
import { Ionicons } from "@react-native-vector-icons/ionicons";
import { Image } from "expo-image";

import { colors, spacing, radius } from "@/src/theme";

export default function VetrinaHome() {
  const insets = useSafeAreaInsets();
  const router = useRouter();

  const tiles = [
    {
      key: "roster",
      title: "GESTIONALE",
      subtitle: "Operatori · Grado · Nome di Battaglia",
      icon: "people" as const,
      route: "/vetrina/roster",
    },
    {
      key: "photos",
      title: "ARCHIVIO FOTO",
      subtitle: "Storico 2015+ · Album recenti",
      icon: "images" as const,
      route: "/vetrina/photos",
    },
  ];

  return (
    <View style={[styles.root, { paddingTop: insets.top }]} testID="vetrina-home">
      <View style={styles.header}>
        <Image
          source={require("../../assets/images/furiani-logo.jpeg")}
          style={styles.logo}
          contentFit="contain"
        />
        <View style={{ flex: 1 }}>
          <Text style={styles.headerLabel}>1° BATTAGLIONE FURIANI · VETRINA</Text>
          <Text style={styles.headerTitle}>PUBBLICO</Text>
        </View>
      </View>

      <ScrollView contentContainerStyle={{ padding: spacing.lg, paddingBottom: spacing.xxl, gap: spacing.lg }}>
        <View style={styles.welcome}>
          <Text style={styles.welcomeHello}>Benvenuto</Text>
          <Text style={styles.welcomeSub}>
            Questa è l&apos;area pubblica del Battaglione Furiani. Puoi consultare liberamente il
            roster e l&apos;archivio fotografico.
          </Text>
        </View>

        {tiles.map((t, idx) => (
          <Pressable
            key={t.key}
            testID={`vetrina-tile-${t.key}`}
            onPress={() => router.push(t.route as any)}
            style={({ pressed }) => [
              styles.tile,
              pressed && { opacity: 0.9, transform: [{ scale: 0.985 }] },
            ]}
          >
            <View style={styles.tileIconWrap}>
              <Ionicons name={t.icon} size={34} color={colors.brandPrimary} />
            </View>
            <View style={{ flex: 1, minWidth: 0 }}>
              <Text style={styles.tileTitle}>{t.title}</Text>
              <Text style={styles.tileSubtitle} numberOfLines={2}>
                {t.subtitle}
              </Text>
            </View>
            <Ionicons name="chevron-forward" size={22} color={colors.onBrandPrimary} />
            <View style={styles.tileCorner}>
              <Text style={styles.tileCornerText}>0{idx + 1}</Text>
            </View>
          </Pressable>
        ))}

        <View style={styles.staffBox}>
          <Ionicons name="shield-checkmark" size={16} color={colors.brandPrimary} />
          <Text style={styles.staffText}>
            Sei parte della squadra?{" "}
            <Text
              style={styles.staffLink}
              onPress={() => {
                if (Platform.OS === "web" && typeof window !== "undefined") {
                  window.location.href = "/";
                } else {
                  router.replace("/");
                }
              }}
            >
              Area riservata →
            </Text>
          </Text>
        </View>

        <View style={styles.footer}>
          <Text style={styles.footerText}>1° BATTAGLIONE FURIANI · ASD</Text>
          <Text style={styles.footerSubtext}>Softair · Addestramento · Tornei</Text>
        </View>
      </ScrollView>
    </View>
  );
}

const styles = StyleSheet.create({
  root: { flex: 1, backgroundColor: colors.surface },
  header: {
    flexDirection: "row",
    alignItems: "center",
    gap: spacing.sm,
    paddingHorizontal: spacing.lg,
    paddingVertical: spacing.md,
    borderBottomWidth: StyleSheet.hairlineWidth,
    borderBottomColor: colors.border,
  },
  logo: { width: 44, height: 44, borderRadius: 22 },
  headerLabel: {
    color: colors.brandPrimary,
    fontSize: 10,
    letterSpacing: 2,
    fontWeight: "800",
  },
  headerTitle: {
    color: colors.onSurface,
    fontSize: 22,
    fontWeight: "900",
    letterSpacing: 2,
  },
  welcome: { paddingVertical: spacing.sm },
  welcomeHello: {
    color: colors.onSurface,
    fontSize: 22,
    fontWeight: "900",
  },
  welcomeSub: {
    color: colors.onSurfaceSecondary,
    fontSize: 13,
    marginTop: 6,
    lineHeight: 18,
  },
  tile: {
    flexDirection: "row",
    alignItems: "center",
    gap: spacing.md,
    padding: spacing.lg,
    borderRadius: radius.lg,
    backgroundColor: colors.brand,
    borderWidth: 1,
    borderColor: colors.brandPrimary,
    overflow: "hidden",
    position: "relative",
    minHeight: 92,
  },
  tileIconWrap: {
    width: 56,
    height: 56,
    borderRadius: radius.lg,
    backgroundColor: colors.surface,
    alignItems: "center",
    justifyContent: "center",
    borderWidth: StyleSheet.hairlineWidth,
    borderColor: colors.brandPrimary,
  },
  tileTitle: {
    color: colors.onBrand,
    fontSize: 18,
    fontWeight: "900",
    letterSpacing: 2,
  },
  tileSubtitle: {
    color: colors.onBrand,
    opacity: 0.85,
    fontSize: 12,
    marginTop: 4,
    fontWeight: "600",
  },
  tileCorner: { position: "absolute", top: 8, right: 42, opacity: 0.15 },
  tileCornerText: {
    color: colors.onBrand,
    fontSize: 42,
    fontWeight: "900",
    letterSpacing: 2,
  },
  staffBox: {
    flexDirection: "row",
    alignItems: "center",
    gap: 8,
    padding: spacing.md,
    borderRadius: radius.lg,
    backgroundColor: colors.surfaceSecondary,
    borderWidth: StyleSheet.hairlineWidth,
    borderColor: colors.border,
  },
  staffText: {
    color: colors.onSurfaceSecondary,
    fontSize: 12,
    flex: 1,
  },
  staffLink: {
    color: colors.brandPrimary,
    fontWeight: "800",
  },
  footer: {
    alignItems: "center",
    paddingVertical: spacing.lg,
    marginTop: spacing.md,
  },
  footerText: {
    color: colors.brandPrimary,
    fontSize: 11,
    letterSpacing: 3,
    fontWeight: "900",
  },
  footerSubtext: {
    color: colors.onSurfaceSecondary,
    fontSize: 10,
    letterSpacing: 2,
    marginTop: 4,
  },
});
