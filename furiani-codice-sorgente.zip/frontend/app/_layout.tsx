import { QueryClientProvider } from "@tanstack/react-query";
import { Stack, useRouter, useSegments } from "expo-router";
import { LogBox, View, ActivityIndicator, StyleSheet, Platform } from "react-native";
import { SafeAreaProvider } from "react-native-safe-area-context";
import { GestureHandlerRootView } from "react-native-gesture-handler";
import { StatusBar } from "expo-status-bar";
import { useEffect, useState } from "react";

import { ErrorBoundary } from "@/src/components/error-boundary";
import { queryClient } from "@/src/query-client";
import { AuthProvider, useAuth } from "@/src/auth-context";
import { isGatePassed } from "@/src/access-gate";
import { colors } from "@/src/theme";

// Lazy-load KeyboardProvider so any native-module init failure in production
// (JSC/minified) cannot take down the entire app at module eval time.
let KeyboardProviderComp: React.ComponentType<{ children: React.ReactNode }> | null = null;
if (Platform.OS !== "web") {
  try {
    // eslint-disable-next-line @typescript-eslint/no-require-imports
    KeyboardProviderComp = require("react-native-keyboard-controller").KeyboardProvider;
  } catch {
    KeyboardProviderComp = null;
  }
}
const KeyboardMaybe = ({ children }: { children: React.ReactNode }) =>
  KeyboardProviderComp ? <KeyboardProviderComp>{children}</KeyboardProviderComp> : <>{children}</>;

LogBox.ignoreAllLogs(true);

function Gate({ children }: { children: React.ReactNode }) {
  const { status } = useAuth();
  const router = useRouter();
  const segments = useSegments();
  const [gate, setGate] = useState<"loading" | "locked" | "unlocked">("loading");

  useEffect(() => {
    isGatePassed().then((ok) => setGate(ok ? "unlocked" : "locked"));
  }, []);

  useEffect(() => {
    if (gate === "loading") return;
    const seg0 = segments[0] as string | undefined;

    // Public read-only area: bypass gate + auth entirely
    if (seg0 === "vetrina") return;

    if (gate === "locked") {
      if (seg0 !== "access-code") router.replace("/access-code");
      return;
    }
    // gate unlocked
    if (status === "loading") return;
    if (seg0 === "access-code") {
      router.replace(status === "authenticated" ? "/home" : "/");
      return;
    }
    if (status === "authenticated") {
      if (!seg0 || seg0 === "index") router.replace("/home");
    } else if (status === "unauthenticated") {
      if (seg0 && seg0 !== "index") router.replace("/");
    }
  }, [gate, status, segments, router]);

  // Re-check gate whenever landing on access-code (in case it was just set)
  useEffect(() => {
    if (segments[0] === "access-code") {
      isGatePassed().then((ok) => {
        if (ok) setGate("unlocked");
      });
    }
  }, [segments]);

  // Public /vetrina/* bypasses gate+auth: always render immediately
  if (segments[0] === "vetrina") {
    return <>{children}</>;
  }
  if (gate === "loading" || status === "loading") {
    return (
      <View style={styles.loading} testID="boot-loading">
        <ActivityIndicator color={colors.brandPrimary} size="large" />
      </View>
    );
  }
  return <>{children}</>;
}

export default function RootLayout() {
  return (
    <ErrorBoundary>
      <GestureHandlerRootView style={{ flex: 1 }}>
        <SafeAreaProvider>
          <QueryClientProvider client={queryClient}>
            <KeyboardMaybe>
              <AuthProvider>
                <StatusBar style="light" />
                <Gate>
                  <Stack
                    screenOptions={{
                      headerShown: false,
                      contentStyle: { backgroundColor: colors.surface },
                      animation: "fade",
                    }}
                  />
                </Gate>
              </AuthProvider>
            </KeyboardMaybe>
          </QueryClientProvider>
        </SafeAreaProvider>
      </GestureHandlerRootView>
    </ErrorBoundary>
  );
}

const styles = StyleSheet.create({
  loading: {
    flex: 1,
    alignItems: "center",
    justifyContent: "center",
    backgroundColor: colors.surface,
  },
});
