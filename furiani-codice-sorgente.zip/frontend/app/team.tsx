import React, { useState } from "react";
import {
  View,
  Text,
  StyleSheet,
  Pressable,
  FlatList,
  TextInput,
  ActivityIndicator,
  Alert,
  Platform,
  KeyboardAvoidingView,
  ScrollView,
} from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import { useRouter } from "expo-router";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Ionicons } from "@react-native-vector-icons/ionicons";
import * as Haptics from "expo-haptics";

import { apiJson } from "@/src/api";
import { colors, spacing, radius } from "@/src/theme";
import { useAuth } from "@/src/auth-context";

type Member = {
  email: string;
  role: "admin" | "member";
  added_by?: string;
  created_at?: string;
};

export default function TeamScreen() {
  const insets = useSafeAreaInsets();
  const router = useRouter();
  const qc = useQueryClient();
  const { user } = useAuth();
  const [newEmail, setNewEmail] = useState("");
  const [newRole, setNewRole] = useState<"admin" | "member">("member");
  const [code, setCode] = useState("");
  const [codeVisible, setCodeVisible] = useState(false);
  const [err, setErr] = useState<string | null>(null);

  const membersQ = useQuery<{ members: Member[] }>({
    queryKey: ["team", "members"],
    queryFn: () => apiJson<{ members: Member[] }>("/team/members"),
    enabled: user?.role === "admin",
  });

  const codeQ = useQuery<{ code: string }>({
    queryKey: ["team", "access-code"],
    queryFn: () => apiJson<{ code: string }>("/team/access-code"),
    enabled: user?.role === "admin",
  });

  React.useEffect(() => {
    if (codeQ.data?.code && !code) setCode(codeQ.data.code);
  }, [codeQ.data]);

  const addMut = useMutation({
    mutationFn: (payload: { email: string; role: string }) =>
      apiJson("/team/members", { method: "POST", body: JSON.stringify(payload) }),
    onSuccess: () => {
      setNewEmail("");
      setNewRole("member");
      setErr(null);
      Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
      qc.invalidateQueries({ queryKey: ["team", "members"] });
    },
    onError: (e: any) => setErr(e?.message || "Errore"),
  });

  const roleMut = useMutation({
    mutationFn: ({ email, role }: { email: string; role: string }) =>
      apiJson(`/team/members/${encodeURIComponent(email)}`, {
        method: "PATCH",
        body: JSON.stringify({ role }),
      }),
    onSuccess: () => qc.invalidateQueries({ queryKey: ["team", "members"] }),
    onError: (e: any) => setErr(e?.message || "Errore"),
  });

  const removeMut = useMutation({
    mutationFn: (email: string) =>
      apiJson(`/team/members/${encodeURIComponent(email)}`, { method: "DELETE" }),
    onSuccess: () => qc.invalidateQueries({ queryKey: ["team", "members"] }),
    onError: (e: any) => setErr(e?.message || "Errore"),
  });

  const codeMut = useMutation({
    mutationFn: (newCode: string) =>
      apiJson("/team/access-code", {
        method: "POST",
        body: JSON.stringify({ code: newCode }),
      }),
    onSuccess: () => {
      Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
      qc.invalidateQueries({ queryKey: ["team", "access-code"] });
    },
    onError: (e: any) => setErr(e?.message || "Errore"),
  });

  if (user?.role !== "admin") {
    return (
      <View style={[styles.root, styles.center, { paddingTop: insets.top }]} testID="team-screen-denied">
        <Ionicons name="lock-closed" size={40} color={colors.muted} />
        <Text style={styles.deniedText}>Solo gli admin possono accedere</Text>
        <Pressable onPress={() => router.back()} style={styles.backBtn}>
          <Text style={styles.backBtnText}>Torna al roster</Text>
        </Pressable>
      </View>
    );
  }

  const submitAdd = () => {
    if (!newEmail.trim() || !newEmail.includes("@")) {
      setErr("Email non valida");
      return;
    }
    setErr(null);
    addMut.mutate({ email: newEmail.trim().toLowerCase(), role: newRole });
  };

  const submitCode = () => {
    if (!code.trim()) {
      setErr("Codice vuoto");
      return;
    }
    setErr(null);
    codeMut.mutate(code.trim());
  };

  const confirmRemove = (email: string) => {
    if (Platform.OS === "web") {
      if (confirm(`Rimuovere ${email} dal team?`)) removeMut.mutate(email);
    } else {
      Alert.alert("Rimuovi membro", `Rimuovere ${email}?`, [
        { text: "Annulla", style: "cancel" },
        { text: "Rimuovi", style: "destructive", onPress: () => removeMut.mutate(email) },
      ]);
    }
  };

  return (
    <View style={[styles.root, { paddingTop: insets.top }]} testID="team-screen">
      <View style={styles.header}>
        <Pressable onPress={() => router.back()} style={styles.headerBack} hitSlop={8}>
          <Ionicons name="chevron-back" size={22} color={colors.onSurface} />
        </Pressable>
        <View>
          <Text style={styles.headerLabel}>GESTIONE</Text>
          <Text style={styles.headerTitle}>TEAM</Text>
        </View>
      </View>

      <KeyboardAvoidingView
        style={{ flex: 1 }}
        behavior={Platform.OS === "ios" ? "padding" : undefined}
      >
        <ScrollView
          contentContainerStyle={{ paddingBottom: insets.bottom + spacing.xxl }}
          keyboardShouldPersistTaps="handled"
        >
          {err ? (
            <View style={styles.errorBox}>
              <Ionicons name="alert-circle" size={16} color={colors.error} />
              <Text style={styles.errorText}>{err}</Text>
            </View>
          ) : null}

          {/* Access code */}
          <View style={styles.section}>
            <Text style={styles.sectionTitle}>CODICE DI ACCESSO</Text>
            <Text style={styles.sectionHelp}>
              Il codice che tutti i membri devono inserire all&apos;apertura dell&apos;app.
            </Text>
            <View style={styles.codeRow}>
              <TextInput
                testID="access-code-current"
                value={code}
                onChangeText={setCode}
                secureTextEntry={!codeVisible}
                autoCapitalize="none"
                autoCorrect={false}
                style={styles.codeInput}
                placeholder="Codice"
                placeholderTextColor={colors.muted}
              />
              <Pressable
                onPress={() => setCodeVisible((v) => !v)}
                style={styles.eyeBtn}
                hitSlop={8}
              >
                <Ionicons
                  name={codeVisible ? "eye-off" : "eye"}
                  size={20}
                  color={colors.onSurfaceSecondary}
                />
              </Pressable>
            </View>
            <Pressable
              testID="save-access-code"
              onPress={submitCode}
              disabled={codeMut.isPending}
              style={({ pressed }) => [
                styles.primaryBtn,
                pressed && { opacity: 0.85 },
                codeMut.isPending && { opacity: 0.6 },
              ]}
            >
              {codeMut.isPending ? (
                <ActivityIndicator color={colors.onBrandPrimary} />
              ) : (
                <>
                  <Ionicons name="save" size={16} color={colors.onBrandPrimary} />
                  <Text style={styles.primaryBtnText}>SALVA CODICE</Text>
                </>
              )}
            </Pressable>
          </View>

          {/* Add member */}
          <View style={styles.section}>
            <Text style={styles.sectionTitle}>AGGIUNGI MEMBRO</Text>
            <Text style={styles.sectionHelp}>
              Solo le email autorizzate qui potranno fare login con Google.
            </Text>
            <TextInput
              testID="new-member-email"
              value={newEmail}
              onChangeText={setNewEmail}
              autoCapitalize="none"
              autoCorrect={false}
              keyboardType="email-address"
              placeholder="email@esempio.it"
              placeholderTextColor={colors.muted}
              style={styles.input}
            />
            <View style={styles.roleRow}>
              {(["member", "admin"] as const).map((r) => {
                const active = newRole === r;
                return (
                  <Pressable
                    key={r}
                    testID={`new-role-${r}`}
                    onPress={() => setNewRole(r)}
                    style={[styles.roleChip, active && styles.roleChipActive]}
                  >
                    <Ionicons
                      name={active ? "checkmark-circle" : "ellipse-outline"}
                      size={16}
                      color={active ? colors.onBrandPrimary : colors.onSurfaceSecondary}
                    />
                    <Text
                      style={[
                        styles.roleChipText,
                        active && { color: colors.onBrandPrimary },
                      ]}
                    >
                      {r === "admin" ? "ADMIN" : "MEMBRO"}
                    </Text>
                  </Pressable>
                );
              })}
            </View>
            <Pressable
              testID="add-member"
              onPress={submitAdd}
              disabled={addMut.isPending}
              style={({ pressed }) => [
                styles.primaryBtn,
                pressed && { opacity: 0.85 },
                addMut.isPending && { opacity: 0.6 },
              ]}
            >
              {addMut.isPending ? (
                <ActivityIndicator color={colors.onBrandPrimary} />
              ) : (
                <>
                  <Ionicons name="person-add" size={16} color={colors.onBrandPrimary} />
                  <Text style={styles.primaryBtnText}>AGGIUNGI AL TEAM</Text>
                </>
              )}
            </Pressable>
          </View>

          {/* Members list */}
          <View style={styles.section}>
            <Text style={styles.sectionTitle}>
              MEMBRI ({membersQ.data?.members?.length || 0})
            </Text>
            {membersQ.isLoading ? (
              <ActivityIndicator color={colors.brandPrimary} />
            ) : (
              (membersQ.data?.members || []).map((m) => {
                const isMe = m.email === (user?.email || "").toLowerCase();
                const isAdmin = m.role === "admin";
                return (
                  <View
                    key={m.email}
                    style={[
                      styles.memberCard,
                      { borderLeftColor: isAdmin ? colors.brandPrimary : colors.borderStrong },
                    ]}
                    testID={`member-${m.email}`}
                  >
                    <View style={{ flex: 1 }}>
                      <Text style={styles.memberEmail} numberOfLines={1}>
                        {m.email} {isMe ? "(tu)" : ""}
                      </Text>
                      <View style={styles.roleBadgeRow}>
                        <View
                          style={[
                            styles.roleBadge,
                            {
                              backgroundColor: isAdmin
                                ? colors.brandPrimary
                                : colors.surfaceTertiary,
                            },
                          ]}
                        >
                          <Text
                            style={[
                              styles.roleBadgeText,
                              {
                                color: isAdmin
                                  ? colors.onBrandPrimary
                                  : colors.onSurfaceSecondary,
                              },
                            ]}
                          >
                            {isAdmin ? "ADMIN" : "MEMBRO"}
                          </Text>
                        </View>
                      </View>
                    </View>
                    <View style={styles.memberActions}>
                      <Pressable
                        testID={`toggle-role-${m.email}`}
                        onPress={() =>
                          roleMut.mutate({
                            email: m.email,
                            role: isAdmin ? "member" : "admin",
                          })
                        }
                        disabled={isMe}
                        style={[styles.iconBtn, isMe && { opacity: 0.3 }]}
                      >
                        <Ionicons
                          name="swap-vertical"
                          size={18}
                          color={colors.onSurfaceSecondary}
                        />
                      </Pressable>
                      <Pressable
                        testID={`remove-${m.email}`}
                        onPress={() => confirmRemove(m.email)}
                        disabled={isMe}
                        style={[styles.iconBtn, isMe && { opacity: 0.3 }]}
                      >
                        <Ionicons name="trash-outline" size={18} color={colors.error} />
                      </Pressable>
                    </View>
                  </View>
                );
              })
            )}
          </View>
        </ScrollView>
      </KeyboardAvoidingView>
    </View>
  );
}

const styles = StyleSheet.create({
  root: { flex: 1, backgroundColor: colors.surface },
  center: { alignItems: "center", justifyContent: "center", padding: spacing.xl },
  deniedText: {
    color: colors.onSurfaceSecondary,
    marginTop: spacing.md,
    fontSize: 14,
  },
  backBtn: {
    marginTop: spacing.lg,
    backgroundColor: colors.brandPrimary,
    paddingVertical: spacing.md,
    paddingHorizontal: spacing.xl,
    borderRadius: radius.sm,
  },
  backBtnText: {
    color: colors.onBrandPrimary,
    fontWeight: "900",
    letterSpacing: 2,
  },
  header: {
    flexDirection: "row",
    alignItems: "center",
    gap: spacing.md,
    paddingHorizontal: spacing.lg,
    paddingVertical: spacing.md,
    borderBottomWidth: 1,
    borderBottomColor: colors.border,
  },
  headerBack: {
    width: 36,
    height: 36,
    borderRadius: radius.sm,
    backgroundColor: colors.surfaceSecondary,
    borderWidth: 1,
    borderColor: colors.borderStrong,
    alignItems: "center",
    justifyContent: "center",
  },
  headerLabel: {
    color: colors.brandPrimary,
    fontSize: 10,
    letterSpacing: 2,
    fontWeight: "800",
  },
  headerTitle: {
    color: colors.onSurface,
    fontSize: 22,
    fontWeight: "900",
    letterSpacing: 3,
  },
  errorBox: {
    flexDirection: "row",
    alignItems: "center",
    gap: spacing.sm,
    marginHorizontal: spacing.lg,
    marginTop: spacing.md,
    padding: spacing.sm,
    borderRadius: radius.sm,
    backgroundColor: colors.surfaceSecondary,
    borderWidth: 1,
    borderColor: colors.error,
  },
  errorText: { color: colors.error, fontSize: 12, flex: 1 },
  section: {
    padding: spacing.lg,
    gap: spacing.sm,
    borderBottomWidth: 1,
    borderBottomColor: colors.border,
  },
  sectionTitle: {
    color: colors.onSurface,
    fontSize: 15,
    fontWeight: "900",
    letterSpacing: 2,
  },
  sectionHelp: {
    color: colors.onSurfaceSecondary,
    fontSize: 12,
    marginBottom: spacing.xs,
  },
  input: {
    backgroundColor: colors.surfaceSecondary,
    borderWidth: 1,
    borderColor: colors.border,
    borderRadius: radius.sm,
    color: colors.onSurface,
    paddingHorizontal: spacing.md,
    paddingVertical: spacing.md,
    fontSize: 15,
  },
  codeRow: {
    flexDirection: "row",
    alignItems: "center",
    gap: spacing.sm,
  },
  codeInput: {
    flex: 1,
    backgroundColor: colors.surfaceSecondary,
    borderWidth: 1,
    borderColor: colors.border,
    borderRadius: radius.sm,
    color: colors.onSurface,
    paddingHorizontal: spacing.md,
    paddingVertical: spacing.md,
    fontSize: 15,
    letterSpacing: 2,
  },
  eyeBtn: {
    width: 44,
    height: 44,
    borderRadius: radius.sm,
    borderWidth: 1,
    borderColor: colors.border,
    backgroundColor: colors.surfaceSecondary,
    alignItems: "center",
    justifyContent: "center",
  },
  primaryBtn: {
    marginTop: spacing.sm,
    backgroundColor: colors.brandPrimary,
    paddingVertical: spacing.md,
    borderRadius: radius.sm,
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "center",
    gap: spacing.sm,
  },
  primaryBtnText: {
    color: colors.onBrandPrimary,
    fontWeight: "900",
    letterSpacing: 2,
    fontSize: 13,
  },
  roleRow: {
    flexDirection: "row",
    gap: spacing.sm,
  },
  roleChip: {
    flex: 1,
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "center",
    gap: spacing.xs,
    padding: spacing.md,
    borderRadius: radius.sm,
    borderWidth: 1,
    borderColor: colors.border,
    backgroundColor: colors.surfaceTertiary,
  },
  roleChipActive: {
    backgroundColor: colors.brandPrimary,
    borderColor: colors.brandPrimary,
  },
  roleChipText: {
    color: colors.onSurface,
    fontSize: 12,
    fontWeight: "800",
    letterSpacing: 2,
  },
  memberCard: {
    flexDirection: "row",
    alignItems: "center",
    gap: spacing.md,
    backgroundColor: colors.surfaceSecondary,
    borderWidth: 1,
    borderColor: colors.border,
    borderLeftWidth: 4,
    borderRadius: radius.sm,
    padding: spacing.md,
    marginBottom: spacing.sm,
  },
  memberEmail: {
    color: colors.onSurface,
    fontSize: 14,
    fontWeight: "700",
  },
  roleBadgeRow: {
    marginTop: spacing.xs,
  },
  roleBadge: {
    alignSelf: "flex-start",
    paddingHorizontal: spacing.sm,
    paddingVertical: 2,
    borderRadius: 4,
  },
  roleBadgeText: {
    fontSize: 10,
    fontWeight: "900",
    letterSpacing: 2,
  },
  memberActions: {
    flexDirection: "row",
    gap: spacing.xs,
  },
  iconBtn: {
    width: 36,
    height: 36,
    borderRadius: radius.sm,
    borderWidth: 1,
    borderColor: colors.borderStrong,
    alignItems: "center",
    justifyContent: "center",
    backgroundColor: colors.surfaceTertiary,
  },
});
