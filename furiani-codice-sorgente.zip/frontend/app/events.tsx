import React, { useMemo, useState } from "react";
import {
  View,
  Text,
  StyleSheet,
  Pressable,
  ScrollView,
  TextInput,
  Modal,
  ActivityIndicator,
  Platform,
  Alert,
  KeyboardAvoidingView,
  Linking,
} from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import { useRouter } from "expo-router";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Ionicons } from "@react-native-vector-icons/ionicons";
import * as Haptics from "expo-haptics";
import * as DocumentPicker from "expo-document-picker";

import { apiJson, apiFetch, BACKEND_URL, getToken } from "@/src/api";
import { useAuth } from "@/src/auth-context";
import { colors, spacing, radius } from "@/src/theme";
import { generateWeekendMonths, monthLabel } from "@/src/weekends";

type Attachment = {
  file_id: string;
  path: string;
  filename: string;
  content_type: string;
  size: number;
  uploaded_at: string;
};

type EventItem = {
  id: string;
  date: string;
  title: string;
  location: string;
  meetup_time: string;
  start_time: string;
  attachments: Attachment[];
};

const MONTH_IT_LONG = [
  "Gennaio", "Febbraio", "Marzo", "Aprile", "Maggio", "Giugno",
  "Luglio", "Agosto", "Settembre", "Ottobre", "Novembre", "Dicembre",
];

function formatItalianDate(iso: string): string {
  const parts = iso.split("-");
  if (parts.length !== 3) return iso;
  const y = parseInt(parts[0], 10);
  const m = parseInt(parts[1], 10) - 1;
  const d = parseInt(parts[2], 10);
  if (isNaN(y) || isNaN(m) || isNaN(d) || m < 0 || m > 11) return iso;
  const dow = new Date(y, m, d).toLocaleDateString("it-IT", { weekday: "long" });
  const dowCap = dow.charAt(0).toUpperCase() + dow.slice(1);
  return `${dowCap} ${d} ${MONTH_IT_LONG[m]} ${y}`;
}

function buildWhatsAppMessage(ev: EventItem): string {
  const lines: string[] = [];
  lines.push(`🪖 *${ev.title}*`);
  lines.push(`📅 ${formatItalianDate(ev.date)}`);
  if (ev.location) lines.push(`📍 ${ev.location}`);
  if (ev.meetup_time) lines.push(`👥 Ritrovo ore ${ev.meetup_time}`);
  if (ev.start_time) lines.push(`▶️ Inizio ore ${ev.start_time}`);
  const attCount = (ev.attachments || []).length;
  if (attCount > 0) {
    lines.push("");
    lines.push(`📎 ${attCount} allegati disponibili sull'app`);
  }
  lines.push("");
  lines.push("— 1° Battaglione Furiani");
  return lines.join("\n");
}

async function openWhatsAppWithText(text: string) {
  const encoded = encodeURIComponent(text);
  if (Platform.OS === "web") {
    const url = `https://wa.me/?text=${encoded}`;
    try {
      if (typeof window !== "undefined") {
        window.open(url, "_blank");
        return;
      }
    } catch {}
    try { await Linking.openURL(url); } catch {
      Alert.alert("WhatsApp non disponibile", "Riprova dal tuo smartphone.");
    }
    return;
  }
  const nativeUrl = `whatsapp://send?text=${encoded}`;
  const webUrl = `https://wa.me/?text=${encoded}`;
  try {
    const supported = await Linking.canOpenURL(nativeUrl);
    if (supported) {
      await Linking.openURL(nativeUrl);
      return;
    }
  } catch {}
  try {
    await Linking.openURL(webUrl);
  } catch {
    Alert.alert("WhatsApp non disponibile", "Installa WhatsApp per inviare il messaggio.");
  }
}



export default function EventsScreen() {
  const insets = useSafeAreaInsets();
  const router = useRouter();
  const qc = useQueryClient();
  const { user, signOut } = useAuth();
  const isAdmin = user?.role === "admin";

  const [modalOpen, setModalOpen] = useState(false);
  const [editing, setEditing] = useState<EventItem | null>(null);
  const [editingDate, setEditingDate] = useState<string>("");
  const [title, setTitle] = useState("");
  const [location, setLocation] = useState("");
  const [meetup, setMeetup] = useState("");
  const [startAt, setStartAt] = useState("");
  const [uploading, setUploading] = useState(false);

  const months = useMemo(() => generateWeekendMonths(), []);

  const eventsQ = useQuery({
    queryKey: ["events"],
    queryFn: async () => (await apiJson<{ events: EventItem[] }>("/events")).events,
  });

  type Notif = { id: string; title: string; date: string; unread: boolean };
  const [showNotifs, setShowNotifs] = useState(false);
  const [views, setViews] = useState<{ user_name: string; viewed_at: string | null }[] | null>(null);
  const notifsQ = useQuery({
    queryKey: ["notifications"],
    queryFn: () => apiJson<{ notifications: Notif[]; unread_count: number }>("/notifications"),
  });
  const unread = notifsQ.data?.unread_count || 0;
  const toggleNotifs = async () => {
    const next = !showNotifs;
    setShowNotifs(next);
    if (next && unread > 0) {
      await apiJson("/notifications/seen", { method: "POST" }).catch(() => {});
      qc.setQueryData(["notifications"], (d: any) => (d ? { ...d, unread_count: 0 } : d));
    }
  };
  const loadViews = async (evId: string) => {
    try {
      const d = await apiJson<{ views: { user_name: string; viewed_at: string | null }[] }>(`/events/${evId}/views`);
      setViews(d.views);
    } catch (e: any) {
      Alert.alert("Errore", e?.message || "Impossibile caricare il registro");
    }
  };

  const byDate = useMemo(() => {
    const map = new Map<string, EventItem[]>();
    for (const e of eventsQ.data || []) {
      const arr = map.get(e.date) || [];
      arr.push(e);
      map.set(e.date, arr);
    }
    return map;
  }, [eventsQ.data]);

  const createMut = useMutation({
    mutationFn: async (p: Partial<EventItem> & { date: string; title: string }) =>
      apiJson<EventItem>("/events", { method: "POST", body: JSON.stringify(p) }),
    onSuccess: (data) => {
      qc.invalidateQueries({ queryKey: ["events"] });
      qc.invalidateQueries({ queryKey: ["notifications"] });
      setEditing(data);
    },
  });
  const updateMut = useMutation({
    mutationFn: async ({ id, patch }: { id: string; patch: Partial<EventItem> }) =>
      apiJson<EventItem>(`/events/${id}`, { method: "PATCH", body: JSON.stringify(patch) }),
    onSuccess: (data) => {
      qc.invalidateQueries({ queryKey: ["events"] });
      setEditing(data);
    },
  });
  const deleteMut = useMutation({
    mutationFn: async (id: string) => apiJson(`/events/${id}`, { method: "DELETE" }),
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ["events"] });
      setModalOpen(false);
    },
  });
  const detachMut = useMutation({
    mutationFn: async ({ evId, fileId }: { evId: string; fileId: string }) =>
      apiJson(`/events/${evId}/attachments/${fileId}`, { method: "DELETE" }),
    onSuccess: async () => {
      qc.invalidateQueries({ queryKey: ["events"] });
      if (editing) {
        const fresh = await apiJson<EventItem>(`/events/${editing.id}`, { method: "PATCH", body: "{}" });
        setEditing(fresh);
      }
    },
  });

  const openCreate = (date: string) => {
    if (!isAdmin) return;
    setEditing(null);
    setEditingDate(date);
    setTitle("");
    setLocation("");
    setMeetup("");
    setStartAt("");
    setModalOpen(true);
  };
  const openEdit = (ev: EventItem) => {
    apiJson(`/events/${ev.id}/view`, { method: "POST" }).catch(() => {});
    setViews(null);
    setEditing(ev);
    setEditingDate(ev.date);
    setTitle(ev.title);
    setLocation(ev.location);
    setMeetup(ev.meetup_time);
    setStartAt(ev.start_time);
    setModalOpen(true);
  };
  const submit = async () => {
    if (!title.trim() || !editingDate) return;
    const patch = {
      title: title.trim(),
      location: location.trim(),
      meetup_time: meetup.trim(),
      start_time: startAt.trim(),
    };
    if (editing) {
      await updateMut.mutateAsync({ id: editing.id, patch });
    } else {
      await createMut.mutateAsync({ date: editingDate, ...patch });
    }
    Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Medium);
  };
  const confirmDelete = () => {
    if (!editing) return;
    const doIt = () => deleteMut.mutate(editing.id);
    if (Platform.OS === "web") {
      if (typeof window !== "undefined" && window.confirm(`Eliminare "${editing.title}"?`)) doIt();
    } else {
      Alert.alert("Elimina evento", `Eliminare "${editing.title}"?`, [
        { text: "Annulla", style: "cancel" },
        { text: "Elimina", style: "destructive", onPress: doIt },
      ]);
    }
  };
  const pickAttachment = async () => {
    if (!editing) return;
    try {
      const result = await DocumentPicker.getDocumentAsync({
        type: ["application/pdf", "image/*"],
        copyToCacheDirectory: true,
        multiple: false,
      });
      if (result.canceled || !result.assets?.length) return;
      const asset = result.assets[0];
      setUploading(true);
      const form = new FormData();
      if (Platform.OS === "web") {
        const r = await fetch(asset.uri);
        const b = await r.blob();
        form.append("file", b, asset.name || "file");
      } else {
        form.append("file", {
          uri: asset.uri,
          name: asset.name || "file",
          type: asset.mimeType || "application/octet-stream",
        } as any);
      }
      const res = await apiFetch(`/events/${editing.id}/attachments`, {
        method: "POST",
        body: form as any,
      });
      if (!res.ok) throw new Error(`Upload failed: ${res.status}`);
      Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
      // Refresh editing event
      const fresh = await apiJson<EventItem>(`/events/${editing.id}`, { method: "PATCH", body: "{}" });
      setEditing(fresh);
      qc.invalidateQueries({ queryKey: ["events"] });
    } catch (e: any) {
      Alert.alert("Errore", e?.message || "Upload fallito");
    } finally {
      setUploading(false);
    }
  };
  const openAttachment = async (att: Attachment) => {
    const url = `${BACKEND_URL}/api/event-files/${editing?.id}/${att.file_id}?token=${encodeURIComponent(getToken() || "")}`;
    if (Platform.OS === "web") {
      if (typeof window !== "undefined") window.open(url, "_blank");
    } else {
      const Linking = await import("expo-linking");
      Linking.openURL(url);
    }
  };

  const formatDay = (date: string) => date.split("-")[2];

  return (
    <View style={[styles.root, { paddingTop: insets.top }]} testID="events-screen">
      <View style={styles.header}>
        <Pressable
          testID="back-home"
          onPress={() => router.push("/home")}
          style={styles.iconChip}
          hitSlop={6}
        >
          <Ionicons name="chevron-back" size={22} color={colors.onSurface} />
        </Pressable>
        <View style={{ flex: 1 }}>
          <Text style={styles.headerLabel}>FURIANI GESTIONALE</Text>
          <Text style={styles.headerTitle}>CALENDARIO</Text>
        </View>
        <Pressable testID="notifications-btn" onPress={toggleNotifs} style={styles.iconChip} hitSlop={6}>
          <Ionicons name="notifications" size={18} color={colors.brandPrimary} />
          {unread > 0 ? (
            <View style={styles.badge} testID="notif-badge">
              <Text style={styles.badgeText}>{unread}</Text>
            </View>
          ) : null}
        </Pressable>
        {isAdmin ? (
          <Pressable testID="analytics-button" onPress={() => router.push("/analytics")} style={styles.iconChip} hitSlop={6}>
            <Ionicons name="stats-chart" size={18} color={colors.brandPrimary} />
          </Pressable>
        ) : null}
        {isAdmin ? (
          <Pressable testID="team-button" onPress={() => router.push("/team")} style={styles.iconChip} hitSlop={6}>
            <Ionicons name="people" size={18} color={colors.brandPrimary} />
          </Pressable>
        ) : null}
        <Pressable testID="logout-btn" onPress={signOut} style={styles.iconChip} hitSlop={6}>
          <Ionicons name="log-out-outline" size={18} color={colors.onSurfaceSecondary} />
        </Pressable>
      </View>

      {showNotifs ? (
        <View style={styles.notifPanel} testID="notif-panel">
          <Text style={styles.notifTitle}>NOTIFICHE</Text>
          {(notifsQ.data?.notifications || []).length === 0 ? (
            <Text style={styles.dayEmpty}>Nessuna notifica</Text>
          ) : (
            (notifsQ.data?.notifications || []).slice(0, 10).map((n) => (
              <View key={n.id} style={styles.notifRow}>
                <Ionicons name="calendar" size={14} color={colors.brandPrimary} />
                <Text style={styles.notifText}>
                  Nuovo evento: <Text style={{ fontWeight: "900" }}>{n.title}</Text> · {formatItalianDate(n.date)}
                </Text>
                {n.unread ? <View style={styles.unreadDot} /> : null}
              </View>
            ))
          )}
        </View>
      ) : null}

      {eventsQ.isLoading ? (
        <View style={styles.loading}>
          <ActivityIndicator color={colors.brandPrimary} />
        </View>
      ) : (
        <ScrollView
          contentContainerStyle={{ paddingHorizontal: spacing.lg, paddingBottom: insets.bottom + spacing.xxl }}
        >
          {months.map((m) => (
            <View key={m.key} style={{ marginTop: spacing.md }}>
              <Text style={styles.monthTitle}>{monthLabel(m.key)} {m.year}</Text>
              <View style={{ gap: spacing.sm }}>
                {m.weekends.map((d) => {
                  const list = byDate.get(d.date) || [];
                  const has = list.length > 0;
                  return (
                    <Pressable
                      key={d.date}
                      testID={`day-${d.date}`}
                      onPress={() => openCreate(d.date)}
                      style={[styles.dayRow, has && styles.dayRowHas]}
                    >
                      <View style={styles.dayCol}>
                        <Text style={styles.dayNum}>{formatDay(d.date)}</Text>
                        <Text style={styles.dayDow}>{d.isSaturday ? "SAB" : "DOM"}</Text>
                      </View>
                      <View style={{ flex: 1, gap: 4 }}>
                        {list.length === 0 ? (
                          <Text style={styles.dayEmpty}>Nessun evento</Text>
                        ) : (
                          list.map((ev) => (
                            <Pressable
                              key={ev.id}
                              onPress={(e) => {
                                e.stopPropagation?.();
                                openEdit(ev);
                              }}
                              style={styles.eventBlock}
                              testID={`event-${ev.id}`}
                            >
                              <Text style={styles.eventTitle}>{ev.title}</Text>
                              {ev.location ? (
                                <View style={styles.evRow}>
                                  <Ionicons name="location" size={11} color={colors.brandPrimary} />
                                  <Text style={styles.evDetail} numberOfLines={2}>{ev.location}</Text>
                                </View>
                              ) : null}
                              {ev.meetup_time ? (
                                <View style={styles.evRow}>
                                  <Ionicons name="people" size={11} color={colors.brandPrimary} />
                                  <Text style={styles.evDetail}>Ritrovo {ev.meetup_time}</Text>
                                </View>
                              ) : null}
                              {ev.start_time ? (
                                <View style={styles.evRow}>
                                  <Ionicons name="play" size={11} color={colors.brandPrimary} />
                                  <Text style={styles.evDetail}>Inizio {ev.start_time}</Text>
                                </View>
                              ) : null}
                              {(ev.attachments || []).length > 0 ? (
                                <View style={styles.evRow}>
                                  <Ionicons name="attach" size={11} color={colors.brandPrimary} />
                                  <Text style={styles.evDetail}>{ev.attachments.length} allegati</Text>
                                </View>
                              ) : null}
                              {isAdmin ? (
                                <Pressable
                                  testID={`wa-share-${ev.id}`}
                                  onPress={(e) => {
                                    e.stopPropagation?.();
                                    try { Haptics.selectionAsync(); } catch {}
                                    const msg = buildWhatsAppMessage(ev);
                                    openWhatsAppWithText(msg);
                                  }}
                                  style={styles.waShareBtn}
                                  hitSlop={6}
                                >
                                  <Ionicons name="logo-whatsapp" size={13} color="#25D366" />
                                  <Text style={styles.waShareText}>INVIA SU WHATSAPP</Text>
                                </Pressable>
                              ) : null}
                            </Pressable>
                          ))
                        )}
                      </View>
                    </Pressable>
                  );
                })}
              </View>
            </View>
          ))}
        </ScrollView>
      )}

      <Modal visible={modalOpen} transparent animationType="fade" onRequestClose={() => setModalOpen(false)}>
        <KeyboardAvoidingView behavior={Platform.OS === "ios" ? "padding" : undefined} style={styles.modalWrap}>
          <ScrollView contentContainerStyle={{ flexGrow: 1, justifyContent: "center" }} keyboardShouldPersistTaps="handled">
            <View style={styles.modalCard}>
              <View style={{ flexDirection: "row", alignItems: "center" }}>
                <View style={{ flex: 1 }}>
                  <Text style={styles.modalTitle}>{editing ? "MODIFICA EVENTO" : "NUOVO EVENTO"}</Text>
                  <Text style={styles.modalDate}>{editingDate}</Text>
                </View>
                <Pressable onPress={() => setModalOpen(false)} hitSlop={8}>
                  <Ionicons name="close" size={22} color={colors.onSurfaceSecondary} />
                </Pressable>
              </View>

              <Text style={styles.label}>TITOLO EVENTO</Text>
              <TextInput
                testID="input-title"
                value={title}
                onChangeText={setTitle}
                placeholder="Es. Partita vs Lupi"
                placeholderTextColor={colors.muted}
                style={styles.input}
                editable={isAdmin}
              />

              <Text style={styles.label}>LUOGO</Text>
              <TextInput
                testID="input-location"
                value={location}
                onChangeText={setLocation}
                placeholder="Es. Campo Furiani, via Roma 1"
                placeholderTextColor={colors.muted}
                style={styles.input}
                editable={isAdmin}
              />

              <View style={{ flexDirection: "row", gap: spacing.sm }}>
                <View style={{ flex: 1 }}>
                  <Text style={styles.label}>ORA RITROVO</Text>
                  <TextInput
                    testID="input-meetup"
                    value={meetup}
                    onChangeText={setMeetup}
                    placeholder="08:30"
                    placeholderTextColor={colors.muted}
                    style={styles.input}
                    editable={isAdmin}
                  />
                </View>
                <View style={{ flex: 1 }}>
                  <Text style={styles.label}>ORA INIZIO</Text>
                  <TextInput
                    testID="input-start"
                    value={startAt}
                    onChangeText={setStartAt}
                    placeholder="09:30"
                    placeholderTextColor={colors.muted}
                    style={styles.input}
                    editable={isAdmin}
                  />
                </View>
              </View>

              {isAdmin ? (
                <Pressable
                  onPress={submit}
                  disabled={!title.trim() || createMut.isPending || updateMut.isPending}
                  style={[
                    styles.saveBtn,
                    (!title.trim() || createMut.isPending || updateMut.isPending) && { opacity: 0.6 },
                  ]}
                  testID="event-save"
                >
                  {createMut.isPending || updateMut.isPending ? (
                    <ActivityIndicator color={colors.onBrandPrimary} />
                  ) : (
                    <Text style={styles.saveText}>{editing ? "SALVA" : "CREA EVENTO"}</Text>
                  )}
                </Pressable>
              ) : null}

              {editing ? (
                <>
                  <View style={styles.divider} />
                  <Text style={styles.label}>ALLEGATI (PDF · FOTO)</Text>
                  {(editing.attachments || []).length === 0 ? (
                    <Text style={styles.help}>Nessun allegato</Text>
                  ) : (
                    <View style={{ gap: spacing.sm, marginTop: spacing.sm }}>
                      {editing.attachments.map((a) => (
                        <View key={a.file_id} style={styles.attRow}>
                          <Ionicons
                            name={a.content_type?.startsWith("image/") ? "image" : "document-text"}
                            size={22}
                            color={colors.brandPrimary}
                          />
                          <View style={{ flex: 1 }}>
                            <Text style={styles.attName} numberOfLines={1}>{a.filename}</Text>
                            <Text style={styles.attMeta}>{(a.size / 1024).toFixed(1)} KB</Text>
                          </View>
                          <Pressable onPress={() => openAttachment(a)} style={styles.iconChip} hitSlop={6} testID={`open-att-${a.file_id}`}>
                            <Ionicons name="open-outline" size={18} color={colors.onSurface} />
                          </Pressable>
                          {isAdmin ? (
                            <Pressable
                              onPress={() => detachMut.mutate({ evId: editing.id, fileId: a.file_id })}
                              style={styles.iconChip}
                              hitSlop={6}
                              testID={`del-att-${a.file_id}`}
                            >
                              <Ionicons name="trash-outline" size={18} color={colors.error} />
                            </Pressable>
                          ) : null}
                        </View>
                      ))}
                    </View>
                  )}
                  {isAdmin ? (
                    <Pressable
                      onPress={pickAttachment}
                      disabled={uploading}
                      style={[styles.saveBtn, { backgroundColor: colors.surfaceTertiary, borderWidth: 1, borderColor: colors.brandPrimary }, uploading && { opacity: 0.6 }]}
                      testID="attach-pick"
                    >
                      {uploading ? (
                        <ActivityIndicator color={colors.brandPrimary} />
                      ) : (
                        <Text style={[styles.saveText, { color: colors.brandPrimary }]}>CARICA PDF / FOTO</Text>
                      )}
                    </Pressable>
                  ) : null}
                  {isAdmin ? (
                    <Pressable
                      onPress={() => loadViews(editing.id)}
                      style={[styles.saveBtn, { backgroundColor: colors.surfaceTertiary, borderWidth: 1, borderColor: colors.border, flexDirection: "row", justifyContent: "center", gap: spacing.sm }]}
                      testID="event-views-btn"
                    >
                      <Ionicons name="eye" size={16} color={colors.brandPrimary} />
                      <Text style={[styles.saveText, { color: colors.brandPrimary }]}>REGISTRO VISUALIZZAZIONI</Text>
                    </Pressable>
                  ) : null}
                  {isAdmin && views ? (
                    <View style={{ gap: 4 }} testID="views-list">
                      <Text style={styles.help}>{views.length} viste</Text>
                      {views.length === 0 ? (
                        <Text style={styles.help}>Nessuno ha ancora visualizzato questo evento.</Text>
                      ) : views.map((v, i) => (
                        <View key={i} style={styles.attRow}>
                          <Ionicons name="person" size={16} color={colors.brandPrimary} />
                          <Text style={[styles.attName, { flex: 1 }]} numberOfLines={1}>{v.user_name}</Text>
                          <Text style={styles.attMeta}>{v.viewed_at ? new Date(v.viewed_at).toLocaleString("it-IT") : ""}</Text>
                        </View>
                      ))}
                    </View>
                  ) : null}
                  {isAdmin ? (
                    <Pressable onPress={confirmDelete} style={styles.deleteBtn} testID="delete-event">
                      <Ionicons name="trash-outline" size={16} color={colors.error} />
                      <Text style={styles.deleteText}>ELIMINA EVENTO</Text>
                    </Pressable>
                  ) : null}
                </>
              ) : null}
            </View>
          </ScrollView>
        </KeyboardAvoidingView>
      </Modal>
    </View>
  );
}

const styles = StyleSheet.create({
  root: { flex: 1, backgroundColor: colors.surface },
  header: {
    flexDirection: "row",
    alignItems: "center",
    gap: spacing.md,
    paddingHorizontal: spacing.lg,
    paddingVertical: spacing.md,
    borderBottomWidth: 1,
    borderBottomColor: colors.border,
  },
  logo: { width: 44, height: 44, borderRadius: 6, borderWidth: 1, borderColor: colors.border },
  headerLabel: { color: colors.brandPrimary, fontSize: 10, letterSpacing: 2, fontWeight: "800" },
  headerTitle: { color: colors.onSurface, fontSize: 22, fontWeight: "900", letterSpacing: 2 },
  iconChip: {
    width: 36,
    height: 36,
    borderRadius: radius.sm,
    backgroundColor: colors.surfaceSecondary,
    alignItems: "center",
    justifyContent: "center",
    borderWidth: 1,
    borderColor: colors.border,
  },
  rosterBtn: {
    flexDirection: "row",
    alignItems: "center",
    gap: spacing.md,
    backgroundColor: colors.brandPrimary,
    marginHorizontal: spacing.lg,
    marginTop: spacing.md,
    paddingHorizontal: spacing.lg,
    paddingVertical: spacing.md,
    borderRadius: radius.sm,
  },
  rosterBtnTitle: { color: colors.onBrandPrimary, fontSize: 14, fontWeight: "900", letterSpacing: 2 },
  rosterBtnSubtitle: { color: colors.onBrandPrimary, opacity: 0.85, fontSize: 11, marginTop: 2 },
  loading: { flex: 1, alignItems: "center", justifyContent: "center" },
  monthTitle: {
    color: colors.brandPrimary,
    fontSize: 13,
    letterSpacing: 2,
    fontWeight: "900",
    marginBottom: spacing.sm,
    marginTop: spacing.md,
  },
  dayRow: {
    flexDirection: "row",
    gap: spacing.md,
    padding: spacing.sm,
    borderRadius: radius.sm,
    borderWidth: 1,
    borderColor: colors.border,
    backgroundColor: colors.surfaceSecondary,
  },
  dayRowHas: { borderColor: colors.brandPrimary },
  dayCol: { width: 54, alignItems: "center", justifyContent: "center" },
  dayNum: { color: colors.onSurface, fontSize: 24, fontWeight: "900" },
  dayDow: { color: colors.onSurfaceSecondary, fontSize: 10, letterSpacing: 1.5, fontWeight: "700" },
  dayEmpty: { color: colors.muted, fontSize: 11, fontStyle: "italic" },
  eventBlock: {
    backgroundColor: colors.surfaceTertiary,
    borderLeftWidth: 3,
    borderLeftColor: colors.brandPrimary,
    paddingHorizontal: spacing.sm,
    paddingVertical: spacing.xs + 2,
    borderRadius: 4,
    gap: 3,
  },
  eventTitle: { color: colors.onSurface, fontSize: 13, fontWeight: "900", letterSpacing: 0.5 },
  evRow: { flexDirection: "row", alignItems: "center", gap: 6 },
  evDetail: { color: colors.onSurfaceSecondary, fontSize: 11, flex: 1 },
  waShareBtn: {
    flexDirection: "row",
    alignItems: "center",
    gap: 5,
    alignSelf: "flex-start",
    paddingHorizontal: 8,
    paddingVertical: 4,
    borderRadius: 999,
    borderWidth: StyleSheet.hairlineWidth,
    borderColor: "#25D366",
    backgroundColor: "rgba(37, 211, 102, 0.08)",
    marginTop: 6,
  },
  waShareText: {
    color: "#25D366",
    fontSize: 10,
    fontWeight: "900",
    letterSpacing: 1,
  },
  modalWrap: {
    flex: 1,
    backgroundColor: "rgba(0,0,0,0.65)",
    padding: spacing.lg,
  },
  modalCard: {
    width: "100%",
    maxWidth: 480,
    alignSelf: "center",
    backgroundColor: colors.surfaceSecondary,
    borderRadius: radius.sm,
    borderWidth: 1,
    borderColor: colors.border,
    padding: spacing.lg,
    gap: spacing.sm,
  },
  modalTitle: { color: colors.onSurface, fontSize: 14, fontWeight: "900", letterSpacing: 2 },
  modalDate: { color: colors.brandPrimary, fontSize: 12, fontWeight: "800", letterSpacing: 1.5 },
  label: {
    color: colors.onSurfaceSecondary,
    fontSize: 11,
    fontWeight: "800",
    letterSpacing: 1.5,
    marginTop: spacing.sm,
  },
  input: {
    color: colors.onSurface,
    fontSize: 15,
    backgroundColor: colors.surfaceTertiary,
    padding: spacing.md,
    borderRadius: radius.sm,
    borderWidth: 1,
    borderColor: colors.border,
  },
  help: { color: colors.muted, fontSize: 11, marginTop: spacing.xs },
  saveBtn: {
    marginTop: spacing.md,
    paddingVertical: spacing.md,
    borderRadius: radius.sm,
    backgroundColor: colors.brandPrimary,
    alignItems: "center",
  },
  saveText: {
    color: colors.onBrandPrimary,
    fontWeight: "900",
    letterSpacing: 2,
    fontSize: 13,
  },
  divider: {
    height: 1,
    backgroundColor: colors.border,
    marginVertical: spacing.md,
  },
  attRow: {
    flexDirection: "row",
    alignItems: "center",
    gap: spacing.sm,
    backgroundColor: colors.surfaceTertiary,
    padding: spacing.sm,
    borderRadius: 4,
    borderWidth: 1,
    borderColor: colors.border,
  },
  attName: { color: colors.onSurface, fontSize: 13, fontWeight: "700" },
  attMeta: { color: colors.muted, fontSize: 10, marginTop: 2 },
  deleteBtn: {
    marginTop: spacing.md,
    flexDirection: "row",
    gap: spacing.xs,
    alignItems: "center",
    justifyContent: "center",
    paddingVertical: spacing.sm,
    borderWidth: 1,
    borderColor: colors.error,
    borderRadius: radius.sm,
  },
  deleteText: { color: colors.error, fontWeight: "900", letterSpacing: 2, fontSize: 11 },
  badge: {
    position: "absolute", top: -4, right: -4, minWidth: 16, height: 16, borderRadius: 8,
    backgroundColor: colors.error, alignItems: "center", justifyContent: "center", paddingHorizontal: 3,
  },
  badgeText: { color: colors.onError, fontSize: 9, fontWeight: "900" },
  notifPanel: {
    marginHorizontal: spacing.lg, marginTop: spacing.md, padding: spacing.md, gap: spacing.xs,
    backgroundColor: colors.surfaceSecondary, borderWidth: 1, borderColor: colors.border, borderRadius: radius.sm,
  },
  notifTitle: { color: colors.brandPrimary, fontSize: 12, fontWeight: "900", letterSpacing: 1 },
  notifRow: {
    flexDirection: "row", alignItems: "center", gap: spacing.sm, paddingVertical: 6,
    borderBottomWidth: 1, borderBottomColor: colors.border,
  },
  notifText: { flex: 1, color: colors.onSurface, fontSize: 13 },
  unreadDot: { width: 8, height: 8, borderRadius: 4, backgroundColor: colors.error },
});
