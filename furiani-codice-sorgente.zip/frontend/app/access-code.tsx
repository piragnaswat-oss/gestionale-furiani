import React, { useState } from "react";
import {
  View,
  Text,
  StyleSheet,
  TextInput,
  Pressable,
  KeyboardAvoidingView,
  Platform,
  ActivityIndicator,
} from "react-native";
import { Image } from "expo-image";
import { LinearGradient } from "expo-linear-gradient";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import { useRouter } from "expo-router";
import { Ionicons } from "@react-native-vector-icons/ionicons";
import * as Haptics from "expo-haptics";

import { colors, spacing, radius } from "@/src/theme";
import { setGatePassed } from "@/src/access-gate";
import { apiJson } from "@/src/api";
import { useAuth, type AuthUser } from "@/src/auth-context";

type VerifyResponse = {
  ok: boolean;
  mode?: "standard" | "editor" | null;
  session_token?: string;
  user?: AuthUser;
};

export default function AccessCodeScreen() {
  const insets = useSafeAreaInsets();
  const router = useRouter();
  const { signInAsEditor } = useAuth();
  const [code, setCode] = useState("");
  const [err, setErr] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);

  const submit = async () => {
    setErr(null);
    if (!code.trim()) {
      setErr("Inserisci il codice");
      return;
    }
    setBusy(true);
    try {
      const res = await apiJson<VerifyResponse>("/access-code/verify", {
        method: "POST",
        body: JSON.stringify({ code: code.trim() }),
      });
      if (!res.ok) {
        Haptics.notificationAsync(Haptics.NotificationFeedbackType.Error);
        setErr("Codice errato");
        setBusy(false);
        return;
      }
      await setGatePassed();
      Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
      // Editor / Viewer mode: auto-sign in with returned session (bypasses Google auth)
      if ((res.mode === "editor" || res.mode === "standard") && res.session_token && res.user) {
        await signInAsEditor(res.session_token, res.user);
      }
      router.replace("/");
    } catch {
      setErr("Errore di rete, riprova");
      setBusy(false);
    }
  };

  return (
    <View style={[styles.root, { paddingTop: insets.top }]} testID="access-code-screen">
      <LinearGradient
        colors={["#0B0D0B", "#101210", "#161816"]}
        style={StyleSheet.absoluteFillObject}
      />
      <KeyboardAvoidingView
        behavior={Platform.OS === "ios" ? "padding" : undefined}
        style={{ flex: 1 }}
      >
        <View style={styles.header}>
          <View style={styles.logoBox}>
            <Image
              source={require("../assets/images/furiani-logo.jpeg")}
              style={styles.logo}
              contentFit="contain"
            />
          </View>
          <Text style={styles.title}>FURIANI</Text>
          <Text style={styles.subtitle}>GESTIONALE</Text>
        </View>

        <View style={styles.form}>
          <Text style={styles.label}>CODICE DI ACCESSO</Text>
          <Text style={styles.help}>
            Inserisci il codice condiviso della squadra per entrare.
          </Text>
          <TextInput
            testID="access-code-input"
            value={code}
            onChangeText={(t) => {
              setCode(t);
              if (err) setErr(null);
            }}
            secureTextEntry
            autoCapitalize="none"
            autoCorrect={false}
            placeholder="Codice"
            placeholderTextColor={colors.muted}
            style={[styles.input, err && { borderColor: colors.error }]}
            onSubmitEditing={submit}
            returnKeyType="go"
          />
          {err ? (
            <View style={styles.errorRow}>
              <Ionicons name="alert-circle" size={16} color={colors.error} />
              <Text style={styles.errorText}>{err}</Text>
            </View>
          ) : null}

          <Pressable
            testID="access-code-submit"
            onPress={submit}
            disabled={busy}
            style={({ pressed }) => [
              styles.btn,
              pressed && { opacity: 0.85 },
              busy && { opacity: 0.6 },
            ]}
          >
            {busy ? (
              <ActivityIndicator color={colors.onBrandPrimary} />
            ) : (
              <>
                <Ionicons name="lock-open" size={18} color={colors.onBrandPrimary} />
                <Text style={styles.btnText}>SBLOCCA</Text>
              </>
            )}
          </Pressable>

          <Text style={[styles.help, { textAlign: "center", marginTop: spacing.lg }]}>
            L&apos;accesso ai dati richiede successivamente il login Google del team.
          </Text>

          <Pressable
            testID="vetrina-link-gate"
            onPress={() => router.push("/vetrina")}
            style={({ pressed }) => [styles.vetrinaLink, pressed && { opacity: 0.7 }]}
            hitSlop={6}
          >
            <Ionicons name="eye-outline" size={14} color={colors.brandPrimary} />
            <Text style={styles.vetrinaLinkText}>VISITA LA VETRINA PUBBLICA</Text>
          </Pressable>
        </View>
      </KeyboardAvoidingView>
    </View>
  );
}

const styles = StyleSheet.create({
  root: { flex: 1, backgroundColor: colors.surface },
  header: {
    alignItems: "center",
    justifyContent: "center",
    paddingVertical: spacing.xxl,
  },
  logoBox: {
    width: 140,
    height: 140,
    borderRadius: 20,
    backgroundColor: colors.surfaceSecondary,
    alignItems: "center",
    justifyContent: "center",
    padding: 8,
    borderWidth: 1,
    borderColor: colors.borderStrong,
  },
  logo: { width: "100%", height: "100%" },
  title: {
    color: colors.onSurface,
    fontSize: 34,
    fontWeight: "900",
    letterSpacing: 4,
    marginTop: spacing.lg,
  },
  subtitle: {
    color: colors.brandPrimary,
    fontSize: 15,
    fontWeight: "800",
    letterSpacing: 6,
    marginTop: 2,
  },
  form: {
    paddingHorizontal: spacing.xl,
    gap: spacing.md,
  },
  label: {
    color: colors.onSurfaceSecondary,
    fontSize: 11,
    letterSpacing: 2,
    fontWeight: "800",
  },
  help: {
    color: colors.onSurfaceSecondary,
    fontSize: 12,
    lineHeight: 18,
  },
  input: {
    backgroundColor: colors.surfaceSecondary,
    borderWidth: 1,
    borderColor: colors.border,
    borderRadius: radius.sm,
    color: colors.onSurface,
    paddingHorizontal: spacing.md,
    paddingVertical: spacing.md,
    fontSize: 16,
    letterSpacing: 2,
  },
  errorRow: {
    flexDirection: "row",
    alignItems: "center",
    gap: spacing.xs,
    marginTop: -spacing.xs,
  },
  errorText: {
    color: colors.error,
    fontSize: 12,
    fontWeight: "700",
  },
  btn: {
    backgroundColor: colors.brandPrimary,
    paddingVertical: spacing.lg,
    borderRadius: radius.sm,
    alignItems: "center",
    justifyContent: "center",
    flexDirection: "row",
    gap: spacing.sm,
    marginTop: spacing.md,
  },
  btnText: {
    color: colors.onBrandPrimary,
    fontWeight: "900",
    letterSpacing: 3,
    fontSize: 14,
  },
  vetrinaLink: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "center",
    gap: 6,
    marginTop: spacing.lg,
    paddingVertical: spacing.sm,
    paddingHorizontal: spacing.md,
    borderRadius: radius.pill,
    borderWidth: StyleSheet.hairlineWidth,
    borderColor: colors.brandPrimary,
    alignSelf: "center",
  },
  vetrinaLinkText: {
    color: colors.brandPrimary,
    fontSize: 11,
    fontWeight: "900",
    letterSpacing: 1.5,
  },
});
