// Access code gate — a shared team passphrase persisted locally.
// This is not a security boundary (it lives client-side); Google Auth handles
// actual auth server-side. It's just a lightweight team-only entry gate.
import { storage } from "@/src/utils/storage";

const KEY = "furiani_access_gate_v1";
export const REQUIRED_CODE = "Mussolini";

export async function isGatePassed(): Promise<boolean> {
  const v = await storage.getItem(KEY);
  return v === "1";
}

export async function setGatePassed(): Promise<void> {
  await storage.setItem(KEY, "1");
}

export async function clearGate(): Promise<void> {
  await storage.removeItem(KEY);
}

export function codeMatches(input: string): boolean {
  return (input || "").trim().toLowerCase() === REQUIRED_CODE.toLowerCase();
}
