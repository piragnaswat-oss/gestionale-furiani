// Calendar helpers for the 2026/27 season (Sept 2026 → Aug 2027)

export type WeekendDay = {
  date: string; // YYYY-MM-DD
  day: number;
  dow: 6 | 0; // 6=Sat, 0=Sun
};

export type MonthGroup = {
  key: string; // YYYY-MM
  label: string; // "SETTEMBRE 2026"
  days: WeekendDay[];
};

export type SeasonMonth = {
  key: string; // YYYY-MM
  label: string; // "SETTEMBRE 2026"
  year: number;
  month: number; // 1-12
};

const MONTH_NAMES_IT = [
  "GENNAIO",
  "FEBBRAIO",
  "MARZO",
  "APRILE",
  "MAGGIO",
  "GIUGNO",
  "LUGLIO",
  "AGOSTO",
  "SETTEMBRE",
  "OTTOBRE",
  "NOVEMBRE",
  "DICEMBRE",
];

function pad(n: number): string {
  return n < 10 ? `0${n}` : String(n);
}

export function generateSeasonMonths(): MonthGroup[] {
  const months: MonthGroup[] = [];
  // Season officially starts Sunday 20 September 2026
  const SEASON_START = new Date(2026, 8, 20);
  let year = 2026;
  let month = 8; // September (0-indexed)
  for (let i = 0; i < 16; i++) {
    const days: WeekendDay[] = [];
    const lastDay = new Date(year, month + 1, 0).getDate();
    for (let d = 1; d <= lastDay; d++) {
      const date = new Date(year, month, d);
      if (date < SEASON_START) continue;
      const dow = date.getDay();
      if (dow === 6 || dow === 0) {
        days.push({
          date: `${year}-${pad(month + 1)}-${pad(d)}`,
          day: d,
          dow: dow as 0 | 6,
        });
      }
    }
    if (days.length > 0) {
      months.push({
        key: `${year}-${pad(month + 1)}`,
        label: `${MONTH_NAMES_IT[month]} ${year}`,
        days,
      });
    }
    month += 1;
    if (month > 11) {
      month = 0;
      year += 1;
    }
    // Stop at December 2027
    if (year === 2028) break;
  }
  return months;
}

export function generateSeasonMonthList(): SeasonMonth[] {
  const months: SeasonMonth[] = [];
  let year = 2026;
  let month = 8;
  for (let i = 0; i < 12; i++) {
    months.push({
      key: `${year}-${pad(month + 1)}`,
      label: `${MONTH_NAMES_IT[month]} ${year}`,
      year,
      month: month + 1,
    });
    month += 1;
    if (month > 11) {
      month = 0;
      year += 1;
    }
  }
  return months;
}

export function isPastDate(dateStr: string): boolean {
  const [y, m, d] = dateStr.split("-").map(Number);
  const endOfDate = new Date(y, m - 1, d + 1);
  return new Date() >= endOfDate;
}

export function isToday(dateStr: string): boolean {
  const [y, m, d] = dateStr.split("-").map(Number);
  const now = new Date();
  return now.getFullYear() === y && now.getMonth() + 1 === m && now.getDate() === d;
}

export function isCurrentOrPastMonth(monthKey: string): boolean {
  // monthKey YYYY-MM. Returns true if that month has started.
  const [y, m] = monthKey.split("-").map(Number);
  const now = new Date();
  const startOfMonth = new Date(y, m - 1, 1);
  return now >= startOfMonth;
}
