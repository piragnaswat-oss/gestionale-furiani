import React, { forwardRef, useImperativeHandle, useRef } from "react";
import { View, StyleSheet } from "react-native";

import { colors } from "@/src/theme";
import { RADAR_HTML, RadarMapHandle } from "./radar-html";

// Web-only: react-native-webview is not supported on web, so the same Leaflet
// page is rendered in an iframe.
const RadarMap = forwardRef<RadarMapHandle>(function RadarMap(_props, ref) {
  const frameRef = useRef<any>(null);
  useImperativeHandle(ref, () => ({
    send: (msg: object) => {
      frameRef.current?.contentWindow?.postMessage(JSON.stringify(msg), "*");
    },
  }));
  return (
    <View style={styles.map} testID="radar-map">
      {React.createElement("iframe", {
        ref: frameRef,
        srcDoc: RADAR_HTML,
        style: { border: 0, width: "100%", height: "100%" },
        title: "radar",
      })}
    </View>
  );
});

export default RadarMap;

const styles = StyleSheet.create({
  map: { flex: 1, backgroundColor: colors.surfaceTertiary },
});
