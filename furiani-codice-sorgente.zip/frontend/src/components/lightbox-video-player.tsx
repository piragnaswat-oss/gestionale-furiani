import React, { useEffect, useState } from "react";
import { View, Text, StyleSheet, Pressable, ActivityIndicator } from "react-native";
import { VideoView, useVideoPlayer, type VideoPlayer } from "expo-video";
import { Ionicons } from "@react-native-vector-icons/ionicons";

import { colors, spacing } from "@/src/theme";

type Props = {
  uri: string;
  filename?: string;
  onError?: (err: string) => void;
};

export default function LightboxVideoPlayer({ uri, filename, onError }: Props) {
  const [loading, setLoading] = useState(true);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);

  const player = useVideoPlayer(uri, (p: VideoPlayer) => {
    p.loop = false;
    p.muted = false;
    p.play();
  });

  // Listen for status changes to detect ready/error
  useEffect(() => {
    const sub = player.addListener("statusChange", (evt: any) => {
      const status = evt?.status || evt;
      if (status === "readyToPlay" || status === "readyForDisplay") {
        setLoading(false);
      }
      if (status === "error" || evt?.error) {
        setLoading(false);
        const msg = evt?.error?.message || "Impossibile riprodurre il video";
        setErrorMsg(msg);
        onError?.(msg);
      }
    });
    return () => {
      try {
        sub.remove();
      } catch {}
    };
  }, [player, onError]);

  // Fallback: hide spinner after short delay in case status event is missed
  useEffect(() => {
    const t = setTimeout(() => setLoading(false), 2500);
    return () => clearTimeout(t);
  }, []);

  return (
    <View style={styles.wrap}>
      <VideoView
        player={player}
        style={styles.video}
        contentFit="contain"
        allowsFullscreen
        allowsPictureInPicture
        nativeControls
      />
      {loading && !errorMsg ? (
        <View pointerEvents="none" style={styles.overlay}>
          <ActivityIndicator color={colors.brandPrimary} size="large" />
          <Text style={styles.hint}>Caricamento video…</Text>
        </View>
      ) : null}
      {errorMsg ? (
        <View style={styles.overlay}>
          <Ionicons name="alert-circle" size={44} color={colors.error} />
          <Text style={styles.errorTitle}>Video non riproducibile</Text>
          <Text style={styles.hint}>{errorMsg}</Text>
          {filename ? <Text style={styles.filename}>{filename}</Text> : null}
          <Pressable
            onPress={() => {
              setErrorMsg(null);
              setLoading(true);
              try {
                player.replace(uri);
                player.play();
              } catch {}
            }}
            style={styles.retryBtn}
          >
            <Ionicons name="refresh" size={16} color={colors.onBrandPrimary} />
            <Text style={styles.retryText}>RIPROVA</Text>
          </Pressable>
        </View>
      ) : null}
    </View>
  );
}

const styles = StyleSheet.create({
  wrap: { flex: 1, backgroundColor: "#000" },
  video: { flex: 1, width: "100%", height: "100%" },
  overlay: {
    position: "absolute",
    top: 0,
    left: 0,
    right: 0,
    bottom: 0,
    alignItems: "center",
    justifyContent: "center",
    gap: spacing.sm,
    backgroundColor: "rgba(0,0,0,0.5)",
    paddingHorizontal: spacing.xl,
  },
  hint: {
    color: colors.onSurface,
    fontSize: 12,
    textAlign: "center",
  },
  errorTitle: {
    color: colors.onSurface,
    fontSize: 15,
    fontWeight: "900",
    letterSpacing: 1,
  },
  filename: {
    color: colors.onSurfaceSecondary,
    fontSize: 11,
    fontStyle: "italic",
    textAlign: "center",
  },
  retryBtn: {
    flexDirection: "row",
    alignItems: "center",
    gap: 6,
    paddingHorizontal: spacing.lg,
    paddingVertical: spacing.sm,
    borderRadius: 999,
    backgroundColor: colors.brandPrimary,
    marginTop: spacing.sm,
  },
  retryText: {
    color: colors.onBrandPrimary,
    fontSize: 11,
    fontWeight: "900",
    letterSpacing: 2,
  },
});
