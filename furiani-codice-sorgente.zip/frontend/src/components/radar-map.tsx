import React, { forwardRef, useImperativeHandle, useRef } from "react";
import { StyleSheet } from "react-native";
import { WebView } from "react-native-webview";

import { colors } from "@/src/theme";
import { RADAR_HTML, RadarMapHandle } from "./radar-html";

const RadarMap = forwardRef<RadarMapHandle>(function RadarMap(_props, ref) {
  const webRef = useRef<WebView>(null);
  useImperativeHandle(ref, () => ({
    send: (msg: object) => {
      webRef.current?.injectJavaScript(`window.radarHandle && window.radarHandle(${JSON.stringify(msg)}); true;`);
    },
  }));
  return (
    <WebView
      ref={webRef}
      testID="radar-map"
      originWhitelist={["*"]}
      source={{ html: RADAR_HTML }}
      style={styles.map}
      javaScriptEnabled
    />
  );
});

export default RadarMap;

const styles = StyleSheet.create({
  map: { flex: 1, backgroundColor: colors.surfaceTertiary },
});
