// Leaflet map page used by the Radar screen (WebView on native, iframe on web).
// The host pushes data by calling window.radarHandle({type, ...}).
export const RADAR_HTML = `<!DOCTYPE html>
<html><head>
<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0" />
<link rel="stylesheet" href="https://unpkg.com/leaflet@1.9.4/dist/leaflet.css" />
<style>html,body,#map{height:100%;margin:0;background:#242824}</style>
</head><body><div id="map"></div>
<script src="https://unpkg.com/leaflet@1.9.4/dist/leaflet.js"></script>
<script>
var map = L.map('map').setView([41.9028, 12.4964], 6);
L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {maxZoom: 19, attribution: '© OpenStreetMap'}).addTo(map);
var markers = {}; var centered = false;
function esc(s){return String(s||'').replace(/[&<>"]/g,function(c){return {'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;'}[c];});}
window.radarHandle = function(msg){
  if (!msg) return;
  if (msg.type === 'focus') { map.setView([msg.lat, msg.lng], 15); return; }
  if (msg.type !== 'positions') return;
  var seen = {};
  (msg.positions || []).forEach(function(p){
    seen[p.user_id] = true;
    var color = p.is_me ? '#5A87B8' : '#6A994E';
    var icon = L.divIcon({html: '<div style="width:18px;height:18px;border-radius:50%;background:'+color+';border:3px solid #fff;box-shadow:0 0 6px rgba(0,0,0,.6)"></div>', className: '', iconSize: [18,18], iconAnchor: [9,9]});
    if (markers[p.user_id]) markers[p.user_id].setLatLng([p.lat, p.lng]).setIcon(icon);
    else markers[p.user_id] = L.marker([p.lat, p.lng], {icon: icon}).addTo(map);
    markers[p.user_id].bindPopup('<b>' + esc(p.name) + (p.is_me ? ' (tu)' : '') + '</b><br/>' + (p.age_seconds || 0) + 's fa');
    if (p.is_me && !centered) { map.setView([p.lat, p.lng], 14); centered = true; }
  });
  Object.keys(markers).forEach(function(id){ if (!seen[id]) { map.removeLayer(markers[id]); delete markers[id]; } });
};
window.addEventListener('message', function(e){ try { window.radarHandle(typeof e.data === 'string' ? JSON.parse(e.data) : e.data); } catch(err){} });
</script></body></html>`;

export type RadarPosition = {
  user_id: string;
  name: string;
  lat: number;
  lng: number;
  age_seconds: number;
  is_me: boolean;
};

export type RadarMapHandle = { send: (msg: object) => void };
