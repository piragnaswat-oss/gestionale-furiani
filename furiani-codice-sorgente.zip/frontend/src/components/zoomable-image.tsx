import React, { useCallback } from "react";
import { StyleSheet, View, ViewStyle } from "react-native";
import { Image, ImageContentFit } from "expo-image";
import {
  Gesture,
  GestureDetector,
} from "react-native-gesture-handler";
import Animated, {
  useAnimatedStyle,
  useSharedValue,
  withTiming,
  runOnJS,
} from "react-native-reanimated";

const AnimatedImage = Animated.createAnimatedComponent(Image);

type Props = {
  uri: string;
  style?: ViewStyle;
  contentFit?: ImageContentFit;
  minScale?: number;
  maxScale?: number;
  onZoomedChange?: (zoomed: boolean) => void;
};

/**
 * Cross-platform pinch-to-zoom image.
 * - Pinch gesture scales from the midpoint between the two fingers
 * - Double tap toggles between fit-to-screen and 2.5x zoom
 * - Pan is enabled only when scale > 1 so the parent gallery can still swipe at scale=1
 */
export default function ZoomableImage({
  uri,
  style,
  contentFit = "contain",
  minScale = 1,
  maxScale = 5,
  onZoomedChange,
}: Props) {
  const scale = useSharedValue(1);
  const savedScale = useSharedValue(1);
  const translateX = useSharedValue(0);
  const translateY = useSharedValue(0);
  const savedTranslateX = useSharedValue(0);
  const savedTranslateY = useSharedValue(0);

  const emitZoomed = useCallback(
    (zoomed: boolean) => {
      onZoomedChange?.(zoomed);
    },
    [onZoomedChange],
  );

  const clamp = (v: number, lo: number, hi: number) => {
    "worklet";
    return v < lo ? lo : v > hi ? hi : v;
  };

  const pinch = Gesture.Pinch()
    .onUpdate((e) => {
      "worklet";
      scale.value = clamp(savedScale.value * e.scale, minScale, maxScale);
    })
    .onEnd(() => {
      "worklet";
      savedScale.value = scale.value;
      if (scale.value <= minScale + 0.01) {
        // snap back to fit
        scale.value = withTiming(1);
        translateX.value = withTiming(0);
        translateY.value = withTiming(0);
        savedScale.value = 1;
        savedTranslateX.value = 0;
        savedTranslateY.value = 0;
        runOnJS(emitZoomed)(false);
      } else {
        runOnJS(emitZoomed)(true);
      }
    });

  const pan = Gesture.Pan()
    .minPointers(1)
    .maxPointers(2)
    .onUpdate((e) => {
      "worklet";
      if (scale.value <= 1.01) return; // let parent handle horizontal swipe
      translateX.value = savedTranslateX.value + e.translationX;
      translateY.value = savedTranslateY.value + e.translationY;
    })
    .onEnd(() => {
      "worklet";
      savedTranslateX.value = translateX.value;
      savedTranslateY.value = translateY.value;
    });

  const doubleTap = Gesture.Tap()
    .numberOfTaps(2)
    .onEnd(() => {
      "worklet";
      if (scale.value > 1.1) {
        scale.value = withTiming(1);
        translateX.value = withTiming(0);
        translateY.value = withTiming(0);
        savedScale.value = 1;
        savedTranslateX.value = 0;
        savedTranslateY.value = 0;
        runOnJS(emitZoomed)(false);
      } else {
        scale.value = withTiming(2.5);
        savedScale.value = 2.5;
        runOnJS(emitZoomed)(true);
      }
    });

  // Simultaneous so pan can work during pinch and double-tap doesn't interfere
  const composed = Gesture.Simultaneous(doubleTap, Gesture.Simultaneous(pinch, pan));

  const animatedStyle = useAnimatedStyle(() => ({
    transform: [
      { translateX: translateX.value },
      { translateY: translateY.value },
      { scale: scale.value },
    ],
  }));

  return (
    <View style={[styles.container, style]}>
      <GestureDetector gesture={composed}>
        <Animated.View style={[StyleSheet.absoluteFill, animatedStyle]}>
          <AnimatedImage
            source={{ uri }}
            style={StyleSheet.absoluteFill}
            contentFit={contentFit}
            transition={150}
          />
        </Animated.View>
      </GestureDetector>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    overflow: "hidden",
  },
});
