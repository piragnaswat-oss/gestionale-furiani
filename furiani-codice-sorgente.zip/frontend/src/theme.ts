// Design tokens: Tactical Dark theme (Softair Squad)
import { useMemo } from "react";
import { Appearance, StyleSheet, useColorScheme } from "react-native";

export type ColorScheme = "light" | "dark";

const dark = {
  surface: "#101210",
  onSurface: "#E2E5E2",
  surfaceSecondary: "#1A1D1A",
  onSurfaceSecondary: "#9FA39F",
  surfaceTertiary: "#242824",
  onSurfaceTertiary: "#B4B8B4",
  surfaceInverse: "#E2E5E2",
  onSurfaceInverse: "#101210",
  muted: "#757A75",

  brand: "#4C6B35",
  onBrand: "#FFFFFF",
  brandPrimary: "#6A994E",
  onBrandPrimary: "#FFFFFF",
  brandSecondary: "#3A5229",
  onBrandSecondary: "#E2E5E2",
  brandTertiary: "#26361C",
  onBrandTertiary: "#8FBA73",

  success: "#6A994E",
  onSuccess: "#FFFFFF",
  warning: "#C28F27",
  onWarning: "#101210",
  error: "#BC4749",
  onError: "#FFFFFF",
  info: "#5A87B8",
  onInfo: "#FFFFFF",

  border: "#2C302C",
  borderStrong: "#454B45",
  divider: "#1A1D1A",
};

export type ThemeColors = typeof dark;

export const defaultScheme = "dark" satisfies ColorScheme;

export const themes: { light?: ThemeColors; dark: ThemeColors } = { dark };

export const spacing = {
  xs: 4,
  sm: 8,
  md: 12,
  lg: 16,
  xl: 24,
  xxl: 32,
  xxxl: 48,
};

export const radius = {
  sm: 2,
  md: 4,
  lg: 8,
  pill: 999,
};

export const fonts = {
  display: "BarlowCondensed_600SemiBold",
  displayBold: "BarlowCondensed_700Bold",
  displayRegular: "BarlowCondensed_500Medium",
  body: "IBMPlexSans_400Regular",
  bodyMedium: "IBMPlexSans_500Medium",
  bodyBold: "IBMPlexSans_600SemiBold",
};

export function setColorScheme(scheme: ColorScheme | null) {
  Appearance.setColorScheme?.(scheme ?? "unspecified");
}

setColorScheme?.("dark");

export function useTheme(): { scheme: ColorScheme; colors: ThemeColors } {
  const system = useColorScheme();
  const scheme: ColorScheme = "dark";
  return { scheme, colors: themes.dark };
}

export const colors = themes.dark;

export function makeStyles<T extends StyleSheet.NamedStyles<T> | StyleSheet.NamedStyles<any>>(
  factory: (colors: ThemeColors) => T & StyleSheet.NamedStyles<any>,
): () => T {
  return function useStyles(): T {
    const { colors } = useTheme();
    return useMemo(() => StyleSheet.create(factory(colors)), [colors]);
  };
}
