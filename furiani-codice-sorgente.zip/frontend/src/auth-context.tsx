import React, { createContext, useContext, useEffect, useMemo, useState, useCallback, useRef } from "react";
import { AppState, Platform } from "react-native";
import * as Linking from "expo-linking";
import * as WebBrowser from "expo-web-browser";

import {
  apiJson,
  clearToken,
  getToken,
  loadTokenFromStorage,
  saveToken,
  setToken,
} from "@/src/api";

try {
  WebBrowser.maybeCompleteAuthSession();
} catch {}

export type AuthUser = {
  user_id: string;
  email: string;
  name: string;
  picture?: string | null;
  role: "admin" | "member" | "editor" | "viewer";
};

type AuthState = {
  status: "loading" | "authenticated" | "unauthenticated";
  user: AuthUser | null;
  signIn: () => Promise<void>;
  signOut: () => Promise<void>;
  signInAsEditor: (token: string, user: AuthUser) => Promise<void>;
  error: string | null;
};

const AuthContext = createContext<AuthState | null>(null);

const processedSessionIds = new Set<string>();

function extractSessionId(url: string | null | undefined): string | null {
  if (!url) return null;
  const m = url.match(/[?#&]session_id=([^&#]+)/);
  return m ? decodeURIComponent(m[1]) : null;
}

export function AuthProvider({ children }: { children: React.ReactNode }) {
  const [status, setStatus] = useState<AuthState["status"]>("loading");
  const [user, setUser] = useState<AuthUser | null>(null);
  const [error, setError] = useState<string | null>(null);
  const sessionLogIdRef = useRef<string | null>(null);
  const heartbeatTimerRef = useRef<ReturnType<typeof setInterval> | null>(null);

  const stopHeartbeat = useCallback(() => {
    if (heartbeatTimerRef.current) {
      clearInterval(heartbeatTimerRef.current);
      heartbeatTimerRef.current = null;
    }
  }, []);

  const sendHeartbeat = useCallback(async () => {
    try {
      const res = await apiJson<{ log_id: string }>("/analytics/session/heartbeat", {
        method: "POST",
        body: JSON.stringify({ log_id: sessionLogIdRef.current }),
      });
      if (res?.log_id) sessionLogIdRef.current = res.log_id;
    } catch {}
  }, []);

  const startSessionTracking = useCallback(async () => {
    try {
      const res = await apiJson<{ log_id: string }>("/analytics/session/start", {
        method: "POST",
        body: JSON.stringify({}),
      });
      sessionLogIdRef.current = res?.log_id || null;
    } catch {
      sessionLogIdRef.current = null;
    }
    stopHeartbeat();
    heartbeatTimerRef.current = setInterval(sendHeartbeat, 60_000);
  }, [sendHeartbeat, stopHeartbeat]);

  const endSessionTracking = useCallback(async () => {
    stopHeartbeat();
    const id = sessionLogIdRef.current;
    sessionLogIdRef.current = null;
    if (!id) return;
    try {
      await apiJson("/analytics/session/end", {
        method: "POST",
        body: JSON.stringify({ log_id: id }),
      });
    } catch {}
  }, [stopHeartbeat]);

  const exchangeSessionId = useCallback(async (sessionId: string) => {
    if (processedSessionIds.has(sessionId)) return;
    processedSessionIds.add(sessionId);
    try {
      const data = await apiJson<{ session_token: string; user: AuthUser }>(
        "/auth/session",
        { method: "POST", body: JSON.stringify({ session_id: sessionId }) },
      );
      await saveToken(data.session_token);
      setUser(data.user);
      setStatus("authenticated");
      setError(null);
    } catch (e: any) {
      setError(e?.message || "Login failed");
      setStatus("unauthenticated");
    }
  }, []);

  // Bootstrap: check existing token OR process incoming session_id
  useEffect(() => {
    let cancelled = false;
    (async () => {
      try {
        // 1. Web: check URL for session_id first
        if (Platform.OS === "web" && typeof window !== "undefined") {
          const href = window.location.href;
          const sid = extractSessionId(href);
          if (sid) {
            await exchangeSessionId(sid);
            // Clean URL (remove session_id fragment/query)
            try {
              const url = new URL(window.location.href);
              url.hash = url.hash.replace(/[#&]?session_id=[^&]+/g, "").replace(/^#$/, "");
              url.searchParams.delete("session_id");
              window.history.replaceState(
                window.history.state,
                "",
                url.pathname + url.search + url.hash,
              );
            } catch {}
            return;
          }
        } else {
          // Mobile cold start
          const initial = await Linking.getInitialURL();
          const sid = extractSessionId(initial);
          if (sid) {
            await exchangeSessionId(sid);
            return;
          }
        }

        // 2. Check existing token
        const token = await loadTokenFromStorage();
        if (!token) {
          if (!cancelled) setStatus("unauthenticated");
          return;
        }
        setToken(token);
        try {
          const me = await apiJson<AuthUser>("/auth/me");
          if (!cancelled) {
            setUser(me);
            setStatus("authenticated");
          }
        } catch {
          await clearToken();
          if (!cancelled) {
            setUser(null);
            setStatus("unauthenticated");
          }
        }
      } catch (e: any) {
        if (!cancelled) {
          setError(e?.message || "Auth init error");
          setStatus("unauthenticated");
        }
      }
    })();
    return () => {
      cancelled = true;
    };
  }, [exchangeSessionId]);

  // Mobile: listen for deep links while app is running
  useEffect(() => {
    if (Platform.OS === "web") return;
    const sub = Linking.addEventListener("url", (event) => {
      const sid = extractSessionId(event.url);
      if (sid) exchangeSessionId(sid);
    });
    return () => sub.remove();
  }, [exchangeSessionId]);

  const signIn = useCallback(async () => {
    setError(null);
    const redirectUrl =
      Platform.OS === "web" && typeof window !== "undefined"
        ? window.location.origin + "/"
        : Linking.createURL("");
    const authUrl = `https://auth.emergentagent.com/?redirect=${encodeURIComponent(redirectUrl)}`;
    if (Platform.OS === "web") {
      if (typeof window !== "undefined") window.location.href = authUrl;
      return;
    }
    // Listener that captures URL for Android Custom Tabs fallback
    let capturedUrl: string | null = null;
    const sub = Linking.addEventListener("url", (event) => {
      capturedUrl = event.url;
    });
    try {
      const result = await WebBrowser.openAuthSessionAsync(authUrl, redirectUrl);
      let url: string | null = null;
      if (result.type === "success" && (result as any).url) {
        url = (result as any).url;
      }
      if (!url && capturedUrl) url = capturedUrl;
      if (!url) {
        const initial = await Linking.getInitialURL();
        if (initial) url = initial;
      }
      const sid = extractSessionId(url);
      if (sid) {
        await exchangeSessionId(sid);
      } else if (result.type !== "success") {
        // user cancelled genuinely — no-op
      }
    } catch (e: any) {
      setError(e?.message || "Sign-in failed");
    } finally {
      sub.remove();
    }
  }, [exchangeSessionId]);

  const signOut = useCallback(async () => {
    try {
      await endSessionTracking();
    } catch {}
    try {
      await apiJson("/auth/logout", { method: "POST" });
    } catch {}
    await clearToken();
    setUser(null);
    setStatus("unauthenticated");
  }, [endSessionTracking]);

  const signInAsEditor = useCallback(
    async (token: string, editorUser: AuthUser) => {
      try {
        await endSessionTracking();
      } catch {}
      await saveToken(token);
      setUser(editorUser);
      setStatus("authenticated");
      setError(null);
    },
    [endSessionTracking],
  );

  // Start/stop session tracking when auth status changes
  useEffect(() => {
    if (status === "authenticated" && user) {
      startSessionTracking();
    }
    return () => {
      stopHeartbeat();
    };
    // Only re-run when auth transitions, not on user mutations
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [status, user?.user_id]);

  // Beacon: close session when the browser tab/app closes
  useEffect(() => {
    if (Platform.OS === "web" && typeof window !== "undefined") {
      const handler = () => {
        const id = sessionLogIdRef.current;
        if (!id) return;
        try {
          const url = `${process.env.EXPO_PUBLIC_BACKEND_URL || ""}/api/analytics/session/end`;
          const token = getToken();
          void fetch(url, {
            method: "POST",
            headers: {
              "Content-Type": "application/json",
              ...(token ? { Authorization: `Bearer ${token}` } : {}),
            },
            body: JSON.stringify({ log_id: id }),
            keepalive: true,
          }).catch(() => {});
        } catch {}
      };
      window.addEventListener("beforeunload", handler);
      window.addEventListener("pagehide", handler);
      return () => {
        window.removeEventListener("beforeunload", handler);
        window.removeEventListener("pagehide", handler);
      };
    }
    // Native: send heartbeat/end on background
    const sub = AppState.addEventListener("change", (next) => {
      if (next === "background" || next === "inactive") {
        void sendHeartbeat();
      } else if (next === "active" && status === "authenticated") {
        void sendHeartbeat();
      }
    });
    return () => sub.remove();
  }, [sendHeartbeat, status]);

  const value = useMemo<AuthState>(
    () => ({ status, user, signIn, signOut, signInAsEditor, error }),
    [status, user, signIn, signOut, signInAsEditor, error],
  );

  return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>;
}

export function useAuth() {
  const ctx = useContext(AuthContext);
  if (!ctx) throw new Error("useAuth must be used within AuthProvider");
  return ctx;
}
