// Weekend generator from today through end of 2027
// Returns a list of months each with its Saturdays and Sundays

export type WeekendDate = {
  date: string;
  day: number;
  isSaturday: boolean;
};

export type WeekendMonth = {
  key: string;
  year: number;
  month: number;
  weekends: WeekendDate[];
};

function pad(n: number): string {
  return n < 10 ? `0${n}` : String(n);
}

export function generateWeekendMonths(): WeekendMonth[] {
  // Season starts Sunday 20 September 2026 and runs through 31 December 2027
  const start = new Date(2026, 8, 20); // Sep 20 2026 (month index 8 = September)
  const end = new Date(2027, 11, 31);
  const months: WeekendMonth[] = [];
  const cur = new Date(start.getFullYear(), start.getMonth(), 1);
  while (cur <= end) {
    const y = cur.getFullYear();
    const m = cur.getMonth();
    const key = `${y}-${pad(m + 1)}`;
    const weekends: WeekendDate[] = [];
    const d = new Date(y, m, 1);
    while (d.getMonth() === m) {
      const dow = d.getDay();
      if (dow === 0 || dow === 6) {
        if (d >= start) {
          weekends.push({
            date: `${y}-${pad(m + 1)}-${pad(d.getDate())}`,
            day: d.getDate(),
            isSaturday: dow === 6,
          });
        }
      }
      d.setDate(d.getDate() + 1);
    }
    if (weekends.length > 0) {
      months.push({ key, year: y, month: m + 1, weekends });
    }
    cur.setMonth(cur.getMonth() + 1);
  }
  return months;
}

export function monthLabel(key: string): string {
  const names = [
    "Gennaio", "Febbraio", "Marzo", "Aprile",
    "Maggio", "Giugno", "Luglio", "Agosto",
    "Settembre", "Ottobre", "Novembre", "Dicembre",
  ];
  const parts = key.split("-");
  const m = parseInt(parts[1], 10);
  return names[m - 1];
}
