// API client
import { storage } from "@/src/utils/storage";

export const AUTH_TOKEN_KEY = "softair_session_token";
export const BACKEND_URL = process.env.EXPO_PUBLIC_BACKEND_URL || "";

let inMemoryToken: string | null = null;

export function setToken(token: string | null) {
  inMemoryToken = token;
}

export function getToken(): string | null {
  return inMemoryToken;
}

export async function loadTokenFromStorage(): Promise<string | null> {
  const t = await storage.secureGet<string>(AUTH_TOKEN_KEY, "");
  const tok = t && typeof t === "string" && t.length > 0 ? t : null;
  inMemoryToken = tok;
  return tok;
}

export async function saveToken(token: string) {
  inMemoryToken = token;
  await storage.secureSet(AUTH_TOKEN_KEY, token);
}

export async function clearToken() {
  inMemoryToken = null;
  await storage.secureRemove(AUTH_TOKEN_KEY);
}

export async function apiFetch(path: string, options: RequestInit = {}): Promise<Response> {
  const url = `${BACKEND_URL}/api${path}`;
  const headers: Record<string, string> = {
    ...(options.headers as Record<string, string> | undefined),
  };
  if (inMemoryToken) {
    headers["Authorization"] = `Bearer ${inMemoryToken}`;
  }
  const res = await fetch(url, { ...options, headers });
  return res;
}

export async function apiJson<T = any>(path: string, options: RequestInit = {}): Promise<T> {
  const res = await apiFetch(path, {
    ...options,
    headers: {
      "Content-Type": "application/json",
      ...(options.headers as Record<string, string> | undefined),
    },
  });
  if (!res.ok) {
    const text = await res.text().catch(() => "");
    let detail = text || res.statusText;
    try {
      const j = JSON.parse(text);
      if (j && typeof j.detail === "string") detail = j.detail;
    } catch {}
    const err = new Error(detail) as Error & { status?: number };
    err.status = res.status;
    throw err;
  }
  const ct = res.headers.get("content-type") || "";
  if (ct.includes("application/json")) return (await res.json()) as T;
  return (await res.text()) as unknown as T;
}
