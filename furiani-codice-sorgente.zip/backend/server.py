from fastapi import FastAPI, APIRouter, HTTPException, Header, UploadFile, File, Form, Query
from fastapi.responses import Response
from starlette.concurrency import run_in_threadpool
from dotenv import load_dotenv
from starlette.middleware.cors import CORSMiddleware
from motor.motor_asyncio import AsyncIOMotorClient
import os
import logging
import hashlib
import uuid
from pathlib import Path
from datetime import datetime, timezone, timedelta
from typing import List, Optional
from pydantic import BaseModel, Field
import httpx
import requests


ROOT_DIR = Path(__file__).parent
load_dotenv(ROOT_DIR / '.env')

# MongoDB connection
mongo_url = os.environ['MONGO_URL']
client = AsyncIOMotorClient(mongo_url)
db = client[os.environ['DB_NAME']]

# Object Storage config
STORAGE_BASE = (os.environ.get("INTEGRATION_PROXY_URL") or "").strip() or "https://integrations.emergentagent.com"
STORAGE_URL = STORAGE_BASE.rstrip("/") + "/objstore/api/v1/storage"
EMERGENT_KEY = os.environ.get("EMERGENT_LLM_KEY")
APP_NAME = "softair-squad"
_storage_key: Optional[str] = None


def init_storage() -> str:
    global _storage_key
    if _storage_key:
        return _storage_key
    resp = requests.post(f"{STORAGE_URL}/init", json={"emergent_key": EMERGENT_KEY}, timeout=30)
    resp.raise_for_status()
    _storage_key = resp.json()["storage_key"]
    return _storage_key


def put_object(path: str, data: bytes, content_type: str) -> dict:
    key = init_storage()
    resp = requests.put(
        f"{STORAGE_URL}/objects/{path}",
        headers={"X-Storage-Key": key, "Content-Type": content_type},
        data=data,
        timeout=120,
    )
    resp.raise_for_status()
    return resp.json()


def get_object(path: str) -> tuple:
    global _storage_key
    key = init_storage()
    resp = requests.get(
        f"{STORAGE_URL}/objects/{path}",
        headers={"X-Storage-Key": key},
        timeout=60,
    )
    if resp.status_code == 503:
        _storage_key = None
        key = init_storage()
        resp = requests.get(
            f"{STORAGE_URL}/objects/{path}",
            headers={"X-Storage-Key": key},
            timeout=60,
        )
    resp.raise_for_status()
    return resp.content, resp.headers.get("Content-Type", "application/octet-stream")


# App
app = FastAPI()
api_router = APIRouter(prefix="/api")


# --------- MODELS ----------
class SessionRequest(BaseModel):
    session_id: str


class UserResponse(BaseModel):
    user_id: str
    email: str
    name: str
    picture: Optional[str] = None
    role: str = "member"


class SessionResponse(BaseModel):
    session_token: str
    user: UserResponse


class MemberIn(BaseModel):
    email: str
    role: str = "member"  # "admin" | "member"


class MemberRoleUpdate(BaseModel):
    role: str  # "admin" | "member"


class AccessCodeUpdate(BaseModel):
    code: str


class AccessCodeVerify(BaseModel):
    code: str


class OperatorCreate(BaseModel):
    battle_name: str
    real_name: str = ""
    phone: str = ""
    rank: str = ""
    department: str = "630 ROCS"
    email: str = ""


class OperatorUpdate(BaseModel):
    battle_name: Optional[str] = None
    real_name: Optional[str] = None
    phone: Optional[str] = None
    rank: Optional[str] = None
    department: Optional[str] = None
    behavioral_notes: Optional[str] = None
    annual_fee_paid: Optional[bool] = None
    annual_fee_amount: Optional[float] = None
    email: Optional[str] = None


class AttendanceToggle(BaseModel):
    date: str  # YYYY-MM-DD
    present: bool = True
    status: Optional[str] = None  # "present" | "rest" (optional; falls back to present)


class PaymentToggle(BaseModel):
    month: str  # YYYY-MM
    paid: bool


class SessionLogIn(BaseModel):
    log_id: Optional[str] = None


class PhotoAlbumIn(BaseModel):
    year: int
    album: str
    caption: str = ""


class PrivatePasswordIn(BaseModel):
    password: str


class PrivateCheckIn(BaseModel):
    password: str


# --------- AUTH HELPERS ----------
DEFAULT_ACCESS_CODE = "Mussolini"
GUEST_EDITOR_CODE = "Mussolini89"
GUEST_EDITOR_EMAIL = "guest-editor@furiani.local"
GUEST_EDITOR_USER_ID = "user_guest_editor_fixed"
GATE_VIEWER_EMAIL = "gate-viewer@furiani.local"
GATE_VIEWER_USER_ID = "user_gate_viewer_fixed"
OWNER_EMAIL = "alessandro.p89@gmail.com"  # Excluded from analytics


def _norm_email(e: str) -> str:
    return (e or "").strip().lower()


async def get_role_for_email(email: str) -> Optional[str]:
    m = await db.members.find_one({"email": _norm_email(email)}, {"_id": 0})
    return m["role"] if m else None


async def ensure_bootstrap_admin(email: str) -> str:
    """If the members collection is empty, promote the first login to admin.
    Returns the role granted."""
    count = await db.members.count_documents({})
    if count == 0:
        await db.members.insert_one({
            "email": _norm_email(email),
            "role": "admin",
            "added_by": "bootstrap",
            "created_at": datetime.now(timezone.utc),
        })
        return "admin"
    return None


async def get_access_code() -> str:
    doc = await db.settings.find_one({"key": "access_code"}, {"_id": 0})
    if doc and isinstance(doc.get("value"), str) and doc["value"]:
        return doc["value"]
    # seed default
    await db.settings.update_one(
        {"key": "access_code"},
        {"$set": {"key": "access_code", "value": DEFAULT_ACCESS_CODE}},
        upsert=True,
    )
    return DEFAULT_ACCESS_CODE


async def get_current_user(authorization: Optional[str] = Header(None)) -> dict:
    if not authorization or not authorization.lower().startswith("bearer "):
        raise HTTPException(status_code=401, detail="Missing token")
    token = authorization.split(" ", 1)[1].strip()
    session = await db.user_sessions.find_one({"session_token": token}, {"_id": 0})
    if not session:
        raise HTTPException(status_code=401, detail="Invalid session")
    expires_at = session.get("expires_at")
    if isinstance(expires_at, datetime):
        if expires_at.tzinfo is None:
            expires_at = expires_at.replace(tzinfo=timezone.utc)
        if expires_at < datetime.now(timezone.utc):
            raise HTTPException(status_code=401, detail="Session expired")
    user = await db.users.find_one({"user_id": session["user_id"]}, {"_id": 0})
    if not user:
        raise HTTPException(status_code=401, detail="User not found")
    # Attach role (auto-join as member if missing, but keep session valid)
    role = await get_role_for_email(user.get("email", ""))
    if not role:
        bootstrap = await ensure_bootstrap_admin(user.get("email", ""))
        if bootstrap:
            role = bootstrap
        else:
            await db.members.insert_one({
                "email": _norm_email(user.get("email", "")),
                "role": "member",
                "added_by": "auto_signup",
                "created_at": datetime.now(timezone.utc),
            })
            role = "member"
    user["role"] = role
    return user


async def require_admin(user: dict) -> dict:
    if user.get("role") != "admin":
        raise HTTPException(status_code=403, detail="Admin only")
    return user


async def require_admin_or_editor(user: dict) -> dict:
    """Allow full admins AND the shared 'editor' role (Mussolini89 guest editor).
    Used for photo/video upload+download in both public and private archives."""
    role = user.get("role")
    if role not in ("admin", "editor"):
        raise HTTPException(status_code=403, detail="Permesso insufficiente")
    return user


async def _ensure_guest_editor_user() -> str:
    """Make sure the shared guest-editor pseudo user + members record exists.
    Returns the user_id."""
    existing = await db.users.find_one({"user_id": GUEST_EDITOR_USER_ID}, {"_id": 0})
    if not existing:
        await db.users.insert_one({
            "user_id": GUEST_EDITOR_USER_ID,
            "email": GUEST_EDITOR_EMAIL,
            "name": "Guest Editor",
            "picture": None,
            "created_at": datetime.now(timezone.utc),
        })
    member = await db.members.find_one({"email": GUEST_EDITOR_EMAIL}, {"_id": 0})
    if not member:
        await db.members.insert_one({
            "email": GUEST_EDITOR_EMAIL,
            "role": "editor",
            "added_by": "system",
            "created_at": datetime.now(timezone.utc),
        })
    elif member.get("role") != "editor":
        await db.members.update_one(
            {"email": GUEST_EDITOR_EMAIL},
            {"$set": {"role": "editor"}},
        )
    return GUEST_EDITOR_USER_ID


async def _ensure_gate_viewer_user() -> str:
    """Make sure the shared gate-viewer pseudo user + members record exists.
    This is the pseudo user used for anyone who entered the Mussolini (standard) access code
    without a Google login. Grants VIEW-only access to Prova Fisica."""
    existing = await db.users.find_one({"user_id": GATE_VIEWER_USER_ID}, {"_id": 0})
    if not existing:
        await db.users.insert_one({
            "user_id": GATE_VIEWER_USER_ID,
            "email": GATE_VIEWER_EMAIL,
            "name": "Gate Viewer",
            "picture": None,
            "created_at": datetime.now(timezone.utc),
        })
    member = await db.members.find_one({"email": GATE_VIEWER_EMAIL}, {"_id": 0})
    if not member:
        await db.members.insert_one({
            "email": GATE_VIEWER_EMAIL,
            "role": "viewer",
            "added_by": "system",
            "created_at": datetime.now(timezone.utc),
        })
    elif member.get("role") != "viewer":
        await db.members.update_one(
            {"email": GATE_VIEWER_EMAIL},
            {"$set": {"role": "viewer"}},
        )
    return GATE_VIEWER_USER_ID


# --------- AUTH ROUTES ----------
@api_router.post("/auth/session", response_model=SessionResponse)
async def create_session(payload: SessionRequest):
    async with httpx.AsyncClient(timeout=30) as ac:
        r = await ac.get(
            "https://demobackend.emergentagent.com/auth/v1/env/oauth/session-data",
            headers={"X-Session-ID": payload.session_id},
        )
    if r.status_code != 200:
        raise HTTPException(status_code=401, detail="Invalid session_id")
    data = r.json()
    email = data.get("email")
    name = data.get("name", "")
    picture = data.get("picture")
    session_token = data.get("session_token")
    if not email or not session_token:
        raise HTTPException(status_code=401, detail="Bad session data")

    existing = await db.users.find_one({"email": email}, {"_id": 0})
    if existing:
        user_id = existing["user_id"]
        await db.users.update_one(
            {"user_id": user_id},
            {"$set": {"name": name, "picture": picture}},
        )
    else:
        user_id = f"user_{uuid.uuid4().hex[:12]}"
        await db.users.insert_one({
            "user_id": user_id,
            "email": email,
            "name": name,
            "picture": picture,
            "created_at": datetime.now(timezone.utc),
        })

    # Bootstrap first login as admin; subsequent logins auto-join as member
    role = await get_role_for_email(email)
    if not role:
        bootstrap = await ensure_bootstrap_admin(email)
        if bootstrap:
            role = bootstrap
        else:
            await db.members.insert_one({
                "email": _norm_email(email),
                "role": "member",
                "added_by": "auto_signup",
                "created_at": datetime.now(timezone.utc),
            })
            role = "member"

    await db.user_sessions.insert_one({
        "session_token": session_token,
        "user_id": user_id,
        "expires_at": datetime.now(timezone.utc) + timedelta(days=7),
        "created_at": datetime.now(timezone.utc),
    })

    return SessionResponse(
        session_token=session_token,
        user=UserResponse(
            user_id=user_id, email=email, name=name, picture=picture, role=role,
        ),
    )


@api_router.get("/auth/me", response_model=UserResponse)
async def me(authorization: Optional[str] = Header(None)):
    user = await get_current_user(authorization)
    return UserResponse(
        user_id=user["user_id"],
        email=user["email"],
        name=user.get("name", ""),
        picture=user.get("picture"),
        role=user.get("role", "member"),
    )


@api_router.post("/auth/logout")
async def logout(authorization: Optional[str] = Header(None)):
    if authorization and authorization.lower().startswith("bearer "):
        token = authorization.split(" ", 1)[1].strip()
        await db.user_sessions.delete_one({"session_token": token})
    return {"ok": True}


# --------- ACCESS CODE (public verify + admin manage) ----------
@api_router.post("/access-code/verify")
async def verify_access_code(payload: AccessCodeVerify):
    raw = (payload.code or "").strip()
    stored = await get_access_code()
    is_guest_editor = raw.lower() == GUEST_EDITOR_CODE.lower()
    is_standard = raw.lower() == (stored or "").strip().lower()

    if is_guest_editor:
        await _ensure_guest_editor_user()
        session_token = f"editor_{uuid.uuid4().hex}"
        await db.user_sessions.insert_one({
            "session_token": session_token,
            "user_id": GUEST_EDITOR_USER_ID,
            "expires_at": datetime.now(timezone.utc) + timedelta(days=30),
            "created_at": datetime.now(timezone.utc),
            "is_guest_editor": True,
        })
        return {
            "ok": True,
            "mode": "editor",
            "session_token": session_token,
            "user": {
                "user_id": GUEST_EDITOR_USER_ID,
                "email": GUEST_EDITOR_EMAIL,
                "name": "Guest Editor",
                "picture": None,
                "role": "editor",
            },
        }

    if is_standard:
        await _ensure_gate_viewer_user()
        session_token = f"viewer_{uuid.uuid4().hex}"
        await db.user_sessions.insert_one({
            "session_token": session_token,
            "user_id": GATE_VIEWER_USER_ID,
            "expires_at": datetime.now(timezone.utc) + timedelta(days=30),
            "created_at": datetime.now(timezone.utc),
            "is_gate_viewer": True,
        })
        return {
            "ok": True,
            "mode": "standard",
            "session_token": session_token,
            "user": {
                "user_id": GATE_VIEWER_USER_ID,
                "email": GATE_VIEWER_EMAIL,
                "name": "Gate Viewer",
                "picture": None,
                "role": "viewer",
            },
        }

    return {"ok": False, "mode": None}


@api_router.get("/team/access-code")
async def get_access_code_admin(authorization: Optional[str] = Header(None)):
    user = await get_current_user(authorization)
    await require_admin(user)
    code = await get_access_code()
    return {"code": code}


@api_router.post("/team/access-code")
async def set_access_code_admin(
    payload: AccessCodeUpdate,
    authorization: Optional[str] = Header(None),
):
    user = await get_current_user(authorization)
    await require_admin(user)
    new_code = (payload.code or "").strip()
    if not new_code:
        raise HTTPException(status_code=400, detail="Codice vuoto")
    await db.settings.update_one(
        {"key": "access_code"},
        {"$set": {"key": "access_code", "value": new_code, "updated_by": user["email"], "updated_at": datetime.now(timezone.utc)}},
        upsert=True,
    )
    return {"ok": True, "code": new_code}


# --------- TEAM MEMBERS (admin only) ----------
@api_router.get("/team/members")
async def list_members(authorization: Optional[str] = Header(None)):
    user = await get_current_user(authorization)
    await require_admin(user)
    cursor = db.members.find({}, {"_id": 0}).sort("created_at", 1)
    items = await cursor.to_list(500)
    for m in items:
        m["created_at"] = m.get("created_at").isoformat() if isinstance(m.get("created_at"), datetime) else m.get("created_at")
    return {"members": items}


@api_router.post("/team/members")
async def add_member(payload: MemberIn, authorization: Optional[str] = Header(None)):
    user = await get_current_user(authorization)
    await require_admin(user)
    email = _norm_email(payload.email)
    if not email or "@" not in email:
        raise HTTPException(status_code=400, detail="Email non valida")
    role = payload.role if payload.role in ("admin", "member") else "member"
    existing = await db.members.find_one({"email": email})
    if existing:
        raise HTTPException(status_code=409, detail="Membro già presente")
    await db.members.insert_one({
        "email": email,
        "role": role,
        "added_by": user["email"],
        "created_at": datetime.now(timezone.utc),
    })
    return {"ok": True, "email": email, "role": role}


@api_router.patch("/team/members/{email}")
async def update_member_role(
    email: str,
    payload: MemberRoleUpdate,
    authorization: Optional[str] = Header(None),
):
    user = await get_current_user(authorization)
    await require_admin(user)
    email_n = _norm_email(email)
    role = payload.role
    if role not in ("admin", "member"):
        raise HTTPException(status_code=400, detail="Ruolo non valido")
    if email_n == _norm_email(user["email"]) and role != "admin":
        raise HTTPException(status_code=400, detail="Non puoi rimuovere il tuo ruolo admin")
    r = await db.members.update_one({"email": email_n}, {"$set": {"role": role}})
    if r.matched_count == 0:
        raise HTTPException(status_code=404, detail="Membro non trovato")
    return {"ok": True, "email": email_n, "role": role}


@api_router.delete("/team/members/{email}")
async def remove_member(email: str, authorization: Optional[str] = Header(None)):
    user = await get_current_user(authorization)
    await require_admin(user)
    email_n = _norm_email(email)
    if email_n == _norm_email(user["email"]):
        raise HTTPException(status_code=400, detail="Non puoi rimuovere te stesso")
    # Also revoke any active sessions of that user
    target = await db.users.find_one({"email": email_n}, {"_id": 0})
    if target:
        await db.user_sessions.delete_many({"user_id": target["user_id"]})
    r = await db.members.delete_one({"email": email_n})
    if r.deleted_count == 0:
        raise HTTPException(status_code=404, detail="Membro non trovato")
    return {"ok": True}


# --------- OPERATORS ----------
def _normalize_pdf_list(doc: dict, kind: str) -> list:
    """Return list of pdf infos for a kind, migrating legacy singular field."""
    plural_field = f"{kind}_pdfs"
    singular_field = f"{kind}_pdf"
    items = doc.get(plural_field)
    if isinstance(items, list):
        out = []
        for it in items:
            if isinstance(it, dict):
                if not it.get("file_id"):
                    it = {**it, "file_id": uuid.uuid4().hex[:12]}
                out.append(it)
        return out
    legacy = doc.get(singular_field)
    if isinstance(legacy, dict):
        if not legacy.get("file_id"):
            legacy = {**legacy, "file_id": uuid.uuid4().hex[:12]}
        return [legacy]
    return []


def _operator_out(doc: dict) -> dict:
    medical_pdfs = _normalize_pdf_list(doc, "medical")
    insurance_pdfs = _normalize_pdf_list(doc, "insurance")
    fitness_pdfs = _normalize_pdf_list(doc, "fitness")
    return {
        "id": doc["id"],
        "owner_id": doc["owner_id"],
        "battle_name": doc.get("battle_name", ""),
        "real_name": doc.get("real_name", ""),
        "phone": doc.get("phone", ""),
        "rank": doc.get("rank", ""),
        "department": doc.get("department", "630 ROCS"),
        "email": doc.get("email", ""),
        "photo": doc.get("photo"),
        "behavioral_notes": doc.get("behavioral_notes", ""),
        "annual_fee_paid": bool(doc.get("annual_fee_paid", False)),
        "annual_fee_amount": float(doc.get("annual_fee_amount", 0) or 0),
        "medical_pdfs": medical_pdfs,
        "insurance_pdfs": insurance_pdfs,
        "fitness_pdfs": fitness_pdfs,
        # Keep legacy single fields for backward compat with old clients
        "medical_pdf": medical_pdfs[0] if medical_pdfs else None,
        "insurance_pdf": insurance_pdfs[0] if insurance_pdfs else None,
        "created_at": doc.get("created_at"),
    }


@api_router.get("/operators")
async def list_operators(authorization: Optional[str] = Header(None)):
    user = await get_current_user(authorization)
    cursor = db.operators.find({}, {"_id": 0}).sort("created_at", 1)
    docs = await cursor.to_list(1000)
    return [_operator_out(d) for d in docs]


@api_router.post("/operators")
async def create_operator(payload: OperatorCreate, authorization: Optional[str] = Header(None)):
    user = await get_current_user(authorization)
    await require_admin(user)
    op_id = f"op_{uuid.uuid4().hex[:12]}"
    doc = {
        "id": op_id,
        "owner_id": user["user_id"],
        "battle_name": payload.battle_name.strip(),
        "real_name": payload.real_name.strip(),
        "phone": payload.phone.strip(),
        "rank": (payload.rank or "").strip(),
        "department": (payload.department or "630 ROCS").strip() or "630 ROCS",
        "email": _norm_email(payload.email or ""),
        "behavioral_notes": "",
        "annual_fee_paid": False,
        "annual_fee_amount": 0.0,
        "medical_pdf": None,
        "insurance_pdf": None,
        "created_at": datetime.now(timezone.utc),
    }
    await db.operators.insert_one(doc)
    return _operator_out(doc)


@api_router.get("/operators/{op_id}")
async def get_operator(op_id: str, authorization: Optional[str] = Header(None)):
    user = await get_current_user(authorization)
    doc = await db.operators.find_one({"id": op_id}, {"_id": 0})
    if not doc:
        raise HTTPException(status_code=404, detail="Not found")
    return _operator_out(doc)


@api_router.patch("/operators/{op_id}")
async def update_operator(op_id: str, payload: OperatorUpdate, authorization: Optional[str] = Header(None)):
    user = await get_current_user(authorization)
    await require_admin(user)
    updates = {k: v for k, v in payload.dict(exclude_unset=True).items() if v is not None}
    if "email" in updates:
        updates["email"] = _norm_email(updates["email"])
    if not updates:
        doc = await db.operators.find_one({"id": op_id}, {"_id": 0})
        if not doc:
            raise HTTPException(status_code=404, detail="Not found")
        return _operator_out(doc)
    r = await db.operators.update_one(
        {"id": op_id}, {"$set": updates}
    )
    if r.matched_count == 0:
        raise HTTPException(status_code=404, detail="Not found")
    doc = await db.operators.find_one({"id": op_id}, {"_id": 0})
    return _operator_out(doc)


@api_router.delete("/operators/{op_id}")
async def delete_operator(op_id: str, authorization: Optional[str] = Header(None)):
    user = await get_current_user(authorization)
    await require_admin(user)
    r = await db.operators.delete_one({"id": op_id})
    if r.deleted_count == 0:
        raise HTTPException(status_code=404, detail="Not found")
    await db.attendance.delete_many({"operator_id": op_id})
    await db.payments.delete_many({"operator_id": op_id})
    return {"ok": True}


# --------- PDF UPLOAD ----------
@api_router.post("/operators/{op_id}/upload")
async def upload_pdf(
    op_id: str,
    kind: str = Form(...),  # "medical" | "insurance" | "fitness"
    file: UploadFile = File(...),
    authorization: Optional[str] = Header(None),
):
    user = await get_current_user(authorization)
    await require_admin(user)
    if kind not in ("medical", "insurance", "fitness"):
        raise HTTPException(status_code=400, detail="Invalid kind")
    op = await db.operators.find_one({"id": op_id}, {"_id": 0})
    if not op:
        raise HTTPException(status_code=404, detail="Operator not found")

    content = await file.read()
    original_name = file.filename or "file"
    ext = original_name.rsplit(".", 1)[-1].lower() if "." in original_name else "bin"
    ext = "".join(c for c in ext if c.isalnum()) or "bin"
    path = f"{APP_NAME}/uploads/{user['user_id']}/{uuid.uuid4().hex}.{ext}"
    ct = file.content_type or "application/octet-stream"
    try:
        await run_in_threadpool(put_object, path, content, ct)
    except requests.HTTPError as e:
        status = e.response.status_code if e.response is not None else 500
        raise HTTPException(status_code=status, detail=f"Storage error: {status}")

    file_info = {
        "file_id": uuid.uuid4().hex[:12],
        "path": path,
        "filename": original_name,
        "content_type": ct,
        "size": len(content),
        "uploaded_at": datetime.now(timezone.utc).isoformat(),
    }
    plural = f"{kind}_pdfs"
    singular = f"{kind}_pdf"
    current = _normalize_pdf_list(op, kind)
    current.append(file_info)
    update_doc = {plural: current}
    if kind in ("medical", "insurance"):
        update_doc[singular] = current[0]
    await db.operators.update_one({"id": op_id}, {"$set": update_doc})
    return file_info


@api_router.delete("/operators/{op_id}/upload")
async def delete_pdf(
    op_id: str,
    kind: str,
    file_id: Optional[str] = None,
    authorization: Optional[str] = Header(None),
):
    user = await get_current_user(authorization)
    await require_admin(user)
    if kind not in ("medical", "insurance", "fitness"):
        raise HTTPException(status_code=400, detail="Invalid kind")
    op = await db.operators.find_one({"id": op_id}, {"_id": 0})
    if not op:
        raise HTTPException(status_code=404, detail="Operator not found")
    plural = f"{kind}_pdfs"
    singular = f"{kind}_pdf"
    current = _normalize_pdf_list(op, kind)
    if file_id:
        current = [f for f in current if f.get("file_id") != file_id]
    else:
        current = []
    update_doc = {plural: current}
    if kind in ("medical", "insurance"):
        update_doc[singular] = current[0] if current else None
    await db.operators.update_one({"id": op_id}, {"$set": update_doc})
    return {"ok": True, "remaining": len(current)}


# --------- OPERATOR PHOTO UPLOAD ----------
@api_router.post("/operators/{op_id}/photo")
async def upload_photo(
    op_id: str,
    file: UploadFile = File(...),
    authorization: Optional[str] = Header(None),
):
    user = await get_current_user(authorization)
    await require_admin(user)
    op = await db.operators.find_one({"id": op_id}, {"_id": 0})
    if not op:
        raise HTTPException(status_code=404, detail="Operator not found")
    content = await file.read()
    ct = file.content_type or "image/jpeg"
    ext = (file.filename or "photo.jpg").split(".")[-1].lower() or "jpg"
    if ext not in ("jpg", "jpeg", "png", "webp"):
        ext = "jpg"
    path = f"{APP_NAME}/photos/{op_id}/{uuid.uuid4().hex}.{ext}"
    try:
        await run_in_threadpool(put_object, path, content, ct)
    except requests.HTTPError as e:
        status = e.response.status_code if e.response is not None else 500
        raise HTTPException(status_code=status, detail=f"Storage error: {status}")
    photo = {
        "path": path,
        "content_type": ct,
        "size": len(content),
        "uploaded_at": datetime.now(timezone.utc).isoformat(),
    }
    await db.operators.update_one({"id": op_id}, {"$set": {"photo": photo}})
    return photo


@api_router.get("/operators/{op_id}/photo")
async def download_photo(
    op_id: str,
    token: Optional[str] = None,
    authorization: Optional[str] = Header(None),
):
    auth_header = authorization
    if not auth_header and token:
        auth_header = f"Bearer {token}"
    user = await get_current_user(auth_header)
    op = await db.operators.find_one({"id": op_id}, {"_id": 0})
    if not op:
        raise HTTPException(status_code=404, detail="Not found")
    info = op.get("photo")
    if not info:
        raise HTTPException(status_code=404, detail="No photo")
    try:
        data, _ct = await run_in_threadpool(get_object, info["path"])
    except requests.HTTPError as e:
        status = e.response.status_code if e.response is not None else 500
        raise HTTPException(status_code=status, detail=f"Storage error: {status}")
    return Response(content=data, media_type=info.get("content_type", "image/jpeg"))


@api_router.get("/files/{op_id}/{kind}")
async def download_pdf(
    op_id: str,
    kind: str,
    file_id: Optional[str] = None,
    token: Optional[str] = None,
    authorization: Optional[str] = Header(None),
):
    # Support token via query string for web <img>/window.open
    auth_header = authorization
    if not auth_header and token:
        auth_header = f"Bearer {token}"
    user = await get_current_user(auth_header)
    role = user.get("role")
    # This endpoint returns the ORIGINAL file bytes (used by admins to download for maintenance).
    # Editors are explicitly blocked here — they must use /info + /page/{idx} to view.
    if role != "admin":
        raise HTTPException(status_code=403, detail="Download riservato agli admin")
    op = await db.operators.find_one({"id": op_id}, {"_id": 0})
    if not op:
        raise HTTPException(status_code=404, detail="Not found")
    items = _normalize_pdf_list(op, kind)
    if not items:
        raise HTTPException(status_code=404, detail="No file")
    info = None
    if file_id:
        for it in items:
            if it.get("file_id") == file_id:
                info = it
                break
        if not info:
            raise HTTPException(status_code=404, detail="File not found")
    else:
        info = items[0]
    try:
        data, ct = await run_in_threadpool(get_object, info["path"])
    except requests.HTTPError:
        raise HTTPException(status_code=500, detail="Storage read failed")
    return Response(
        content=data,
        media_type=ct,
        headers={"Content-Disposition": f'inline; filename="{info["filename"]}"'},
    )


def _rasterize_pdf_page(pdf_bytes: bytes, page_index: int, zoom: float = 2.0) -> bytes:
    """Render a single PDF page as PNG bytes."""
    import fitz  # pymupdf
    doc = fitz.open(stream=pdf_bytes, filetype="pdf")
    try:
        if page_index < 0 or page_index >= doc.page_count:
            raise HTTPException(status_code=404, detail="Pagina non trovata")
        page = doc.load_page(page_index)
        mat = fitz.Matrix(zoom, zoom)
        pix = page.get_pixmap(matrix=mat, alpha=False)
        return pix.tobytes("png")
    finally:
        doc.close()


def _pdf_page_count(pdf_bytes: bytes) -> int:
    import fitz
    doc = fitz.open(stream=pdf_bytes, filetype="pdf")
    try:
        return int(doc.page_count)
    finally:
        doc.close()


async def _authorize_file(op_id: str, kind: str, file_id: Optional[str], auth_header: Optional[str]):
    """Shared auth check for file endpoints.
    - fitness: PUBLIC (no auth required) - everyone can view Prova Fisica
    - medical / insurance: admin or editor only
    - Raw-bytes download endpoint `/files/{op_id}/{kind}` remains admin-only elsewhere.
    """
    if kind != "fitness":
        user = await get_current_user(auth_header)
        role = user.get("role")
        if role not in ("admin", "editor"):
            raise HTTPException(status_code=403, detail="Permesso insufficiente")
    op = await db.operators.find_one({"id": op_id}, {"_id": 0})
    if not op:
        raise HTTPException(status_code=404, detail="Not found")
    items = _normalize_pdf_list(op, kind)
    if not items:
        raise HTTPException(status_code=404, detail="No file")
    info = None
    if file_id:
        for it in items:
            if it.get("file_id") == file_id:
                info = it
                break
        if not info:
            raise HTTPException(status_code=404, detail="File not found")
    else:
        info = items[0]
    return info


@api_router.get("/files/{op_id}/{kind}/info")
async def file_info(
    op_id: str,
    kind: str,
    file_id: Optional[str] = None,
    token: Optional[str] = None,
    authorization: Optional[str] = Header(None),
):
    """Returns metadata (content_type, pages) for the file without exposing bytes.
    For PDFs, computes page count by streaming the file once."""
    auth_header = authorization or (f"Bearer {token}" if token else None)
    info = await _authorize_file(op_id, kind, file_id, auth_header)
    content_type = (info.get("content_type") or "").lower()
    pages = 1
    is_pdf = content_type == "application/pdf" or (info.get("filename") or "").lower().endswith(".pdf")
    if is_pdf:
        try:
            data, _ = await run_in_threadpool(get_object, info["path"])
            pages = await run_in_threadpool(_pdf_page_count, data)
        except Exception as e:
            logger.warning(f"pdf page count failed: {e}")
            pages = 1
    return {
        "file_id": info.get("file_id"),
        "filename": info.get("filename"),
        "content_type": content_type or "application/octet-stream",
        "is_pdf": is_pdf,
        "pages": pages,
    }


@api_router.get("/files/{op_id}/{kind}/page/{page_index}")
async def file_page(
    op_id: str,
    kind: str,
    page_index: int,
    file_id: Optional[str] = None,
    token: Optional[str] = None,
    authorization: Optional[str] = Header(None),
):
    """Returns a single rasterized page of the PDF as PNG. Non-images are returned as-is."""
    auth_header = authorization or (f"Bearer {token}" if token else None)
    info = await _authorize_file(op_id, kind, file_id, auth_header)
    try:
        data, ct = await run_in_threadpool(get_object, info["path"])
    except Exception:
        raise HTTPException(status_code=500, detail="Storage read failed")
    content_type = (info.get("content_type") or ct or "").lower()
    is_pdf = content_type == "application/pdf" or (info.get("filename") or "").lower().endswith(".pdf")
    if not is_pdf:
        # For images, return as inline; page_index ignored
        return Response(
            content=data,
            media_type=content_type or "application/octet-stream",
            headers={"Cache-Control": "private, max-age=60"},
        )
    try:
        png = await run_in_threadpool(_rasterize_pdf_page, data, int(page_index), 1.8)
    except HTTPException:
        raise
    except Exception as e:
        logger.warning(f"rasterize failed: {e}")
        raise HTTPException(status_code=500, detail="Rendering fallito")
    return Response(
        content=png,
        media_type="image/png",
        headers={"Cache-Control": "private, max-age=60"},
    )


# --------- ATTENDANCE ----------
@api_router.get("/operators/{op_id}/attendance")
async def get_attendance(op_id: str, authorization: Optional[str] = Header(None)):
    user = await get_current_user(authorization)
    op = await db.operators.find_one({"id": op_id}, {"_id": 0})
    if not op:
        raise HTTPException(status_code=404, detail="Not found")
    cursor = db.attendance.find(
        {"operator_id": op_id}, {"_id": 0}
    )
    records = await cursor.to_list(2000)
    out = []
    for r in records:
        status = r.get("status")
        if not status:
            status = "present" if r.get("present") else "absent"
        out.append({
            "date": r["date"],
            "present": bool(r.get("present")),
            "status": status,
        })
    return {"records": out}


@api_router.post("/operators/{op_id}/attendance")
async def toggle_attendance(
    op_id: str,
    payload: AttendanceToggle,
    authorization: Optional[str] = Header(None),
):
    user = await get_current_user(authorization)
    await require_admin(user)
    op = await db.operators.find_one({"id": op_id}, {"_id": 0})
    if not op:
        raise HTTPException(status_code=404, detail="Not found")
    status = (payload.status or "").strip().lower()
    if status not in ("present", "rest", "absent"):
        status = "present" if payload.present else "absent"
    # 'absent' = delete the record so the UI goes back to default state
    if status == "absent":
        await db.attendance.delete_one({"operator_id": op_id, "date": payload.date})
        return {"date": payload.date, "present": False, "status": "absent"}
    is_present = status == "present"
    await db.attendance.update_one(
        {"operator_id": op_id, "date": payload.date},
        {"$set": {
            "operator_id": op_id,
            "owner_id": user["user_id"],
            "date": payload.date,
            "present": is_present,
            "status": status,
            "updated_at": datetime.now(timezone.utc),
        }},
        upsert=True,
    )
    return {"date": payload.date, "present": is_present, "status": status}


@api_router.delete("/operators/{op_id}/attendance/{date}")
async def clear_attendance(
    op_id: str,
    date: str,
    authorization: Optional[str] = Header(None),
):
    user = await get_current_user(authorization)
    await require_admin(user)
    op = await db.operators.find_one({"id": op_id}, {"_id": 0})
    if not op:
        raise HTTPException(status_code=404, detail="Not found")
    await db.attendance.delete_one({"operator_id": op_id, "date": date})
    return {"date": date, "status": "absent", "present": False}


@api_router.get("/operators/{op_id}/payments")
async def get_payments(op_id: str, authorization: Optional[str] = Header(None)):
    user = await get_current_user(authorization)
    op = await db.operators.find_one({"id": op_id}, {"_id": 0})
    if not op:
        raise HTTPException(status_code=404, detail="Not found")
    cursor = db.payments.find(
        {"operator_id": op_id}, {"_id": 0}
    )
    records = await cursor.to_list(500)
    return {"records": [{"month": r["month"], "paid": r["paid"]} for r in records]}


@api_router.post("/operators/{op_id}/payments")
async def toggle_payment(
    op_id: str,
    payload: PaymentToggle,
    authorization: Optional[str] = Header(None),
):
    user = await get_current_user(authorization)
    await require_admin(user)
    op = await db.operators.find_one({"id": op_id}, {"_id": 0})
    if not op:
        raise HTTPException(status_code=404, detail="Not found")
    await db.payments.update_one(
        {"operator_id": op_id, "month": payload.month},
        {"$set": {
            "operator_id": op_id,
            "owner_id": user["user_id"],
            "month": payload.month,
            "paid": payload.paid,
            "updated_at": datetime.now(timezone.utc),
        }},
        upsert=True,
    )
    return {"month": payload.month, "paid": payload.paid}


@api_router.post("/operators/{op_id}/promote")
async def promote_operator(op_id: str, authorization: Optional[str] = Header(None)):
    user = await get_current_user(authorization)
    await require_admin(user)
    op = await db.operators.find_one({"id": op_id}, {"_id": 0})
    if not op:
        raise HTTPException(status_code=404, detail="Not found")
    email = _norm_email(op.get("email") or "")
    if not email or "@" not in email:
        raise HTTPException(status_code=400, detail="L'operatore non ha un'email Google valida")
    existing = await db.members.find_one({"email": email}, {"_id": 0})
    if existing:
        await db.members.update_one({"email": email}, {"$set": {"role": "admin"}})
    else:
        await db.members.insert_one({
            "email": email,
            "role": "admin",
            "added_by": user["email"],
            "created_at": datetime.now(timezone.utc),
        })
    return {"ok": True, "email": email, "role": "admin"}


@api_router.post("/operators/{op_id}/demote")
async def demote_operator(op_id: str, authorization: Optional[str] = Header(None)):
    user = await get_current_user(authorization)
    await require_admin(user)
    op = await db.operators.find_one({"id": op_id}, {"_id": 0})
    if not op:
        raise HTTPException(status_code=404, detail="Not found")
    email = _norm_email(op.get("email") or "")
    if not email:
        raise HTTPException(status_code=400, detail="Nessuna email associata")
    if email == _norm_email(user["email"]):
        raise HTTPException(status_code=400, detail="Non puoi rimuovere il tuo ruolo admin")
    r = await db.members.update_one({"email": email}, {"$set": {"role": "member"}})
    if r.matched_count == 0:
        raise HTTPException(status_code=404, detail="Membro non trovato")
    return {"ok": True, "email": email, "role": "member"}


@api_router.get("/operators/{op_id}/role-info")
async def operator_role_info(op_id: str, authorization: Optional[str] = Header(None)):
    user = await get_current_user(authorization)
    op = await db.operators.find_one({"id": op_id}, {"_id": 0})
    if not op:
        raise HTTPException(status_code=404, detail="Not found")
    email = _norm_email(op.get("email") or "")
    if not email:
        return {"email": "", "has_account": False, "role": None}
    member = await db.members.find_one({"email": email}, {"_id": 0})
    return {
        "email": email,
        "has_account": member is not None,
        "role": member["role"] if member else None,
    }


class EventIn(BaseModel):
    date: str  # YYYY-MM-DD
    title: str
    location: str = ""
    meetup_time: str = ""
    start_time: str = ""


class EventUpdate(BaseModel):
    title: Optional[str] = None
    location: Optional[str] = None
    meetup_time: Optional[str] = None
    start_time: Optional[str] = None


@api_router.get("/health")
async def health():
    return {"ok": True}


app.add_middleware(
    CORSMiddleware,
    allow_credentials=True,
    allow_origins=["*"],
    allow_methods=["*"],
    allow_headers=["*"],
)

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)


def _event_out(e: dict) -> dict:
    return {
        "id": e["id"],
        "date": e["date"],
        "title": e.get("title", ""),
        "location": e.get("location", ""),
        "meetup_time": e.get("meetup_time", ""),
        "start_time": e.get("start_time", ""),
        "attachments": e.get("attachments", []) or [],
    }


# --------- SQUAD EVENTS (shared calendar) ----------
@api_router.get("/events")
async def list_events(authorization: Optional[str] = Header(None)):
    user = await get_current_user(authorization)
    cursor = db.events.find({}, {"_id": 0}).sort("date", 1)
    items = await cursor.to_list(2000)
    return {"events": [_event_out(e) for e in items]}


@api_router.post("/events")
async def create_event(payload: EventIn, authorization: Optional[str] = Header(None)):
    user = await get_current_user(authorization)
    await require_admin(user)
    if not payload.date or not payload.title.strip():
        raise HTTPException(status_code=400, detail="Dati evento non validi")
    ev_id = f"ev_{uuid.uuid4().hex[:12]}"
    doc = {
        "id": ev_id,
        "date": payload.date,
        "title": payload.title.strip(),
        "location": (payload.location or "").strip(),
        "meetup_time": (payload.meetup_time or "").strip(),
        "start_time": (payload.start_time or "").strip(),
        "attachments": [],
        "created_by": user["email"],
        "created_at": datetime.now(timezone.utc),
    }
    await db.events.insert_one(doc)
    await db.notifications.insert_one({
        "id": f"nt_{uuid.uuid4().hex[:12]}",
        "type": "event",
        "event_id": ev_id,
        "title": doc["title"],
        "date": doc["date"],
        "created_at": datetime.now(timezone.utc),
    })
    return _event_out(doc)


@api_router.patch("/events/{ev_id}")
async def update_event(ev_id: str, payload: EventUpdate, authorization: Optional[str] = Header(None)):
    user = await get_current_user(authorization)
    await require_admin(user)
    updates = {k: v.strip() if isinstance(v, str) else v
               for k, v in payload.dict(exclude_unset=True).items() if v is not None}
    if not updates:
        doc = await db.events.find_one({"id": ev_id}, {"_id": 0})
        if not doc:
            raise HTTPException(status_code=404, detail="Non trovato")
        return _event_out(doc)
    r = await db.events.update_one({"id": ev_id}, {"$set": updates})
    if r.matched_count == 0:
        raise HTTPException(status_code=404, detail="Non trovato")
    doc = await db.events.find_one({"id": ev_id}, {"_id": 0})
    return _event_out(doc)


@api_router.delete("/events/{ev_id}")
async def delete_event(ev_id: str, authorization: Optional[str] = Header(None)):
    user = await get_current_user(authorization)
    await require_admin(user)
    r = await db.events.delete_one({"id": ev_id})
    if r.deleted_count == 0:
        raise HTTPException(status_code=404, detail="Non trovato")
    return {"ok": True}


@api_router.post("/events/{ev_id}/attachments")
async def event_attach(
    ev_id: str,
    file: UploadFile = File(...),
    authorization: Optional[str] = Header(None),
):
    user = await get_current_user(authorization)
    await require_admin(user)
    ev = await db.events.find_one({"id": ev_id}, {"_id": 0})
    if not ev:
        raise HTTPException(status_code=404, detail="Evento non trovato")
    content = await file.read()
    original_name = file.filename or "file"
    ext = original_name.rsplit(".", 1)[-1].lower() if "." in original_name else "bin"
    ext = "".join(c for c in ext if c.isalnum()) or "bin"
    path = f"{APP_NAME}/events/{ev_id}/{uuid.uuid4().hex}.{ext}"
    ct = file.content_type or "application/octet-stream"
    try:
        await run_in_threadpool(put_object, path, content, ct)
    except requests.HTTPError as e:
        status = e.response.status_code if e.response is not None else 500
        raise HTTPException(status_code=status, detail=f"Storage error: {status}")
    info = {
        "file_id": uuid.uuid4().hex[:12],
        "path": path,
        "filename": original_name,
        "content_type": ct,
        "size": len(content),
        "uploaded_at": datetime.now(timezone.utc).isoformat(),
    }
    atts = list(ev.get("attachments") or [])
    atts.append(info)
    await db.events.update_one({"id": ev_id}, {"$set": {"attachments": atts}})
    return info


@api_router.delete("/events/{ev_id}/attachments/{file_id}")
async def event_detach(ev_id: str, file_id: str, authorization: Optional[str] = Header(None)):
    user = await get_current_user(authorization)
    await require_admin(user)
    ev = await db.events.find_one({"id": ev_id}, {"_id": 0})
    if not ev:
        raise HTTPException(status_code=404, detail="Evento non trovato")
    atts = [a for a in (ev.get("attachments") or []) if a.get("file_id") != file_id]
    await db.events.update_one({"id": ev_id}, {"$set": {"attachments": atts}})
    return {"ok": True, "remaining": len(atts)}


@api_router.get("/event-files/{ev_id}/{file_id}")
async def event_file(
    ev_id: str,
    file_id: str,
    token: Optional[str] = None,
    authorization: Optional[str] = Header(None),
):
    auth_header = authorization
    if not auth_header and token:
        auth_header = f"Bearer {token}"
    await get_current_user(auth_header)
    ev = await db.events.find_one({"id": ev_id}, {"_id": 0})
    if not ev:
        raise HTTPException(status_code=404, detail="Non trovato")
    info = None
    for a in ev.get("attachments") or []:
        if a.get("file_id") == file_id:
            info = a
            break
    if not info:
        raise HTTPException(status_code=404, detail="File non trovato")
    try:
        data, ct = await run_in_threadpool(get_object, info["path"])
    except requests.HTTPError:
        raise HTTPException(status_code=500, detail="Storage read failed")
    return Response(
        content=data,
        media_type=ct,
        headers={"Content-Disposition": f'inline; filename="{info["filename"]}"'},
    )


# --------- ANALYTICS (admin only) ----------
HEARTBEAT_TIMEOUT_SECONDS = 180  # if no heartbeat in this window, finalize session
MAX_SESSION_SECONDS = 60 * 60 * 12  # safety cap: 12h


@api_router.post("/analytics/session/start")
async def analytics_session_start(authorization: Optional[str] = Header(None)):
    user = await get_current_user(authorization)
    now = datetime.now(timezone.utc)
    log_id = f"log_{uuid.uuid4().hex[:12]}"
    await db.access_logs.insert_one({
        "log_id": log_id,
        "user_id": user["user_id"],
        "user_email": _norm_email(user.get("email", "")),
        "user_name": user.get("name", ""),
        "user_picture": user.get("picture"),
        "started_at": now,
        "last_heartbeat": now,
        "ended_at": None,
        "duration_seconds": 0,
    })
    return {"log_id": log_id}


@api_router.post("/analytics/session/heartbeat")
async def analytics_session_heartbeat(
    payload: SessionLogIn, authorization: Optional[str] = Header(None),
):
    user = await get_current_user(authorization)
    now = datetime.now(timezone.utc)
    log = None
    if payload.log_id:
        log = await db.access_logs.find_one({"log_id": payload.log_id})
    if not log:
        # Create new log if client lost its id
        log_id = f"log_{uuid.uuid4().hex[:12]}"
        await db.access_logs.insert_one({
            "log_id": log_id,
            "user_id": user["user_id"],
            "user_email": _norm_email(user.get("email", "")),
            "user_name": user.get("name", ""),
            "user_picture": user.get("picture"),
            "started_at": now,
            "last_heartbeat": now,
            "ended_at": None,
            "duration_seconds": 0,
        })
        return {"log_id": log_id}
    started = log.get("started_at")
    if isinstance(started, datetime):
        if started.tzinfo is None:
            started = started.replace(tzinfo=timezone.utc)
        duration = int((now - started).total_seconds())
    else:
        duration = int(log.get("duration_seconds", 0))
    duration = max(0, min(duration, MAX_SESSION_SECONDS))
    await db.access_logs.update_one(
        {"log_id": payload.log_id},
        {"$set": {"last_heartbeat": now, "duration_seconds": duration}},
    )
    return {"log_id": payload.log_id, "duration_seconds": duration}


@api_router.post("/analytics/session/end")
async def analytics_session_end(
    payload: SessionLogIn, authorization: Optional[str] = Header(None),
):
    await get_current_user(authorization)
    if not payload.log_id:
        return {"ok": True}
    log = await db.access_logs.find_one({"log_id": payload.log_id})
    if not log:
        return {"ok": True}
    now = datetime.now(timezone.utc)
    started = log.get("started_at")
    if isinstance(started, datetime):
        if started.tzinfo is None:
            started = started.replace(tzinfo=timezone.utc)
        duration = int((now - started).total_seconds())
    else:
        duration = int(log.get("duration_seconds", 0))
    duration = max(0, min(duration, MAX_SESSION_SECONDS))
    await db.access_logs.update_one(
        {"log_id": payload.log_id},
        {"$set": {"ended_at": now, "last_heartbeat": now, "duration_seconds": duration}},
    )
    return {"ok": True, "duration_seconds": duration}


async def _finalize_stale_sessions():
    """Close sessions whose last heartbeat is older than HEARTBEAT_TIMEOUT_SECONDS."""
    cutoff = datetime.now(timezone.utc) - timedelta(seconds=HEARTBEAT_TIMEOUT_SECONDS)
    cursor = db.access_logs.find({"ended_at": None, "last_heartbeat": {"$lt": cutoff}})
    async for log in cursor:
        started = log.get("started_at")
        last_hb = log.get("last_heartbeat")
        if isinstance(started, datetime) and isinstance(last_hb, datetime):
            if started.tzinfo is None:
                started = started.replace(tzinfo=timezone.utc)
            if last_hb.tzinfo is None:
                last_hb = last_hb.replace(tzinfo=timezone.utc)
            duration = int((last_hb - started).total_seconds())
        else:
            duration = int(log.get("duration_seconds", 0))
        duration = max(0, min(duration, MAX_SESSION_SECONDS))
        await db.access_logs.update_one(
            {"log_id": log["log_id"]},
            {"$set": {"ended_at": last_hb or started, "duration_seconds": duration}},
        )


@api_router.get("/analytics/stats")
async def analytics_stats(
    authorization: Optional[str] = Header(None),
    date_from: Optional[str] = Query(None, alias="from", description="ISO date YYYY-MM-DD"),
    date_to: Optional[str] = Query(None, alias="to", description="ISO date YYYY-MM-DD"),
):
    """Contaore semplice: persone, accessi, giorno e ora di punta (ora italiana).
    Gli accessi del creatore (OWNER_EMAIL) sono sempre esclusi."""
    user = await get_current_user(authorization)
    await require_admin(user)
    excluded = _norm_email(OWNER_EMAIL)
    owner_ids = [u["user_id"] async for u in db.users.find({"email": excluded}, {"_id": 0, "user_id": 1})]
    match: dict = {"user_email": {"$ne": excluded}, "user_id": {"$nin": owner_ids}}
    try:
        rng: dict = {}
        if date_from:
            rng["$gte"] = datetime.strptime(date_from, "%Y-%m-%d").replace(tzinfo=timezone.utc)
        if date_to:
            rng["$lt"] = datetime.strptime(date_to, "%Y-%m-%d").replace(tzinfo=timezone.utc) + timedelta(days=1)
        if rng:
            match["started_at"] = rng
    except ValueError:
        raise HTTPException(status_code=400, detail="Formato data non valido (YYYY-MM-DD)")

    tz = "Europe/Rome"
    total_accesses = await db.access_logs.count_documents(match)
    people = await db.access_logs.distinct("user_email", match)

    async def _group(expr) -> list:
        rows = db.access_logs.aggregate([
            {"$match": match},
            {"$group": {"_id": expr, "count": {"$sum": 1}}},
            {"$sort": {"count": -1}},
        ])
        return [r async for r in rows]

    weekdays_it = ["", "Domenica", "Lunedì", "Martedì", "Mercoledì", "Giovedì", "Venerdì", "Sabato"]
    by_weekday = await _group({"$dayOfWeek": {"date": "$started_at", "timezone": tz}})
    by_hour = await _group({"$hour": {"date": "$started_at", "timezone": tz}})
    by_date = await _group({"$dateToString": {"format": "%Y-%m-%d", "date": "$started_at", "timezone": tz}})

    return {
        "excluded_email": excluded,
        "unique_people": len(people),
        "total_accesses": total_accesses,
        "peak_weekdays": [{"label": weekdays_it[int(r["_id"])], "count": r["count"]} for r in by_weekday[:3]],
        "peak_hours": [{"label": f"{int(r['_id']):02d}:00", "count": r["count"]} for r in by_hour[:3]],
        "peak_dates": [{"label": r["_id"], "count": r["count"]} for r in by_date[:3]],
    }


@api_router.get("/analytics/export.csv")
async def analytics_export_csv(
    authorization: Optional[str] = Header(None),
    date_from: Optional[str] = Query(None, alias="from"),
    date_to: Optional[str] = Query(None, alias="to"),
):
    user = await get_current_user(authorization)
    await require_admin(user)
    try:
        await _finalize_stale_sessions()
    except Exception as e:
        logger.warning(f"finalize stale failed: {e}")

    excluded = _norm_email(OWNER_EMAIL)
    excluded_list = [excluded, _norm_email(GUEST_EDITOR_EMAIL), _norm_email(GATE_VIEWER_EMAIL)]
    range_from: Optional[datetime] = None
    range_to: Optional[datetime] = None
    try:
        if date_from:
            range_from = datetime.strptime(date_from, "%Y-%m-%d").replace(tzinfo=timezone.utc)
        if date_to:
            range_to = datetime.strptime(date_to, "%Y-%m-%d").replace(tzinfo=timezone.utc) \
                + timedelta(days=1) - timedelta(milliseconds=1)
    except ValueError:
        raise HTTPException(status_code=400, detail="Invalid date format (use YYYY-MM-DD)")

    match: dict = {"user_email": {"$nin": excluded_list}}
    if range_from or range_to:
        rng: dict = {}
        if range_from:
            rng["$gte"] = range_from
        if range_to:
            rng["$lte"] = range_to
        match["started_at"] = rng

    pipeline = [
        {"$match": match},
        {
            "$group": {
                "_id": "$user_email",
                "name": {"$last": "$user_name"},
                "access_count": {"$sum": 1},
                "last_access": {"$max": "$last_heartbeat"},
                "total_seconds": {"$sum": "$duration_seconds"},
            },
        },
        {"$sort": {"access_count": -1, "total_seconds": -1}},
    ]

    def fmt_duration(sec: int) -> str:
        sec = max(0, int(sec))
        h = sec // 3600
        m = (sec % 3600) // 60
        s = sec % 60
        return f"{h:02d}:{m:02d}:{s:02d}"

    lines = ["Email,Nome,Accessi,Tempo totale (hh:mm:ss),Durata media (hh:mm:ss),Ultimo accesso (UTC),Giorni da ultimo accesso,Stato"]
    now = datetime.now(timezone.utc)
    async for row in db.access_logs.aggregate(pipeline):
        access = int(row.get("access_count") or 0)
        total = int(row.get("total_seconds") or 0)
        avg = int(total / access) if access > 0 else 0
        last = row.get("last_access")
        last_iso = ""
        days_since = ""
        status = "ATTIVO"
        if isinstance(last, datetime):
            if last.tzinfo is None:
                last = last.replace(tzinfo=timezone.utc)
            last_iso = last.strftime("%Y-%m-%d %H:%M:%S")
            d = int((now - last).total_seconds() // 86400)
            days_since = str(d)
            if d > 30:
                status = "INATTIVO"
        else:
            status = "INATTIVO"

        def esc(v: str) -> str:
            v = (v or "").replace('"', '""')
            if "," in v or "\n" in v or '"' in v:
                return f'"{v}"'
            return v

        lines.append(",".join([
            esc(row.get("_id") or ""),
            esc(row.get("name") or ""),
            str(access),
            fmt_duration(total),
            fmt_duration(avg),
            esc(last_iso),
            days_since,
            status,
        ]))

    csv_body = "\ufeff" + "\n".join(lines)  # BOM for Excel UTF-8 compat
    today = datetime.now(timezone.utc).strftime("%Y%m%d")
    filename_range = ""
    if date_from or date_to:
        filename_range = f"_{date_from or 'inizio'}_{date_to or today}"
    filename = f"furiani_analytics_{today}{filename_range}.csv"
    return Response(
        content=csv_body.encode("utf-8"),
        media_type="text/csv; charset=utf-8",
        headers={"Content-Disposition": f'attachment; filename="{filename}"'},
    )


def _month_bounds(year: int, month: int) -> tuple:
    """Return (start, end) datetime bounds (UTC) for a given month."""
    start = datetime(year, month, 1, tzinfo=timezone.utc)
    if month == 12:
        end = datetime(year + 1, 1, 1, tzinfo=timezone.utc) - timedelta(milliseconds=1)
    else:
        end = datetime(year, month + 1, 1, tzinfo=timezone.utc) - timedelta(milliseconds=1)
    return start, end


MONTH_LABELS_IT = [
    "Gennaio", "Febbraio", "Marzo", "Aprile", "Maggio", "Giugno",
    "Luglio", "Agosto", "Settembre", "Ottobre", "Novembre", "Dicembre",
]


async def _aggregate_window(start: datetime, end: datetime, excluded: str) -> dict:
    excluded_list = [excluded, _norm_email(GUEST_EDITOR_EMAIL), _norm_email(GATE_VIEWER_EMAIL)]
    pipeline = [
        {
            "$match": {
                "user_email": {"$nin": excluded_list},
                "started_at": {"$gte": start, "$lte": end},
            },
        },
        {
            "$group": {
                "_id": None,
                "total_accesses": {"$sum": 1},
                "total_seconds": {"$sum": "$duration_seconds"},
                "unique_users": {"$addToSet": "$user_email"},
            },
        },
    ]
    async for row in db.access_logs.aggregate(pipeline):
        return {
            "total_accesses": int(row.get("total_accesses") or 0),
            "total_seconds": int(row.get("total_seconds") or 0),
            "unique_users": len(row.get("unique_users") or []),
        }
    return {"total_accesses": 0, "total_seconds": 0, "unique_users": 0}


def _pct_delta(current: int, previous: int) -> Optional[float]:
    if previous == 0:
        if current == 0:
            return 0.0
        return None  # infinite growth from zero
    return round(((current - previous) / previous) * 100.0, 1)


@api_router.get("/analytics/compare")
async def analytics_compare(
    authorization: Optional[str] = Header(None),
    month: Optional[str] = Query(None, description="YYYY-MM (defaults to current month UTC)"),
):
    user = await get_current_user(authorization)
    await require_admin(user)
    try:
        await _finalize_stale_sessions()
    except Exception as e:
        logger.warning(f"finalize stale failed: {e}")

    excluded = _norm_email(OWNER_EMAIL)
    excluded_list = [excluded, _norm_email(GUEST_EDITOR_EMAIL), _norm_email(GATE_VIEWER_EMAIL)]
    now = datetime.now(timezone.utc)
    try:
        if month:
            year, mon = [int(x) for x in month.split("-", 1)]
            if not (1 <= mon <= 12):
                raise ValueError
        else:
            year, mon = now.year, now.month
    except Exception:
        raise HTTPException(status_code=400, detail="Invalid month (use YYYY-MM)")

    cur_start, cur_end = _month_bounds(year, mon)
    prev_year = year if mon > 1 else year - 1
    prev_mon = mon - 1 if mon > 1 else 12
    prev_start, prev_end = _month_bounds(prev_year, prev_mon)

    current = await _aggregate_window(cur_start, cur_end, excluded)
    previous = await _aggregate_window(prev_start, prev_end, excluded)

    return {
        "current": {
            "year": year,
            "month": mon,
            "label": f"{MONTH_LABELS_IT[mon - 1]} {year}",
            "from": cur_start.strftime("%Y-%m-%d"),
            "to": cur_end.strftime("%Y-%m-%d"),
            **current,
        },
        "previous": {
            "year": prev_year,
            "month": prev_mon,
            "label": f"{MONTH_LABELS_IT[prev_mon - 1]} {prev_year}",
            "from": prev_start.strftime("%Y-%m-%d"),
            "to": prev_end.strftime("%Y-%m-%d"),
            **previous,
        },
        "delta_pct": {
            "accesses": _pct_delta(current["total_accesses"], previous["total_accesses"]),
            "seconds": _pct_delta(current["total_seconds"], previous["total_seconds"]),
            "users": _pct_delta(current["unique_users"], previous["unique_users"]),
        },
    }


@api_router.get("/analytics/user/sessions")
async def analytics_user_sessions(
    authorization: Optional[str] = Header(None),
    email: str = Query(..., description="User email"),
    limit: int = Query(100, ge=1, le=500),
):
    user = await get_current_user(authorization)
    await require_admin(user)
    excluded = _norm_email(OWNER_EMAIL)
    excluded_list = [excluded, _norm_email(GUEST_EDITOR_EMAIL), _norm_email(GATE_VIEWER_EMAIL)]
    target = _norm_email(email)
    if target in excluded_list:
        raise HTTPException(status_code=404, detail="Utente escluso")

    try:
        await _finalize_stale_sessions()
    except Exception as e:
        logger.warning(f"finalize stale failed: {e}")

    cursor = db.access_logs.find(
        {"user_email": target},
        {"_id": 0},
    ).sort("started_at", -1).limit(limit)

    sessions = []
    name = None
    picture = None
    total_seconds = 0
    async for log in cursor:
        if not name:
            name = log.get("user_name")
            picture = log.get("user_picture")
        started = log.get("started_at")
        ended = log.get("ended_at") or log.get("last_heartbeat")
        duration = int(log.get("duration_seconds") or 0)
        total_seconds += duration
        sessions.append({
            "log_id": log.get("log_id"),
            "started_at": started.isoformat() if isinstance(started, datetime) else None,
            "ended_at": ended.isoformat() if isinstance(ended, datetime) else None,
            "duration_seconds": duration,
            "active": log.get("ended_at") is None,
        })

    return {
        "email": target,
        "name": name or target,
        "picture": picture,
        "total_shown": len(sessions),
        "total_seconds": total_seconds,
        "sessions": sessions,
    }


# --------- PHOTOS ARCHIVE ----------
def _photo_out(doc: dict) -> dict:
    ct = doc.get("content_type") or "image/jpeg"
    return {
        "id": doc.get("photo_id"),
        "year": int(doc.get("year") or 0),
        "album": doc.get("album") or "",
        "caption": doc.get("caption") or "",
        "filename": doc.get("filename") or "",
        "content_type": ct,
        "is_video": ct.startswith("video/"),
        "size": int(doc.get("size") or 0),
        "source": doc.get("source") or "upload",  # 'blog' | 'upload'
        "source_url": doc.get("source_url"),
        "uploaded_at": doc.get("uploaded_at").isoformat() if isinstance(doc.get("uploaded_at"), datetime) else None,
        "post_url": doc.get("post_url"),
        "order": int(doc.get("order") or 0),
    }


@api_router.get("/photos")
async def list_photos(
    authorization: Optional[str] = Header(None),
    year: Optional[int] = Query(None),
    album: Optional[str] = Query(None),
):
    await get_current_user(authorization)
    q: dict = {"private": {"$ne": True}}
    if year is not None:
        q["year"] = int(year)
    if album is not None:
        q["album"] = album
    cursor = db.photos.find(q, {"_id": 0}).sort([("year", -1), ("album", 1), ("order", 1), ("uploaded_at", 1)])
    items = []
    async for p in cursor:
        items.append(_photo_out(p))
    return {"photos": items}


@api_router.get("/photos/albums")
async def list_albums(authorization: Optional[str] = Header(None)):
    await get_current_user(authorization)
    pipeline = [
        {"$match": {"private": {"$ne": True}}},
        {
            "$group": {
                "_id": {"year": "$year", "album": "$album"},
                "count": {"$sum": 1},
                "cover_id": {"$first": "$photo_id"},
                "latest": {"$max": "$uploaded_at"},
                "source": {"$first": "$source"},
            },
        },
        {"$sort": {"_id.year": -1, "_id.album": 1}},
    ]
    albums = []
    async for row in db.photos.aggregate(pipeline):
        _id = row.get("_id") or {}
        latest = row.get("latest")
        albums.append({
            "year": int(_id.get("year") or 0),
            "album": _id.get("album") or "",
            "count": int(row.get("count") or 0),
            "cover_id": row.get("cover_id"),
            "source": row.get("source") or "upload",
            "latest": latest.isoformat() if isinstance(latest, datetime) else None,
        })
    # Also expose a year->count rollup for the "per anno" view
    year_pipeline = [
        {"$match": {"private": {"$ne": True}}},
        {"$group": {"_id": "$year", "count": {"$sum": 1}, "cover_id": {"$first": "$photo_id"}}},
        {"$sort": {"_id": -1}},
    ]
    years = []
    async for row in db.photos.aggregate(year_pipeline):
        years.append({
            "year": int(row.get("_id") or 0),
            "count": int(row.get("count") or 0),
            "cover_id": row.get("cover_id"),
        })
    return {"albums": albums, "years": years}


@api_router.get("/photos/file/{photo_id}")
async def download_photo_file(
    photo_id: str,
    token: Optional[str] = Query(None),
    authorization: Optional[str] = Header(None),
):
    auth = authorization
    if token and not auth:
        auth = f"Bearer {token}"
    await get_current_user(auth)
    p = await db.photos.find_one({"photo_id": photo_id, "private": {"$ne": True}}, {"_id": 0})
    if not p:
        raise HTTPException(status_code=404, detail="Foto non trovata")
    try:
        data, ct = await run_in_threadpool(get_object, p["path"])
    except requests.HTTPError:
        raise HTTPException(status_code=500, detail="Storage read failed")
    return Response(
        content=data,
        media_type=p.get("content_type") or ct,
        headers={"Content-Disposition": f'inline; filename="{p.get("filename", "photo.jpg")}"'},
    )


@api_router.post("/photos")
async def upload_photos(
    year: int = Form(...),
    album: str = Form(...),
    caption: str = Form(""),
    files: List[UploadFile] = File(...),
    authorization: Optional[str] = Header(None),
):
    user = await get_current_user(authorization)
    await require_admin_or_editor(user)
    if year < 1900 or year > 2100:
        raise HTTPException(status_code=400, detail="Anno non valido")
    album = (album or "").strip()
    if not album:
        raise HTTPException(status_code=400, detail="Nome evento/album obbligatorio")
    if not files:
        raise HTTPException(status_code=400, detail="Nessun file fornito")

    # Determine starting order index for this album
    existing = await db.photos.count_documents({"year": int(year), "album": album})
    inserted = []
    for i, f in enumerate(files):
        content = await f.read()
        if not content:
            continue
        ct = f.content_type or "image/jpeg"
        if not (ct.startswith("image/") or ct.startswith("video/")):
            continue
        if len(content) > 200 * 1024 * 1024:  # 200MB cap
            continue
        is_video = ct.startswith("video/")
        photo_id = f"ph_{uuid.uuid4().hex[:12]}"
        default_ext = "mp4" if is_video else "jpg"
        safe_name = (f.filename or f"{photo_id}.{default_ext}").replace("/", "_")
        path = f"{APP_NAME}/photos/{year}/{photo_id}/{safe_name}"
        try:
            await run_in_threadpool(put_object, path, content, ct)
        except Exception as e:
            logger.warning(f"photo upload failed: {e}")
            continue
        doc = {
            "photo_id": photo_id,
            "year": int(year),
            "album": album,
            "caption": caption or "",
            "filename": safe_name,
            "path": path,
            "content_type": ct,
            "size": len(content),
            "source": "upload",
            "uploaded_by": user.get("email"),
            "uploaded_at": datetime.now(timezone.utc),
            "order": existing + i,
        }
        await db.photos.insert_one(doc)
        inserted.append(_photo_out(doc))
    return {"ok": True, "inserted": len(inserted), "photos": inserted}


@api_router.delete("/photos/album")
async def delete_album(
    year: int = Query(...),
    album: str = Query(...),
    authorization: Optional[str] = Header(None),
):
    user = await get_current_user(authorization)
    await require_admin(user)
    res = await db.photos.delete_many({"year": int(year), "album": album})
    return {"ok": True, "deleted": int(res.deleted_count or 0)}


class PhotoBatchDelete(BaseModel):
    ids: List[str]


@api_router.post("/photos/batch-delete")
async def batch_delete_photos(
    payload: PhotoBatchDelete,
    authorization: Optional[str] = Header(None),
):
    user = await get_current_user(authorization)
    await require_admin(user)
    ids = [str(i) for i in (payload.ids or []) if i]
    if not ids:
        return {"ok": True, "deleted": 0}
    res = await db.photos.delete_many({"photo_id": {"$in": ids}})
    return {"ok": True, "deleted": int(res.deleted_count or 0)}


@api_router.patch("/photos/{photo_id}")
async def update_photo(
    photo_id: str,
    payload: dict,
    authorization: Optional[str] = Header(None),
):
    user = await get_current_user(authorization)
    await require_admin(user)
    p = await db.photos.find_one({"photo_id": photo_id}, {"_id": 0})
    if not p:
        raise HTTPException(status_code=404, detail="Foto non trovata")
    update: dict = {}
    if "caption" in payload:
        update["caption"] = str(payload.get("caption") or "")[:500]
    if "album" in payload:
        new_album = str(payload.get("album") or "").strip()
        if new_album:
            update["album"] = new_album
    if "year" in payload:
        try:
            yr = int(payload.get("year"))
            if 1900 <= yr <= 2100:
                update["year"] = yr
        except (TypeError, ValueError):
            pass
    if not update:
        return _photo_out(p)
    await db.photos.update_one({"photo_id": photo_id}, {"$set": update})
    merged = {**p, **update}
    return _photo_out(merged)


@api_router.delete("/photos/{photo_id}")
async def delete_photo(photo_id: str, authorization: Optional[str] = Header(None)):
    user = await get_current_user(authorization)
    await require_admin(user)
    p = await db.photos.find_one({"photo_id": photo_id}, {"_id": 0})
    if not p:
        raise HTTPException(status_code=404, detail="Foto non trovata")
    await db.photos.delete_one({"photo_id": photo_id})
    return {"ok": True}


# ---- Private archive (password-protected area for admins to share with trusted team) ----
PRIVATE_PASSWORD_KEY = "photos_private_password"


def _hash_private_password(p: str) -> str:
    return hashlib.sha256((p or "").strip().encode("utf-8")).hexdigest()


async def _get_private_password_hash() -> Optional[str]:
    doc = await db.settings.find_one({"key": PRIVATE_PASSWORD_KEY}, {"_id": 0})
    if not doc:
        return None
    return doc.get("value")


@api_router.get("/photos/private/status")
async def private_status(authorization: Optional[str] = Header(None)):
    await get_current_user(authorization)
    h = await _get_private_password_hash()
    return {"configured": bool(h)}


@api_router.post("/photos/private/password")
async def set_private_password(
    payload: PrivatePasswordIn, authorization: Optional[str] = Header(None),
):
    user = await get_current_user(authorization)
    await require_admin(user)
    pwd = (payload.password or "").strip()
    if len(pwd) < 4:
        raise HTTPException(status_code=400, detail="Password troppo corta (min 4 caratteri)")
    await db.settings.update_one(
        {"key": PRIVATE_PASSWORD_KEY},
        {"$set": {"key": PRIVATE_PASSWORD_KEY, "value": _hash_private_password(pwd), "updated_at": datetime.now(timezone.utc)}},
        upsert=True,
    )
    return {"ok": True}


@api_router.post("/photos/private/check")
async def check_private_password(payload: PrivateCheckIn):
    h = await _get_private_password_hash()
    if not h:
        raise HTTPException(status_code=404, detail="Password non ancora configurata")
    ok = _hash_private_password(payload.password or "") == h
    if not ok:
        raise HTTPException(status_code=401, detail="Password errata")
    return {"ok": True}


async def _verify_private_password_header(x_private_password: Optional[str]) -> None:
    h = await _get_private_password_hash()
    if not h:
        raise HTTPException(status_code=404, detail="Area privata non ancora configurata")
    if _hash_private_password(x_private_password or "") != h:
        raise HTTPException(status_code=401, detail="Password privata mancante o errata")


def _photo_out_v2(doc: dict) -> dict:
    base = _photo_out(doc)
    base["is_private"] = bool(doc.get("private", False))
    base["is_video"] = (doc.get("content_type") or "").startswith("video/")
    base["album_id"] = doc.get("album_id")
    return base


@api_router.get("/photos/private/list")
async def list_private_photos(
    x_private_password: Optional[str] = Header(None, alias="X-Private-Password"),
    year: Optional[int] = Query(None),
    album: Optional[str] = Query(None),
    authorization: Optional[str] = Header(None),
):
    await get_current_user(authorization)
    await _verify_private_password_header(x_private_password)
    q: dict = {"private": True}
    if year is not None:
        q["year"] = int(year)
    if album is not None:
        q["album"] = album
    cursor = db.photos.find(q, {"_id": 0}).sort(
        [("year", -1), ("album", 1), ("order", 1), ("uploaded_at", 1)]
    )
    items = []
    async for p in cursor:
        items.append(_photo_out_v2(p))
    # Albums rollup for private only
    pipeline = [
        {"$match": {"private": True}},
        {
            "$group": {
                "_id": {"year": "$year", "album": "$album"},
                "count": {"$sum": 1},
                "cover_id": {"$first": "$photo_id"},
                "latest": {"$max": "$uploaded_at"},
            },
        },
        {"$sort": {"_id.year": -1, "_id.album": 1}},
    ]
    albums = []
    async for row in db.photos.aggregate(pipeline):
        _id = row.get("_id") or {}
        latest = row.get("latest")
        albums.append({
            "year": int(_id.get("year") or 0),
            "album": _id.get("album") or "",
            "count": int(row.get("count") or 0),
            "cover_id": row.get("cover_id"),
            "source": "private",
            "latest": latest.isoformat() if isinstance(latest, datetime) else None,
        })
    return {"photos": items, "albums": albums}


@api_router.get("/photos/private/file/{photo_id}")
async def download_private_file(
    photo_id: str,
    pw: Optional[str] = Query(None),
    x_private_password: Optional[str] = Header(None, alias="X-Private-Password"),
    token: Optional[str] = Query(None),
    authorization: Optional[str] = Header(None),
):
    auth = authorization
    if token and not auth:
        auth = f"Bearer {token}"
    await get_current_user(auth)
    pwd_to_check = x_private_password or pw
    await _verify_private_password_header(pwd_to_check)
    p = await db.photos.find_one({"photo_id": photo_id, "private": True}, {"_id": 0})
    if not p:
        raise HTTPException(status_code=404, detail="File privato non trovato")
    try:
        data, ct = await run_in_threadpool(get_object, p["path"])
    except Exception:
        raise HTTPException(status_code=500, detail="Storage read failed")
    return Response(
        content=data,
        media_type=p.get("content_type") or ct,
        headers={"Content-Disposition": f'inline; filename="{p.get("filename", "file")}"'},
    )


@api_router.post("/photos/private/upload")
async def upload_private_photos(
    year: int = Form(...),
    album: str = Form(...),
    caption: str = Form(""),
    files: List[UploadFile] = File(...),
    authorization: Optional[str] = Header(None),
    x_private_password: Optional[str] = Header(None, alias="X-Private-Password"),
):
    user = await get_current_user(authorization)
    await require_admin_or_editor(user)
    await _verify_private_password_header(x_private_password)
    if year < 1900 or year > 2100:
        raise HTTPException(status_code=400, detail="Anno non valido")
    album = (album or "").strip()
    if not album:
        raise HTTPException(status_code=400, detail="Nome album obbligatorio")
    existing = await db.photos.count_documents({"year": int(year), "album": album, "private": True})
    inserted = []
    for i, f in enumerate(files):
        content = await f.read()
        if not content:
            continue
        ct = f.content_type or "application/octet-stream"
        if not (ct.startswith("image/") or ct.startswith("video/")):
            continue
        if len(content) > 200 * 1024 * 1024:  # 200MB cap
            continue
        photo_id = f"ph_{uuid.uuid4().hex[:12]}"
        safe_name = (f.filename or f"{photo_id}.bin").replace("/", "_")
        path = f"{APP_NAME}/photos/private/{year}/{photo_id}/{safe_name}"
        try:
            await run_in_threadpool(put_object, path, content, ct)
        except Exception as e:
            logger.warning(f"private upload fail: {e}")
            continue
        doc = {
            "photo_id": photo_id,
            "year": int(year),
            "album": album,
            "caption": caption or "",
            "filename": safe_name,
            "path": path,
            "content_type": ct,
            "size": len(content),
            "source": "upload",
            "private": True,
            "uploaded_by": user.get("email"),
            "uploaded_at": datetime.now(timezone.utc),
            "order": existing + i,
        }
        await db.photos.insert_one(doc)
        inserted.append(_photo_out_v2(doc))
    return {"ok": True, "inserted": len(inserted), "photos": inserted}


# One-shot Blogger import (idempotent per source_url)
import re as _re_blog


BLOG_FEED_URL = "https://battaglionefuriani.blogspot.com/feeds/posts/default?alt=json&max-results=200"


@api_router.post("/photos/import-blog")
async def import_blog_photos(authorization: Optional[str] = Header(None)):
    user = await get_current_user(authorization)
    await require_admin(user)
    try:
        import json as _json
        resp = requests.get(BLOG_FEED_URL, timeout=60, headers={"User-Agent": "Mozilla/5.0"})
        resp.raise_for_status()
        data = resp.json()
    except Exception as e:
        raise HTTPException(status_code=502, detail=f"Impossibile scaricare feed blog: {e}")

    entries = (data.get("feed") or {}).get("entry") or []
    imported = 0
    skipped = 0
    albums_touched: list = []

    for e in entries:
        title = ((e.get("title") or {}).get("$t") or "").strip()
        published = ((e.get("published") or {}).get("$t") or "")
        year_s = published[:4] if published else ""
        try:
            year = int(year_s)
        except Exception:
            continue
        content_html = ((e.get("content") or {}).get("$t") or "")
        # Prefer full-res /s1600/ hrefs; fallback to thumbnail srcs
        hrefs = _re_blog.findall(r'href="(https://blogger\.googleusercontent\.com/img/[^"]+?/s1600/[^"]+)"', content_html)
        if not hrefs:
            hrefs = _re_blog.findall(r'src="(https://blogger\.googleusercontent\.com/img/[^"]+)"', content_html)
        # De-dupe while preserving order
        seen = set()
        urls = []
        for u in hrefs:
            if u in seen:
                continue
            seen.add(u)
            urls.append(u)
        if not urls:
            continue
        # Post URL (for permalink reference)
        post_url = None
        for link in (e.get("link") or []):
            if link.get("rel") == "alternate":
                post_url = link.get("href")
                break

        album = title or f"Album {year}"
        for idx, url in enumerate(urls):
            # Skip if already imported this exact source URL
            existing_src = await db.photos.find_one({"source_url": url}, {"_id": 0})
            if existing_src:
                skipped += 1
                continue
            try:
                r = requests.get(url, timeout=60, headers={"User-Agent": "Mozilla/5.0"})
                r.raise_for_status()
                raw = r.content
                ct = r.headers.get("Content-Type", "image/jpeg").split(";")[0].strip() or "image/jpeg"
            except Exception as ex:
                logger.warning(f"download fail {url}: {ex}")
                continue
            photo_id = f"ph_{uuid.uuid4().hex[:12]}"
            # Filename from URL tail
            tail = url.rstrip("/").split("/")[-1][:120] or f"{photo_id}.jpg"
            safe_name = tail.replace("?", "_")
            if "." not in safe_name:
                safe_name += ".jpg"
            path = f"{APP_NAME}/photos/{year}/{photo_id}/{safe_name}"
            try:
                await run_in_threadpool(put_object, path, raw, ct)
            except Exception as ex:
                logger.warning(f"blob put fail: {ex}")
                continue
            doc = {
                "photo_id": photo_id,
                "year": year,
                "album": album,
                "caption": "",
                "filename": safe_name,
                "path": path,
                "content_type": ct,
                "size": len(raw),
                "source": "blog",
                "source_url": url,
                "post_url": post_url,
                "uploaded_by": user.get("email"),
                "uploaded_at": datetime.now(timezone.utc),
                "order": idx,
            }
            await db.photos.insert_one(doc)
            imported += 1
            key = (year, album)
            if key not in albums_touched:
                albums_touched.append(key)

    return {
        "ok": True,
        "imported": imported,
        "skipped_existing": skipped,
        "albums_touched": [{"year": y, "album": a} for (y, a) in albums_touched],
    }


# --------- PUBLIC READ-ONLY API (no auth required) ----------
PUBLIC_OPERATOR_FIELDS = {
    "id": 1,
    "battle_name": 1,
    "rank": 1,
    "department": 1,
    "has_photo": 1,
}


def _public_operator_out(doc: dict) -> dict:
    """Return minimal operator info safe for public visitors: photo, rank, battle name only."""
    photo = doc.get("photo") or {}
    dept = doc.get("department") or []
    if isinstance(dept, str):
        dept = [d.strip() for d in dept.split(",") if d.strip()] if "," in dept else [dept]
    return {
        "id": doc.get("id"),
        "battle_name": doc.get("battle_name") or "",
        "rank": doc.get("rank") or "",
        "department": dept,
        "has_photo": bool(photo.get("path")),
    }


@api_router.get("/public/operators")
async def public_list_operators():
    cursor = db.operators.find({}, {"_id": 0}).sort([("rank", 1), ("battle_name", 1)])
    items = []
    async for op in cursor:
        items.append(_public_operator_out(op))
    return {"operators": items}


@api_router.get("/public/operators/{op_id}/photo")
async def public_operator_photo(op_id: str):
    op = await db.operators.find_one({"id": op_id}, {"_id": 0})
    if not op:
        raise HTTPException(status_code=404, detail="Operator not found")
    photo = op.get("photo") or {}
    photo_path = photo.get("path")
    content_type = photo.get("content_type")
    if not photo_path:
        raise HTTPException(status_code=404, detail="Nessuna foto")
    try:
        data, ct = await run_in_threadpool(get_object, photo_path)
    except Exception:
        raise HTTPException(status_code=500, detail="Storage read failed")
    return Response(
        content=data,
        media_type=content_type or ct,
        headers={"Cache-Control": "public, max-age=3600"},
    )


@api_router.get("/public/photos")
async def public_list_photos(
    year: Optional[int] = Query(None),
    album: Optional[str] = Query(None),
):
    q: dict = {"private": {"$ne": True}}
    if year is not None:
        q["year"] = int(year)
    if album is not None:
        q["album"] = album
    cursor = db.photos.find(q, {"_id": 0}).sort(
        [("year", -1), ("album", 1), ("order", 1), ("uploaded_at", 1)]
    )
    items = []
    async for p in cursor:
        items.append(_photo_out(p))
    return {"photos": items}


@api_router.get("/public/photos/albums")
async def public_list_albums():
    pipeline = [
        {"$match": {"private": {"$ne": True}}},
        {
            "$group": {
                "_id": {"year": "$year", "album": "$album"},
                "count": {"$sum": 1},
                "cover_id": {"$first": "$photo_id"},
                "latest": {"$max": "$uploaded_at"},
                "source": {"$first": "$source"},
            },
        },
        {"$sort": {"_id.year": -1, "_id.album": 1}},
    ]
    albums = []
    async for row in db.photos.aggregate(pipeline):
        _id = row.get("_id") or {}
        latest = row.get("latest")
        albums.append({
            "year": int(_id.get("year") or 0),
            "album": _id.get("album") or "",
            "count": int(row.get("count") or 0),
            "cover_id": row.get("cover_id"),
            "source": row.get("source") or "upload",
            "latest": latest.isoformat() if isinstance(latest, datetime) else None,
        })
    year_pipeline = [
        {"$match": {"private": {"$ne": True}}},
        {"$group": {"_id": "$year", "count": {"$sum": 1}, "cover_id": {"$first": "$photo_id"}}},
        {"$sort": {"_id": -1}},
    ]
    years = []
    async for row in db.photos.aggregate(year_pipeline):
        years.append({
            "year": int(row.get("_id") or 0),
            "count": int(row.get("count") or 0),
            "cover_id": row.get("cover_id"),
        })
    return {"albums": albums, "years": years}


@api_router.get("/public/photos/file/{photo_id}")
async def public_download_photo(photo_id: str):
    p = await db.photos.find_one({"photo_id": photo_id, "private": {"$ne": True}}, {"_id": 0})
    if not p:
        raise HTTPException(status_code=404, detail="Foto non trovata")
    try:
        data, ct = await run_in_threadpool(get_object, p["path"])
    except Exception:
        raise HTTPException(status_code=500, detail="Storage read failed")
    return Response(
        content=data,
        media_type=p.get("content_type") or ct,
        headers={
            "Content-Disposition": f'inline; filename="{p.get("filename", "photo.jpg")}"',
            "Cache-Control": "public, max-age=3600",
        },
    )


# --------- NOTIFICHE & REGISTRO VISUALIZZAZIONI EVENTI ----------
@api_router.get("/notifications")
async def list_notifications(authorization: Optional[str] = Header(None)):
    user = await get_current_user(authorization)
    items = await db.notifications.find({}, {"_id": 0}).sort("created_at", -1).to_list(30)
    seen = await db.notification_seen.find_one({"user_id": user["user_id"]}, {"_id": 0})
    last_seen = seen.get("seen_at") if seen else None
    if isinstance(last_seen, datetime) and last_seen.tzinfo is None:
        last_seen = last_seen.replace(tzinfo=timezone.utc)
    out, unread = [], 0
    for n in items:
        ca = n.get("created_at")
        if isinstance(ca, datetime) and ca.tzinfo is None:
            ca = ca.replace(tzinfo=timezone.utc)
        is_unread = last_seen is None or (isinstance(ca, datetime) and ca > last_seen)
        unread += 1 if is_unread else 0
        out.append({
            "id": n["id"], "type": n.get("type", "event"), "event_id": n.get("event_id"),
            "title": n.get("title", ""), "date": n.get("date", ""),
            "created_at": ca.isoformat() if isinstance(ca, datetime) else None,
            "unread": is_unread,
        })
    return {"notifications": out, "unread_count": unread}


@api_router.post("/notifications/seen")
async def notifications_seen(authorization: Optional[str] = Header(None)):
    user = await get_current_user(authorization)
    await db.notification_seen.update_one(
        {"user_id": user["user_id"]},
        {"$set": {"user_id": user["user_id"], "seen_at": datetime.now(timezone.utc)}},
        upsert=True,
    )
    return {"ok": True}


@api_router.post("/events/{ev_id}/view")
async def register_event_view(ev_id: str, authorization: Optional[str] = Header(None)):
    user = await get_current_user(authorization)
    await db.event_views.update_one(
        {"event_id": ev_id, "user_id": user["user_id"]},
        {"$set": {
            "event_id": ev_id, "user_id": user["user_id"],
            "user_name": user.get("name") or user.get("email", ""),
            "user_email": user.get("email", ""),
            "viewed_at": datetime.now(timezone.utc),
        }},
        upsert=True,
    )
    return {"ok": True}


@api_router.get("/events/{ev_id}/views")
async def list_event_views(ev_id: str, authorization: Optional[str] = Header(None)):
    user = await get_current_user(authorization)
    await require_admin(user)
    items = await db.event_views.find({"event_id": ev_id}, {"_id": 0}).sort("viewed_at", -1).to_list(500)
    return {"views": [{
        "user_name": v.get("user_name", ""), "user_email": v.get("user_email", ""),
        "viewed_at": v["viewed_at"].replace(tzinfo=timezone.utc).isoformat() if isinstance(v.get("viewed_at"), datetime) else None,
    } for v in items]}


# --------- CASSA SQUADRA (admin only) ----------
class CassaNotesIn(BaseModel):
    notes: str = ""


class CassaAmountIn(BaseModel):
    amount: float = 0


class TournamentIn(BaseModel):
    name: str
    cost: float = 0


async def _get_setting(key: str, default=None):
    doc = await db.settings.find_one({"key": key}, {"_id": 0})
    return doc.get("value", default) if doc else default


async def _set_setting(key: str, value):
    await db.settings.update_one({"key": key}, {"$set": {"key": key, "value": value}}, upsert=True)


CASSA_MONTHLY_FEE = 10.0  # stessa quota della sezione Tesseramento (operator/[id].tsx MONTHLY_FEE)


async def _cassa_summary() -> dict:
    ops = await db.operators.find({}, {"_id": 0, "id": 1, "annual_fee_paid": 1, "annual_fee_amount": 1}).to_list(2000)
    income_annual = sum(float(o.get("annual_fee_amount") or 0) for o in ops if o.get("annual_fee_paid"))
    op_ids = [o["id"] for o in ops]
    paid_months = await db.payments.count_documents({"paid": True, "operator_id": {"$in": op_ids}})
    income_monthly = paid_months * CASSA_MONTHLY_FEE
    tours = await db.cassa_tournaments.find({}, {"_id": 0, "cost": 1}).to_list(2000)
    tournaments_total = sum(float(t.get("cost") or 0) for t in tours)
    manual = float(await _get_setting("cassa_manual_adjustment", 0) or 0)
    return {
        "balance": round(income_annual + income_monthly - tournaments_total + manual, 2),
        "income_annual": round(income_annual, 2),
        "paid_annual_count": sum(1 for o in ops if o.get("annual_fee_paid")),
        "income_monthly": round(income_monthly, 2),
        "paid_months": paid_months,
        "monthly_fee": CASSA_MONTHLY_FEE,
        "tournaments_total": tournaments_total,
        "manual_adjustment": manual,
        "notes": await _get_setting("cassa_notes", "") or "",
    }


@api_router.get("/cassa/summary")
async def cassa_summary(authorization: Optional[str] = Header(None)):
    await require_admin(await get_current_user(authorization))
    return await _cassa_summary()


@api_router.post("/cassa/notes")
async def cassa_notes(payload: CassaNotesIn, authorization: Optional[str] = Header(None)):
    await require_admin(await get_current_user(authorization))
    await _set_setting("cassa_notes", payload.notes)
    return {"ok": True}


@api_router.post("/cassa/adjustment")
async def cassa_adjustment(payload: CassaAmountIn, authorization: Optional[str] = Header(None)):
    await require_admin(await get_current_user(authorization))
    await _set_setting("cassa_manual_adjustment", float(payload.amount))
    return await _cassa_summary()


@api_router.get("/cassa/tournaments")
async def cassa_tournaments(authorization: Optional[str] = Header(None)):
    await require_admin(await get_current_user(authorization))
    items = await db.cassa_tournaments.find({}, {"_id": 0}).sort("created_at", -1).to_list(2000)
    return {"tournaments": [{"id": t["id"], "name": t["name"], "cost": t.get("cost", 0)} for t in items]}


@api_router.post("/cassa/tournaments")
async def cassa_add_tournament(payload: TournamentIn, authorization: Optional[str] = Header(None)):
    user = await require_admin(await get_current_user(authorization))
    if not payload.name.strip():
        raise HTTPException(status_code=400, detail="Nome obbligatorio")
    doc = {
        "id": f"tr_{uuid.uuid4().hex[:12]}", "name": payload.name.strip(),
        "cost": float(payload.cost or 0), "created_by": user["email"],
        "created_at": datetime.now(timezone.utc),
    }
    await db.cassa_tournaments.insert_one(doc)
    return {"id": doc["id"], "name": doc["name"], "cost": doc["cost"]}


@api_router.delete("/cassa/tournaments/{t_id}")
async def cassa_del_tournament(t_id: str, authorization: Optional[str] = Header(None)):
    await require_admin(await get_current_user(authorization))
    r = await db.cassa_tournaments.delete_one({"id": t_id})
    if r.deleted_count == 0:
        raise HTTPException(status_code=404, detail="Non trovato")
    return {"ok": True}


@api_router.get("/cassa/files")
async def cassa_files(authorization: Optional[str] = Header(None)):
    await require_admin(await get_current_user(authorization))
    items = await db.cassa_files.find({}, {"_id": 0, "path": 0}).sort("uploaded_at", -1).to_list(1000)
    return {"files": items}


@api_router.post("/cassa/files")
async def cassa_upload_file(file: UploadFile = File(...), authorization: Optional[str] = Header(None)):
    user = await require_admin(await get_current_user(authorization))
    content = await file.read()
    name = file.filename or "file"
    ext = name.rsplit(".", 1)[-1].lower() if "." in name else "bin"
    ext = "".join(c for c in ext if c.isalnum()) or "bin"
    path = f"{APP_NAME}/cassa/{uuid.uuid4().hex}.{ext}"
    ct = file.content_type or "application/octet-stream"
    try:
        await run_in_threadpool(put_object, path, content, ct)
    except requests.HTTPError as e:
        status = e.response.status_code if e.response is not None else 500
        raise HTTPException(status_code=status, detail=f"Storage error: {status}")
    info = {
        "file_id": uuid.uuid4().hex[:12], "path": path, "filename": name,
        "content_type": ct, "size": len(content), "uploaded_by": user["email"],
        "uploaded_at": datetime.now(timezone.utc).isoformat(),
    }
    await db.cassa_files.insert_one(dict(info))
    info.pop("path")
    return info


@api_router.get("/cassa/files/{file_id}")
async def cassa_get_file(file_id: str, token: Optional[str] = None, authorization: Optional[str] = Header(None)):
    auth_header = authorization or (f"Bearer {token}" if token else None)
    await require_admin(await get_current_user(auth_header))
    info = await db.cassa_files.find_one({"file_id": file_id}, {"_id": 0})
    if not info:
        raise HTTPException(status_code=404, detail="File non trovato")
    try:
        data, ct = await run_in_threadpool(get_object, info["path"])
    except requests.HTTPError:
        raise HTTPException(status_code=500, detail="Storage read failed")
    return Response(content=data, media_type=info.get("content_type") or ct,
                    headers={"Content-Disposition": f'inline; filename="{info["filename"]}"'})


@api_router.delete("/cassa/files/{file_id}")
async def cassa_del_file(file_id: str, authorization: Optional[str] = Header(None)):
    await require_admin(await get_current_user(authorization))
    r = await db.cassa_files.delete_one({"file_id": file_id})
    if r.deleted_count == 0:
        raise HTTPException(status_code=404, detail="Non trovato")
    return {"ok": True}


# --------- RADAR SQUADRA (posizione live) ----------
RADAR_TTL_SECONDS = 120


class RadarPingIn(BaseModel):
    lat: float
    lng: float


@api_router.post("/radar/ping")
async def radar_ping(payload: RadarPingIn, authorization: Optional[str] = Header(None)):
    user = await get_current_user(authorization)
    if not (-90 <= payload.lat <= 90 and -180 <= payload.lng <= 180):
        raise HTTPException(status_code=400, detail="Coordinate non valide")
    await db.radar_positions.update_one(
        {"user_id": user["user_id"]},
        {"$set": {
            "user_id": user["user_id"], "name": user.get("name") or user.get("email", ""),
            "lat": payload.lat, "lng": payload.lng, "updated_at": datetime.now(timezone.utc),
        }},
        upsert=True,
    )
    return {"ok": True}


@api_router.post("/radar/leave")
async def radar_leave(authorization: Optional[str] = Header(None)):
    user = await get_current_user(authorization)
    await db.radar_positions.delete_one({"user_id": user["user_id"]})
    return {"ok": True}


@api_router.get("/radar/positions")
async def radar_positions(authorization: Optional[str] = Header(None)):
    user = await get_current_user(authorization)
    now = datetime.now(timezone.utc)
    cutoff = now - timedelta(seconds=RADAR_TTL_SECONDS)
    items = await db.radar_positions.find({"updated_at": {"$gte": cutoff}}, {"_id": 0}).to_list(500)
    out = []
    for p in items:
        ua = p["updated_at"]
        if ua.tzinfo is None:
            ua = ua.replace(tzinfo=timezone.utc)
        out.append({
            "user_id": p["user_id"], "name": p.get("name", ""), "lat": p["lat"], "lng": p["lng"],
            "age_seconds": int((now - ua).total_seconds()), "is_me": p["user_id"] == user["user_id"],
        })
    return {"positions": out}


@api_router.get("/download/{name}.zip")
async def download_zip(name: str):
    if name not in ("furiani-web", "furiani-codice-sorgente"):
        raise HTTPException(status_code=404, detail="File non trovato")
    path = ROOT_DIR / "static" / f"{name}.zip"
    return Response(content=path.read_bytes(), media_type="application/zip",
                    headers={"Content-Disposition": f'attachment; filename="{name}.zip"'})


@api_router.get("/download/index.html")
async def download_github_index():
    path = ROOT_DIR / "static" / "index.html"
    return Response(content=path.read_bytes(), media_type="text/html",
                    headers={"Content-Disposition": 'attachment; filename="index.html"'})


# Include router (must be after all @api_router.* definitions)
app.include_router(api_router)


@app.on_event("startup")
async def startup():
    try:
        await db.users.create_index("email", unique=True)
        await db.users.create_index("user_id", unique=True)
        await db.user_sessions.create_index("session_token", unique=True)
        await db.user_sessions.create_index("user_id")
        await db.user_sessions.create_index("expires_at", expireAfterSeconds=0)
        await db.operators.create_index([("owner_id", 1), ("created_at", 1)])
        await db.attendance.create_index(
            [("operator_id", 1), ("date", 1)], unique=True
        )
        await db.payments.create_index(
            [("operator_id", 1), ("month", 1)], unique=True
        )
        await db.members.create_index("email", unique=True)
        await db.settings.create_index("key", unique=True)
        await db.access_logs.create_index("log_id", unique=True)
        await db.access_logs.create_index([("user_email", 1), ("started_at", -1)])
        await db.access_logs.create_index("started_at")
        await db.photos.create_index("photo_id", unique=True)
        await db.photos.create_index([("year", -1), ("album", 1), ("order", 1)])
        await db.photos.create_index("source_url")
    except Exception as e:
        logger.warning(f"Index setup: {e}")
    try:
        await run_in_threadpool(init_storage)
        logger.info("Storage initialized")
    except Exception as e:
        logger.warning(f"Storage init failed: {e}")


@app.on_event("shutdown")
async def shutdown_db_client():
    client.close()
